function test2GfarfieldNovotny(dirdipole,lambda,zo)
p = path;
%path(p,'..\multialgebra');
path(p,'\\NANORFSRV\Users\Bernal\Theory\DipoleDipoleLayeredSubstrate\GreenWaveguideFarField\multialgebra\');
c=1;
%lambda=2000;
k=(2*pi/lambda);
omega=k*c;


% mu0=1;
% mu1=1;
% mu2=1;
% mu3=1;
% eps0=1;
% eps1=1;
% eps2=4.01;
% eps3=2.127;
% t=0.1;



mu0=1;
mu1=1;
mu2=1;
mu3=1;
eps0=1;
eps1=1;
eps2=5;
eps3=2.25;
t=0.08;


% mu0=1;
% mu1=1;
% mu2=1;
% mu3=1;
% eps0=1;
% eps1=1;
% eps2=2.25;
% eps3=2.25;
% t=0;


struct=[[eps1;eps2;eps3],[mu1;mu2;mu3]];

Radius=1;

numpohalf=500;
numpo=numpohalf*2;
%zo=0*lambda/(4*pi);



% [Powertopx,Powerbottomx]=fieldduedipole([cos(pi/3),0,sin(pi/3)]);
thetatop=[linspace(pi/2,0,numpohalf).';linspace(0,pi/2,numpohalf).'];
phitop=[zeros(numpohalf,1)+pi;zeros(numpohalf,1)];
rdetecttop=[Radius*sin(thetatop).*cos(phitop),Radius*sin(thetatop).*sin(phitop),Radius*cos(thetatop)];
rsourcetop=repmat([0,0,zo],numpo,1);


thetabottom=[linspace(pi/2,pi,numpohalf).';linspace(pi,pi/2,numpohalf).'];
phibottom=[zeros(numpohalf,1);zeros(numpohalf,1)+pi];
rdetectbottom=[Radius*sin(thetabottom).*cos(phibottom),Radius*sin(thetabottom).*sin(phibottom),Radius*cos(thetabottom)];
rsourcebottom=repmat([0,0,zo],numpo,1);  

GreenWaveguideFarFieldDyadtop=GreenWaveguideFarField(k,rdetecttop,rsourcetop,struct,t);
GreenWaveguideFarFieldDyadbottom=GreenWaveguideFarField(k,rdetectbottom,rsourcebottom,struct,t);

Fieldtop=(omega^2*mu0*mu1)*multiprod(GreenWaveguideFarFieldDyadtop,repmat(dirdipole,numpo,1).',[1,2],[1]).';

FieldBottom=(omega^2*mu0*mu1)*multiprod(GreenWaveguideFarFieldDyadbottom,repmat(dirdipole,numpo,1).',[1,2],[1]).';

Po=(sqrt(eps1)^3*omega^(4))/(4*pi*eps0*eps1*3*c^3);

powertop=((Radius^2))*(1/2)*(sqrt(eps0*eps1/(mu0*mu1)))*sum(Fieldtop.*conj(Fieldtop),2)/Po;
powerbottom=((Radius^2))*(1/2)*(sqrt(eps0*eps3/(mu0*mu3)))*sum(FieldBottom.*conj(FieldBottom),2)/Po;
%powertop=   ((Radius^2))*(1/2)*(sqrt(eps0*eps1/(mu0*mu1)))*Fieldtop(:,1).*conj(Fieldtop(:,1))/Po;
%powerbottom=((Radius^2))*(1/2)*(sqrt(eps0*eps3/(mu0*mu3)))*FieldBottom(:,1).*conj(FieldBottom(:,1))/Po;


thetaplot=linspace(-pi/2,3*pi/2,2*numpo).';
figure(1)
plot(thetaplot*180/pi,[powertop;powerbottom],'.');
title('Dipole with direction')
figure(2)
polar(thetaplot,[powertop;powerbottom]);
title('Dipole with direction')

end

