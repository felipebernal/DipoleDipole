function testGfarfield
p = path;
%path(p,'..\multialgebra');
path(p,'\\NANORFSRV\Users\Bernal\Theory\DipoleDipoleLayeredSubstrate\GreenWaveguideFarField\multialgebra\');
c=1;
lambda=2000;
k=(2*pi/lambda);
omega=k*c;

mu0=1;
mu1=1;
mu2=1;
mu3=1;
eps0=1;
eps1=1;
eps2=sqrt(2);
eps3=sqrt(2);


% 
% mu0=1;
% mu1=1;
% mu2=1;
% mu3=1;
% eps0=1;
% eps1=1;
% eps2=1.01;
% eps3=1.01;



struct=[[eps1;eps2;eps3],[mu1;mu2;mu3]];
t=0;
Radius=1;
numpo=1000;
zo=0*lambda/(4*pi);



% [Powertopx,Powerbottomx]=fieldduedipole([cos(pi/3),0,sin(pi/3)]);
[Powertopx,Powerbottomx]=fieldduedipole([1,0,0]);
figure(1)
plot(([thetatop;thetabottom]-pi/2)*180/pi,[Powertopx;Powerbottomx],'.');
title('Dipole X')
figure(2)
polar([thetatop;thetabottom],[Powertopx;Powerbottomx]);
title('Dipole X')

[Powertopy,Powerbottomy]=fieldduedipole([0,1,0]);
figure(3)
plot(([thetatop;thetabottom]-pi/2)*180/pi,[Powertopy;Powerbottomy],'.');
title('Dipole Y')
figure(4)
polar([thetatop;thetabottom],[Powertopy;Powerbottomy]);
title('Dipole Y')

[Powertopz,Powerbottomz]=fieldduedipole([0,0,1]);
figure(5)
plot(([thetatop;thetabottom]-pi/2)*180/pi,[Powertopz;Powerbottomz],'.');
title('Dipole Z')
figure(6)
polar([thetatop;thetabottom],[Powertopz;Powerbottomz]);
title('Dipole Z')





function [powertop,powerbottom]=fieldduedipole(dirdipole)
    
if norm(dirdipole-[0,0,1])==0
thetatop=linspace(3*pi/2,5*pi/2,numpo).';
rdetecttop=[Radius*sin(thetatop),0*thetatop,Radius*cos(thetatop)];

rsourcetop=repmat([0,0,zo],numpo,1);


thetabottom=linspace(pi/2,3*pi/2,numpo).';
rdetectbottom=[Radius*sin(thetabottom),0*thetatop,Radius*cos(thetabottom)];

rsourcebottom=repmat([0,0,zo],numpo,1);
else
  thetatop=linspace(3*pi/2,5*pi/2,numpo).';
rdetecttop=[Radius*sin(thetatop)*dirdipole(2),Radius*sin(thetatop)*dirdipole(1),Radius*cos(thetatop)];

rsourcetop=repmat([0,0,zo],numpo,1);


thetabottom=linspace(pi/2,3*pi/2,numpo).';
rdetectbottom=[Radius*sin(thetabottom)*dirdipole(2),Radius*sin(thetabottom)*dirdipole(1),Radius*cos(thetabottom)];

rsourcebottom=repmat([0,0,zo],numpo,1);  
    
end
GreenWaveguideFarFieldDyadtop=GreenWaveguideFarField(k,rdetecttop,rsourcetop,struct,t);
GreenWaveguideFarFieldDyadbottom=GreenWaveguideFarField(k,rdetectbottom,rsourcebottom,struct,t);

Fieldtop=(omega^2*mu0*mu1)*multiprod(GreenWaveguideFarFieldDyadtop,repmat(dirdipole,numpo,1).',[1,2],[1]).';

FieldBottom=(omega^2*mu0*mu1)*multiprod(GreenWaveguideFarFieldDyadbottom,repmat(dirdipole,numpo,1).',[1,2],[1]).';

Po=(sqrt(eps1)^3*omega^(4))/(4*pi*eps0*eps1*3*c^3);

powertop=((Radius^2))*(1/2)*(sqrt(eps0*eps1/(mu0*mu1)))*sum(Fieldtop.*conj(Fieldtop),2)/Po;
powerbottom=((Radius^2))*(1/2)*(sqrt(eps0*eps3/(mu0*mu3)))*sum(FieldBottom.*conj(FieldBottom),2)/Po;

end

end

