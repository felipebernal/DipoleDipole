function valGreen0FarField=Green0FarField(k,rdetect,rsource)

numpoints=size(rdetect,1);
r=sqrt(sum(rdetect.^2,2));
x=rdetect(:,1);
y=rdetect(:,2);
z=rdetect(:,3);
xo=rsource(:,1);
yo=rsource(:,2);
zo=rsource(:,3);
prefactor=zeros(1,1,numpoints);
prefactor(1,1,:)=(exp(1i*k.*r)./(4*pi*r)).*exp(-1i*k*(xo.*x./r + yo.*y./r + zo.*z./r ));

valGreen0FarField=zeros(3,3,numpoints);

valGreen0FarField(1,1,:)=(1-(x.^2)./(r.^2));
valGreen0FarField(2,1,:)=-(x.*y./(r.^2));
valGreen0FarField(3,1,:)=-(x.*z./(r.^2));

valGreen0FarField(1,2,:)=-(x.*y./(r.^2));
valGreen0FarField(2,2,:)=(1-(y.^2)./(r.^2));
valGreen0FarField(3,2,:)=-(y.*z./(r.^2));

valGreen0FarField(1,3,:)=-(x.*z./(r.^2));
valGreen0FarField(2,3,:)=-(y.*z./(r.^2));
valGreen0FarField(3,3,:)=(1-(z.^2)./(r.^2));

valGreen0FarField=valGreen0FarField.*repmat(prefactor,3,3);

%Checked!!!!