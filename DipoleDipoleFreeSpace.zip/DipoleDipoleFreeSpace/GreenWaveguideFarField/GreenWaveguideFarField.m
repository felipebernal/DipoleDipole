function GreenWaveguideFarFieldDyad=GreenWaveguideFarField(k,rdetect,rsource,struct,t)



numpoints=size(rdetect,1);
GreenWaveguideFarFieldDyad=zeros(3,3,numpoints);

cond1=logical(rdetect(:,3)>=0);
cond2=logical(rdetect(:,3)<0 & (rdetect(:,3)+t) >=0 );
cond3=logical((rdetect(:,3)+t) <0 );

if sum(cond1,1)>0%These if's are there just to avoid problems in case there are no values to evaluate with the functions....
    %maybe it works without the if's but better safe than sorry
GreenWaveguideFarFieldDyad(:,:,cond1)=Green0FarField(k,rdetect(cond1,:),rsource(cond1,:))+GreenReflectedFarField(k,rdetect(cond1,:),rsource(cond1,:),struct,t);
%GreenWaveguideFarFieldDyad(:,:,cond1)=GreenReflectedFarField(k,rdetect(cond1,:),rsource(cond1,:),struct,t);

end
if sum(cond2,1)>0
%GreenWaveguideFarFieldDyad(:,:,cond2)=GreenWaveguide(k,rdetect(cond2,:),rsource(cond2,:),struct,t);
GreenWaveguideFarFieldDyad(:,:,cond2)=GreenTransFarField(k,rdetect(cond2,:),rsource(cond2,:),struct,t);

end
if sum(cond3,1)>0
GreenWaveguideFarFieldDyad(:,:,cond3)=GreenTransFarField(k,rdetect(cond3,:),rsource(cond3,:),struct,t);
end

