function valGreenReflectedFarField=GreenReflectedFarField(k,rdetect,rsource,struct,t)

%global t;
%global struct;
c=1;
omega=k*c;
eps0=1;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu0=1;
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

n1=sqrt(eps1*mu1);
n2=sqrt(eps2*mu2);
n3=sqrt(eps3*mu3);

numpoints=size(rdetect,1);
r=sqrt(sum(rdetect.^2,2));
x=rdetect(:,1);
y=rdetect(:,2);
z=rdetect(:,3);
xo=rsource(:,1);
yo=rsource(:,2);
zo=rsource(:,3);

theta=atan2(sqrt(x.^2+y.^2),z);
anglephi=atan2(y,x);

k1=k*sqrt(eps1*mu1);
prefactor=zeros(1,1,numpoints);
prefactor(1,1,:)=((k1^2)/(4*pi*eps0*eps1))*(exp(1i*k1.*r)./r)*...
    (1/(omega^2*mu0*mu1));%This last term converts from E to G 
kR=k1.*sin(theta);



% phi11=exp(-1i*k1.*zo.*cos(theta))+rpg(kR).*exp(1i*k1.*zo.*cos(theta));%Thi
% sis for when you also want the free greens function in the equation.
% phi12=exp(-1i*k1.*zo.*cos(theta))-rpg(kR).*exp(1i*k1.*zo.*cos(theta));
% phi13=exp(-1i*k1.*zo.*cos(theta))+rsg(kR).*exp(1i*k1.*zo.*cos(theta));


phi11=rpg(kR).*exp(1i*k1.*(zo.*cos(theta)-xo.*sin(theta).*cos(anglephi)-yo.*sin(theta).*sin(anglephi)));
phi12=-rpg(kR).*exp(1i*k1.*(zo.*cos(theta)-xo.*sin(theta).*cos(anglephi)-yo.*sin(theta).*sin(anglephi)));
phi13=rsg(kR).*exp(1i*k1.*(zo.*cos(theta)-xo.*sin(theta).*cos(anglephi)-yo.*sin(theta).*sin(anglephi)));



valGreenReflectedFarField=zeros(3,3,numpoints);


valGreenReflectedFarField(1,1,:)=(cos(theta).^2).*(cos(anglephi).^2).*phi12+(sin(anglephi).^2).*phi13;
valGreenReflectedFarField(2,1,:)=(sin(anglephi).*cos(anglephi).*cos(theta).^2).*phi12 -(sin(anglephi).*cos(anglephi)).*phi13;
valGreenReflectedFarField(3,1,:)=-sin(theta).*cos(theta).*cos(anglephi).*phi12;


valGreenReflectedFarField(1,2,:)=(sin(anglephi).*cos(anglephi).*cos(theta).^2).*phi12...
    -(sin(anglephi).*cos(anglephi)).*phi13;
valGreenReflectedFarField(2,2,:)=(cos(theta).^2).*(sin(anglephi).^2).*phi12+(cos(anglephi).^2).*phi13;
valGreenReflectedFarField(3,2,:)=-sin(theta).*cos(theta).*sin(anglephi).*phi12;

valGreenReflectedFarField(1,3,:)=-sin(theta).*cos(theta).*cos(anglephi).*phi11;
valGreenReflectedFarField(2,3,:)=-sin(theta).*cos(theta).*sin(anglephi).*phi11;
valGreenReflectedFarField(3,3,:)=(sin(theta).^2).*phi11;


valGreenReflectedFarField= valGreenReflectedFarField.*repmat(prefactor,3,3);

    function k1zval=k1z(kR,k)
        numkr=size(kR,1);
        tempk1z=sqrt(repmat(eps1*mu1*k^2,numkr,1)-kR.^2);
        k1zval=zeros(numkr,1);
        cond=logical(abs(imag(tempk1z))<k*10^-6);
        k1zval(cond)=tempk1z(cond);
        k1zval(not(cond))=tempk1z(not(cond)).*sign(imag(tempk1z(not(cond))));
        
        %     if abs(imag(tempk1z))<10^-6
        %         k1zval=tempk1z;
        %     else
        %         k1zval=tempk1z*sign(imag(tempk1z));
        %     end
    end

    function k2zval=k2z(kR,k)
        numkr=size(kR,1);
        tempk2z=sqrt(repmat(eps2*mu2*k^2,numkr,1)-kR.^2);
        k2zval=zeros(numkr,1);
        cond=logical(abs(imag(tempk2z))<10^-6);
        k2zval(cond)=tempk2z(cond);
        k2zval(not(cond))=tempk2z(not(cond)).*sign(imag(tempk2z(not(cond))));
        %  if abs(imag(tempk2z))<10^-6
        %         k2zval=tempk2z;
        %     else
        %         k2zval=tempk2z*sign(imag(tempk2z));
        %     end
    end

    function k3zval=k3z(kR,k)
        numkr=size(kR,1);
        tempk3z=sqrt(repmat(eps3*mu3*k^2,numkr,1)-kR.^2);
        k3zval=zeros(numkr,1);
        cond=logical(abs(imag(tempk3z))<10^-6);
        k3zval(cond)=tempk3z(cond);
        k3zval(not(cond))=tempk3z(not(cond)).*sign(imag(tempk3z(not(cond))));
        %     if abs(imag(tempk3z))<10^-6
        %         k3zval=tempk3z;
        %     else
        %         k3zval=tempk3z*sign(imag(tempk3z));
        %     end
    end

    function valrpg=rpg(kR)%This is the generalized reflection p coefficient for the whole layer
        % rs12=rs(mu1,mu2,k1z(kR,k),k2z(kR,k));
        %rs23=rs(mu2,mu3,k2z(kR,k),k3z(kR,k));
        rp12=rp(eps1,eps2,k1z(kR,k),k2z(kR,k));
        rp23=rp(eps2,eps3,k2z(kR,k),k3z(kR,k));
        valrpg=(rp12+rp23.*exp(2*1i*k2z(kR,k).*t))./(1+rp12.*rp23.*exp(2*1i.*k2z(kR,k).*t));
        
    end


    function valrsg=rsg(kR)%This is the generalized reflection s coefficient for the whole layer
        rs12=rs(mu1,mu2,k1z(kR,k),k2z(kR,k));
        rs23=rs(mu2,mu3,k2z(kR,k),k3z(kR,k));
        %rp12=rp(eps1,eps2,k1z(kR,k),k2z(kR,k));
        %rp23=rp(eps2,eps3,k2z(kR,k),k3z(kR,k));
        valrsg=(rs12+rs23.*exp(2*1i.*k2z(kR,k).*t))./(1+rs12.*rs23.*exp(2*1i.*k2z(kR,k).*t));
    end


    function valrp=rp(epsa,epsb,kaz,kbz)
        valrp=(epsb*kaz-epsa*kbz)./(epsb*kaz+epsa*kbz);
    end

    function valrs=rs(mua,mub,kaz,kbz)
        valrs=(mub*kaz-mua*kbz)./(mub*kaz+mua*kbz);
    end


end