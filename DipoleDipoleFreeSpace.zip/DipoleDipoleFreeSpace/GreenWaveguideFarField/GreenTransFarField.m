function valGreenTransFarField=GreenTransFarField(k,rdetect,rsource,struct,t)

%global t;
%global struct;
c=1;
omega=k*c;
eps0=1;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu0=1;
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

n1=sqrt(eps1*mu1);
n2=sqrt(eps2*mu2);
n3=sqrt(eps3*mu3);

numpoints=size(rdetect,1);
r=sqrt(sum(rdetect.^2,2));
x=rdetect(:,1);
y=rdetect(:,2);
z=rdetect(:,3);
xo=rsource(:,1);
yo=rsource(:,2);
zo=rsource(:,3);

k3=k*sqrt(eps3*mu3);
k1=k*sqrt(eps1*mu1);
rho=sqrt(x.^2+y.^2);
kR=k3.*rho./r;

theta=atan2(sqrt(x.^2+y.^2),z);
anglephi=atan2(y,x);


prefactor=zeros(1,1,numpoints);
% prefactor(1,1,:)=((k1^2)/(4*pi*eps0*eps1))*(exp(1i*k3.*(r+t*cos(theta)))./r).*...
%     exp(1i*k1*(zo.*sqrt(1-((n3^2)/(n1^2))*sin(theta).^2)-xo.*sin(theta).*cos(anglephi)-yo.*sin(theta).*sin(anglephi)))*...
%    (1/(omega^2*mu0*mu1));%This last term converts from E to G 


%prefactor(1,1,:)=(1/(4*pi))*(exp(1i*k3.*(r+t*cos(theta)))./r).*...
%    exp(1i*k1*(zo.*sqrt(1-((n3^2)/(n1^2))*sin(theta).^2)-xo.*sin(theta).*cos(anglephi)-yo.*sin(theta).*sin(anglephi)));

prefactor(1,1,:)=(1/(4*pi))*(exp(1i*k3.*(r+t*cos(theta)))./r).*...
    exp(1i*k1*(-xo.*sin(theta).*cos(anglephi)-yo.*sin(theta).*sin(anglephi)));



% 
% phi11=(n3/n1).*(cos(theta)./(sz(theta))).*tpg(kR);
% phi12=-(n3/n1).*tpg(kR);
% phi13=(cos(theta)./(sz(theta))).*tsg(kR);

phi11=(n3/n1).*(cos(theta)./(sz(theta))).*tpg(kR).*exp(1i*k3*zo.*sz(theta));
phi12=-(n3/n1).*tpg(kR).*exp(1i*k3*zo.*sz(theta));
phi13=(cos(theta)./(sz(theta))).*tsg(kR).*exp(1i*k3*zo.*sz(theta));



valGreenTransFarField=zeros(3,3,numpoints);


 
valGreenTransFarField(1,1,:)=(cos(theta).^2).*(cos(anglephi).^2).*phi12+(sin(anglephi).^2).*phi13;
valGreenTransFarField(2,1,:)=(sin(anglephi).*cos(anglephi).*cos(theta).^2).*phi12 -(sin(anglephi).*cos(anglephi)).*phi13;
valGreenTransFarField(3,1,:)=-sin(theta).*cos(theta).*cos(anglephi).*phi12;

valGreenTransFarField(1,2,:)=(sin(anglephi).*cos(anglephi).*cos(theta).^2).*phi12-(sin(anglephi).*cos(anglephi)).*phi13;
    
valGreenTransFarField(2,2,:)=(cos(theta).^2).*(sin(anglephi).^2).*phi12+(cos(anglephi).^2).*phi13;
valGreenTransFarField(3,2,:)=-sin(theta).*cos(theta).*sin(anglephi).*phi12;

valGreenTransFarField(1,3,:)=-sin(theta).*cos(theta).*cos(anglephi).*phi11;
valGreenTransFarField(2,3,:)=-sin(theta).*cos(theta).*sin(anglephi).*phi11;
valGreenTransFarField(3,3,:)=(sin(theta).^2).*phi11;
%  
% valGreenTransFarField(1,1,:)=(cos(theta).^2).*(cos(anglephi).^2).*phi12+(sin(anglephi).^2).*phi13;
% valGreenTransFarField(2,1,:)=(sin(anglephi).*cos(anglephi).*cos(theta).^2).*phi12 -(sin(anglephi).*cos(anglephi)).*phi13;
% valGreenTransFarField(3,1,:)=sin(theta).*cos(theta).*cos(anglephi).*phi12;
% 
% valGreenTransFarField(1,2,:)=(sin(anglephi).*cos(anglephi).*cos(theta).^2).*phi12-(sin(anglephi).*cos(anglephi)).*phi13;
%     
% valGreenTransFarField(2,2,:)=(cos(theta).^2).*(sin(anglephi).^2).*phi12+(cos(anglephi).^2).*phi13;
% valGreenTransFarField(3,2,:)=sin(theta).*cos(theta).*sin(anglephi).*phi12;
% 
% valGreenTransFarField(1,3,:)=sin(theta).*cos(theta).*cos(anglephi).*phi11;
% valGreenTransFarField(2,3,:)=sin(theta).*cos(theta).*sin(anglephi).*phi11;
% valGreenTransFarField(3,3,:)=(sin(theta).^2).*phi11;
% %  

 valGreenTransFarField= valGreenTransFarField.*repmat(prefactor,3,3);
 
 
    function valsz=sz(thet)
                
        valsz=sqrt((n1/n3)^2-sin(thet).^2);
        
    end

 
 function k1zval=k1z(kR,k)
     numkr=size(kR,1);
    tempk1z=sqrt(repmat(eps1*mu1*k^2,numkr,1)-kR.^2);
    
     k1zval=zeros(numkr,1);
    cond=logical(abs(imag(tempk1z))<10^-6);
    k1zval(cond)=tempk1z(cond);
    k1zval(not(cond))=tempk1z(not(cond)).*sign(imag(tempk1z(not(cond))));
    
%     if abs(imag(tempk1z))<10^-6
%         k1zval=tempk1z;
%     else
%         k1zval=tempk1z*sign(imag(tempk1z));
%     end
end

function k2zval=k2z(kR,k)
         numkr=size(kR,1);
 tempk2z=sqrt(repmat(eps2*mu2*k^2,numkr,1)-kR.^2);
  k2zval=zeros(numkr,1);
    cond=logical(abs(imag(tempk2z))<10^-6);
    k2zval(cond)=tempk2z(cond);
    k2zval(not(cond))=tempk2z(not(cond)).*sign(imag(tempk2z(not(cond))));
end

function k3zval=k3z(kR,k)
    numkr=size(kR,1);
 tempk3z=sqrt(repmat(eps3*mu3*k^2,numkr,1)-kR.^2);
  k3zval=zeros(numkr,1);
    cond=logical(abs(imag(tempk3z))<10^-6);
    k3zval(cond)=tempk3z(cond);
    k3zval(not(cond))=tempk3z(not(cond)).*sign(imag(tempk3z(not(cond))));
end
 
    function valtpg=tpg(kR)%This is the generalized transmission p coefficient for the whole layer
       
  numk=size(kR,1);      
        
%rs12=rs(mu1,mu2,k1z(kR,k),k2z(kR,k));
%rs23=rs(mu2,mu3,k2z(kR,k),k3z(kR,k));
rp12=rp(eps1,eps2,k1z(kR,k),k2z(kR,k));
rp23=rp(eps2,eps3,k2z(kR,k),k3z(kR,k));
tp12=tp(eps1,eps2,mu1,mu2,k1z(kR,k),k2z(kR,k));
tp23=tp(eps2,eps3,mu2,mu3,k2z(kR,k),k3z(kR,k));
       

%valtpg=(tp12.*tp23.*exp(1i*k2z(kR,k).*t))./(1+rp12.*rp23.*exp(2*1i.*k2z(kR,k).*t));
 valtpg=zeros(numk,1);
 cond1=logical(abs((1+rp12.*rp23.*exp(2*1i.*k2z(kR,k).*t)))>10^-16&abs((tp12.*tp23.*exp(1i*k2z(kR,k).*t)))>10^-16);
 %cond1=logical(abs((1+rp12.*rp23.*exp(2*1i.*k2z(kR,k).*t)))>10^-16);
 valtpg(cond1,:)=(tp12(cond1,:).*tp23(cond1,:).*exp(1i*k2z(kR(cond1,:),k).*t))./(1+rp12(cond1,:).*rp23(cond1,:).*exp(2*1i.*k2z(kR(cond1,:),k).*t));
 %It was necesary to put this If cause there were ocassions for which both
 %parts tend to zero...at certain angles and we know that i should tend to
 %zero but it was giving NaN numbers....sorry I know I do not explain
 %myself very well but I'm tired and this is the last freaking function
 %that I need to write for this program....I know I will be sorry in a
 %couple of months when I need to read it again and understand it
 %again...!!!!!


    end


    function valtsg=tsg(kR)%This is the generalized reflection s coefficient for the whole layer
        numk=size(kR,1);   
        rs12=rs(mu1,mu2,k1z(kR,k),k2z(kR,k));
        rs23=rs(mu2,mu3,k2z(kR,k),k3z(kR,k));
        ts12=ts(mu1,mu2,k1z(kR,k),k2z(kR,k));
        ts23=ts(mu2,mu3,k2z(kR,k),k3z(kR,k));

%valtsg=(ts12.*ts23.*exp(1i*k2z(kR,k).*t))./(1+rs12.*rs23.*exp(2*1i.*k2z(kR,k).*t));
 valtsg=zeros(numk,1);
 cond1=logical(abs((ts12.*ts23.*exp(1i*k2z(kR,k).*t)))>10^-16&abs((1+rs12.*rs23.*exp(2*1i.*k2z(kR,k).*t)))>10^-16);
 valtsg(cond1,:)=(ts12(cond1,:).*ts23(cond1,:).*exp(1i*k2z(kR(cond1,:),k).*t))./(1+rs12(cond1,:).*rs23(cond1,:).*exp(2*1i.*k2z(kR(cond1,:),k).*t));



    end


    function valrp=rp(epsa,epsb,kaz,kbz)
       valrp=(epsb*kaz-epsa*kbz)./(epsb*kaz+epsa*kbz);
    end

   function valrs=rs(mua,mub,kaz,kbz)
       valrs=(mub*kaz-mua*kbz)./(mub*kaz+mua*kbz);
   end

 
     function valtp=tp(epsa,epsb,mua,mub,kaz,kbz)
       valtp=((2*epsb*kaz)./(epsb*kaz+epsa*kbz))*sqrt((mub*epsa)/(epsb*mua));
     end
    
 function valts=ts(mua,mub,kaz,kbz)
       valts=(2*mub*kaz)./(mub*kaz+mua*kbz);
   end



end