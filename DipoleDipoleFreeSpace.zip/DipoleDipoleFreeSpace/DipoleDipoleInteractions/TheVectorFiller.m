function TheVector = TheVectorFiller(omega, direction,pol,rsource,funE,rdip,muv,epsilonv)
%pol is the polarization of the source.
% This function fills up the vector with the value of the incident field at
%the position of the dipoles.

%This would give us a Ndip x 3 matrix 

%%%%TheVector =funE(omega,direction,pol,rdip,rsource,struct,t);

%We need to reorganize this vector so that we get 3Ndip x 1 vector..where 
%we have dip1x;dip1y;dip1z;dip2x;dip2y;dip2z;....

TheVectortemp =funE(omega,direction,pol,rdip,rsource,muv,epsilonv).';
TheVector =TheVectortemp(:);

