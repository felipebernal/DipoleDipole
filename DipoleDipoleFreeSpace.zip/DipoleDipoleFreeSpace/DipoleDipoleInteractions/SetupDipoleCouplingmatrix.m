function [offdiagcoupled]=SetupDipoleCouplingmatrix(rdip,omega,muv,epsilonv)

%This is for free space
%p = path;
%path(p,'..\WaveguideGreensFunctionv2');
%% now set up the coupling matrix (M in Weber and Ford)
%% Choice to be aware of:
%% matrix first has all the x components (px and Ex at all dipole positions)
%% then all the y components
%% then all the z components

% c0=2.99792458e8;
% eps0=1/(4*pi*1E-7*c0^2) ;        % remember mu0=4*pi*10^-7
% %eps0=1/(4*pi*1E-7*c^2) ;
% eps=eps0*nrefr^2 ;
% v=c/nrefr;
% k=omega/v;

numdipoles=size(rdip,1);
eps0=1;
mu0=1;
mu1=muv;
c=1;
k=omega*sqrt(epsilonv*muv);


offdiagcoupled=zeros(3*numdipoles,3*numdipoles);
%method1
if 1>-1
    for conti=1:numdipoles,
        for contj=1:numdipoles,
            if(conti~=contj),
                rdipi=rdip(conti,:);
                rdipj=rdip(contj,:);
                offdiagcoupled(3*(conti-1)+1:3*conti,3*(contj-1)+1:3*contj)=((omega.^2)*mu0*mu1)*(FreeDyadG(k,rdipi,rdipj));
                %offdiagcoupled(3*(conti-1)+1:3*conti,3*(contj-1)+1:3*contj)=((omega.^2)*mu0*mu1)*FreeDyadG(k,rdipi,rdipj);
                
            end
        end
        
        
    end
    
else
    for conti=1:numdipoles,
        for contj=1+conti:numdipoles,
            if(conti~=contj),
                rdipi=rdip(conti,:);
                rdipj=rdip(contj,:);
                offdiagcoupled(3*(conti-1)+1:3*conti,3*(contj-1)+1:3*contj)=((omega.^2)*mu0*mu1)*(FreeDyadG(k,rdipi,rdipj));
            end
        end
        
        
    end
    
    offdiagcoupled=-(offdiagcoupled+offdiagcoupled.') ;  % copy lower diagonal part
    %there is something very fishy here!!! Felipe comentig a piece of martin's
    %or femiuse's code...they wanted to use reciprocity but something happened.
end

