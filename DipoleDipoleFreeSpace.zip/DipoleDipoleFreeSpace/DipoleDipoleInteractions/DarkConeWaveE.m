function valfunE= DarkConeWaveE(omega,direction,pol,rtoeval,~,muv,epsilonv)
%The magnitude of the field is located in the pol vector
c=1;
numplanewaves=100;
%pol=[1 0 0];
numr=size(rtoeval,1);
normk=(omega/c)*sqrt(muv*epsilonv);

anglerot=linspace(0,2*pi,numplanewaves);
anglerot=anglerot(1:end-1);

direction=direction./norm(direction);


x=direction(1);
y=direction(2);
z=direction(3);
r=sqrt(x^2+y^2);
thet=atan2(r,z);
phi=atan2(y,x);


xpol=pol(1);
ypol=pol(2);
zpol=pol(3);
rpol=sqrt(xpol^2+ypol^2);
Rpol=sqrt(xpol^2+ypol^2+zpol^2);

thetapol=atan2(rpol,zpol);
phipol=atan2(ypol,xpol);


%polip='ppolarized';
polip='twosplanes';
%polip='twoPplanes';
valfunE=zeros(numr,3);
if strcmp(polip,'spolarized')
    for wav=1:numplanewaves-1
        
        %if s polarized
        phirot=anglerot(wav);
        direction=[sin(thet)*cos(phi+phirot),sin(thet)*sin(phi+phirot),cos(thet)];
        pol=Rpol*cross(direction,[0,0,1])/norm(cross(direction,[0,0,1]));
        
        directionrtp=repmat(normk*direction,numr,1);
        kr=sum(directionrtp.*rtoeval,2);
        valueE=exp(1i*kr);
        
        valfunE=valfunE+pol(ones(numr,1),:).*valueE(:,ones(3,1));
        %%%
        % phirot=anglerot(wav);
        % direction=[sin(thet)*cos(phi+phirot),sin(thet)*sin(phi+phirot),cos(thet)];
        % pol=Rpol*[sin(thetapol)*cos(phipol+phirot),sin(thetapol)*sin(phipol+phirot),cos(thetapol)];
        %
        %
        % directionrtp=repmat(normk*direction,numr,1);
        % kr=sum(directionrtp.*rtoeval,2);
        % valueE=exp(1i*kr);
        %
        % valfunE=valfunE+pol(ones(numr,1),:).*valueE(:,ones(3,1));
        %%%
        
    end
    %Finally we use a polarizer in the y direction
    valfunE=[zeros(numr,1),valfunE(:,2),zeros(numr,1)];
elseif strcmp(polip,'ppolarized')
    
    for wav=1:numplanewaves-1
        
        %if p polarized
        phirot=anglerot(wav);
        direction=[sin(thet)*cos(phi+phirot),sin(thet)*sin(phi+phirot),cos(thet)];
        poldir=cross(direction,cross(direction,[0,0,1]));
        pol=Rpol*poldir/norm(poldir);
        
        directionrtp=repmat(normk*direction,numr,1);
        kr=sum(directionrtp.*rtoeval,2);
        valueE=exp(1i*kr);
        
        valfunE=valfunE+pol(ones(numr,1),:).*valueE(:,ones(3,1));
        
        
    end
    %Finally we use a polarizer in the y direction
    valfunE=[zeros(numr,1),valfunE(:,2),zeros(numr,1)];
    
elseif strcmp(polip,'planepolfoucusedpolarized')
    polbefore=pol;
    for wav=1:numplanewaves-1
        
        %if linearly polarized and then focused
        phirot=anglerot(wav);
        direction=[sin(thet)*cos(phi+phirot),sin(thet)*sin(phi+phirot),cos(thet)];
        
        directorvector=[cos(phirot),sin(phirot),0];
        crossdirvector=[sin(phirot),cos(phirot),0];
        
        changecomp=dot(polbefore,directorvector);
        conscomponent=dot(polbefore,crossdirvector);
        
        
        poldir=cross(direction,cross(direction,[0,0,1]));
        
        polafter=changecomp*(poldir/norm(poldir))+conscomponent*crossdirvector;
        
        directionrtp=repmat(normk*direction,numr,1);
        kr=sum(directionrtp.*rtoeval,2);
        valueE=exp(1i*kr);
        
        valfunE=valfunE+polafter(ones(numr,1),:).*valueE(:,ones(3,1));
     
    end
    
   elseif strcmp(polip,'twosplanes')
       
       direction=[sin(thet)*cos(0),sin(thet)*sin(0),cos(thet)];
       
       direction1=direction;
       direction2=[-direction(1),direction(2),direction(3)];
       pol1=pol;
       pol2=[pol(1),pol(2),pol(3)];
       
       directionrtp1=repmat(normk*direction1,numr,1);
       kr1=sum(directionrtp1.*rtoeval,2);
       valueE1=exp(1i*kr1); 
       
       directionrtp2=repmat(normk*direction2,numr,1);
       kr2=sum(directionrtp2.*rtoeval,2);
       valueE2=exp(1i*kr2); 
       
      valfunE= pol1(ones(numr,1),:).*valueE1(:,ones(3,1))+pol2(ones(numr,1),:).*valueE2(:,ones(3,1));
      elseif strcmp(polip,'twoPplanes')
       
       direction=[sin(thet)*cos(pi/2),sin(thet)*sin(pi/2),cos(thet)];
       
       direction1=direction;
       direction2=[direction(1),-direction(2),direction(3)];
       
       pol1=cross(direction1,cross(direction1,[0,0,1]));
       pol2=cross(direction2,cross(direction2,[0,0,1]));
       
       directionrtp1=repmat(normk*direction1,numr,1);
       kr1=sum(directionrtp1.*rtoeval,2);
       valueE1=exp(1i*kr1); 
       
       directionrtp2=repmat(normk*direction2,numr,1);
       kr2=sum(directionrtp2.*rtoeval,2);
       valueE2=exp(1i*kr2); 
       
      valfunE= pol1(ones(numr,1),:).*valueE1(:,ones(3,1))+pol2(ones(numr,1),:).*valueE2(:,ones(3,1));
        
end

%Finally we use a polarizer in the y direction
%valfunE=[zeros(numr,1),valfunE(:,2),zeros(numr,1)];


