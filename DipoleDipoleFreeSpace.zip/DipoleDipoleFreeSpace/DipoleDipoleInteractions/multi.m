function val=multi(a,Rtri2,nodeListTri1,nodeListTri2,rpt,LineNodes,triangle,positions)
val=ones(size(a,1),1);