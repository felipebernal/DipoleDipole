function valfunEDipole= DipoleEFieldLayered(omega,direction,~,rtoeval,rsourcein,struct,t)
% omega is the frequency at which the dipole radiates..
%direction is the orientation of the dipole in x y and z.
%polarization or pol is not used at all...
%rtoeval is the position at which we want to find the E field.
%rsource is the position of the dipole
p = path;
path(p,'..\WaveguideGreensFunctionv2');
%global t;
%global struct;
numpoints=size(rtoeval,1);
%eps1=struct(1,1);
%eps2=struct(2,1);
%eps3=struct(3,1);
mu1=struct(1,2);
%mu2=struct(2,2);
%mu3=struct(3,2);

mu0=1;
c=1;

%pol=[1 0 0];
%numr=size(rtoeval,1);
rsource=repmat(rsourcein,numpoints,1);
direction=repmat(direction./norm(direction),numpoints,1);
k=omega/c;
%pol=pol./norm(pol);
%kpar=Kparfinder(omega,direction);

valfunEDipole=zeros(numpoints,3);

cond1=logical(rtoeval(:,3)>=0);
cond2=logical(rtoeval(:,3)<0 );

if size(rtoeval(cond1,:),1)>0
valfunEDipole=omega^2.*mu0*mu1*multiprod((GreenWaveguide(k,rtoeval,rsource,struct,t)+FreeDyadG(k,rtoeval(cond1,:),rsource(cond1,:))),direction.',[1,2],[1]).';
end

if size(rtoeval(cond2,:),1)>0
valfunEDipole=omega^2.*mu0*mu1*multiprod(GreenWaveguide(k,rtoeval,rsource,struct,t),direction.',[1,2],[1]).';   
end
