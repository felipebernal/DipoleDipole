function [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip)

center=[0,0,0];


directuni=direction/norm(direction);
poluni=pol/norm(pol);
polperpenduni=cross(directuni,pol)/(norm(cross(directuni,pol)));

thetapoints=[0:2*pi/(numberofpoints-1):2*pi].';

% positionsphereparalel=[Radius*cos(thetapoints),0*thetapoints,Radius*sin(thetapoints)];
% positionsphereperpedicular=[Radius*cos(thetapoints),Radius*sin(thetapoints),0*thetapoints];
 

positionsphereparalel=(Radius*cos(thetapoints)*directuni+Radius*sin(thetapoints)*poluni)+repmat(center,numberofpoints,1);
positionsphereperpedicular=(Radius*cos(thetapoints)*directuni+ Radius*sin(thetapoints)*polperpenduni)+repmat(center,numberofpoints,1);

%vecplotparallel=FieldEfinder('scatt','far',positionsphereparalel,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
%vecplotperpedicular=FieldEfinder('scatt','far',positionsphereperpedicular,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
vecplotparallel=FieldEfinder('scatt','far',positionsphereparalel,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
vecplotperpedicular=FieldEfinder('scatt','far',positionsphereperpedicular,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
stes=thetapoints;

%%%%%for part


% center=[0,0,0];
% thetapointsprev=[0:2*pi/(numberofpoints-1):2*pi]';
% totalthetas=size(thetapointsprev,1);
% ndiv=10; %This is the number of divisions of the theta to take.
% numblock=max(gcd(totalthetas,1:ndiv));
% vecplotparallel=zeros(totalthetas,3);
% vecplotperpedicular=zeros(totalthetas,3);
% for thetapointscont=1:numblock
%     
%     thetapoints=thetapointsprev(((thetapointscont-1)*totalthetas/numblock)+1:(thetapointscont)*totalthetas/numblock);
%     positionsphereparalel=[Radius*cos(thetapoints),0*thetapoints,Radius*sin(thetapoints)];
%     positionsphereperpedicular=[Radius*cos(thetapoints),Radius*sin(thetapoints),0*thetapoints];
%     vecplotparallel(((thetapointscont-1)*totalthetas/numblock)+1:(thetapointscont)*totalthetas/numblock,:)=FieldEfinder(1,positionsphereparalel,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,2,LineNodes,triangle,positions);
%     vecplotperpedicular(((thetapointscont-1)*totalthetas/numblock)+1:(thetapointscont)*totalthetas/numblock,:)=FieldEfinder(1,positionsphereperpedicular,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,2,LineNodes,triangle,positions);
%    
% end
%     
    