function valfunE= PlaneWaveELayered(omega,direction,pol,rtoeval,~,struct,t)
% Direction only determines kx and ky and the sign of kz...depending on if
% it goes up or down we choose which refractive index to use for findign
% kz....that makes the program a bit more esy to use.
%This function does not have guided modes....only real kz are possible.
%In this case pol is the polarization in the reference frame of the beam,
%and the plane, like that we avoid cases were people put pol and directions
%that are not perpendicular. so pol has a zero third component wich is th
%edirection of the beam, x is pol totally s polarized and y is polarization p polarized .

%global t;
%global struct;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

c=1;
%pol=[1 0 0];
%numr=size(rtoeval,1);

direction=direction./norm(direction);
pol=pol./norm(pol);

%kpar=Kparfinder(omega,direction);

if direction(3)<0 %incident from medium 1
    normk1L=(omega/c)*sqrt(struct(1,1)*struct(1,2)); %this is omega/c*swrt of wpsilon*mu in the first layer
    kx=direction(1)*normk1L;
    ky=direction(2)*normk1L;
    k1z=sqrt((omega/c)^2*struct(1,1)*struct(1,2)-kx^2-ky^2);
    
    valfunE=pol(1)*E1s(kx,ky,k1z,rtoeval)+pol(2)*E1p(kx,ky,k1z,rtoeval);
    
else   %incident from medium 3
    normk3L=(omega/c)*sqrt(struct(3,1)*struct(3,2)); %this is omega/c*swrt of wpsilon*mu in the first layer
    
    kx=direction(1)*normk3L;
    ky=direction(2)*normk3L;
    k3z=sqrt(((omega/c)^2)*struct(3,1)*struct(3,2)-kx^2-ky^2);
    
    valfunE=pol(1)*E3s(kx,ky,k3z,rtoeval)+pol(2)*E3p(kx,ky,k3z,rtoeval) ;
    
end





    function vecsval=vecs(k)
        kx=k(1);
        ky=k(2);
        kz=k(3);
        if k(1)==0 && k(2)==0
        %this is the condition in case we come strictly from top.
            vecsval=[-1,0,0];
        
        else
            vecsval=(1/sqrt(kx^2+ky^2))*[ky,-kx,0];
        end
        
    end

    function vecpval=vecp(k)
        kx=k(1);
        ky=k(2);
        kz=k(3);
        if k(1)==0 && k(2)==0
            %this is the condition in case we come strictly from top.
        vecpval=[0,1,0];
        else
        vecpval=(1/(sqrt(kx^2+ky^2+abs(kz)^2)*sqrt(kx^2+ky^2)))*[kx*kz,ky*kz,-(kx^2+ky^2)];
        end
    end

    function valE1s=E1s(kx,ky,k1z,rtoeval)
        numpoint=size(rtoeval,1);
        n1=sqrt(struct(1,1)*struct(1,2));
        n2=sqrt(struct(2,1)*struct(2,2));
        n3=sqrt(struct(3,1)*struct(3,2));
        k=(omega/c);
  
        k2z=sqrt(((omega/c)^2)*struct(2,1)*struct(2,2)-kx^2-ky^2);
        k3z=sqrt(((omega/c)^2)*struct(3,1)*struct(3,2)-kx^2-ky^2);
        k1m=[kx,ky,-k1z];
        k2m=[kx,ky,-k2z];
        k3m=[kx,ky,-k3z];
        k1p=[kx,ky,k1z];
        k2p=[kx,ky,k2z];
        k3p=[kx,ky,k3z];
           %this are the rs coefficients
        r12=(mu2*k1z-mu1*k2z)/(mu2*k1z+mu1*k2z);
        r21=(mu1*k2z-mu2*k1z)/(mu2*k1z+mu1*k2z);
        r23=(mu3*k2z-mu2*k3z)/(mu3*k2z+mu2*k3z);
        r32=(mu2*k3z-mu3*k2z)/(mu3*k2z+mu2*k3z);
        t12=(2*mu2*k1z)/(mu2*k1z+mu1*k2z);
        t21=(2*mu2*k1z)/(mu2*k1z+mu1*k2z);
        t23=(2*mu3*k2z)/(mu3*k2z+mu2*k3z);
        t32=(2*mu3*k2z)/(mu3*k2z+mu2*k3z);
        %%%%%%%%%%%%%%%
        R=((r12+r23*exp(2*1i*k2z*t))/(1-r21*r23*exp(2*1i*k2z*t)))*(exp(-1i*k1z*t));
        U=((t12*exp(1i*(k2z-k1z)*t/2))/(1-r21*r23*exp(2*1i*k2z*t)));
        V=(( t12*r23*exp(1i*(3*k2z-k1z)*t/2))/(1-r21*r23*exp(2*1i*k2z*t)));
        T=((t23*t12*exp(1i*(2*k2z-k1z-k3z)*t/2))/(1-r21*r23*exp(2*1i*k2z*t)));
        %A=(1/(2*pi)^(3/2))*sqrt(((omega/c)/k1z));
        A=1;%I prefer amplitude 1 rather than an amplitud that dependds on the direction...
        %the fields will not hold the condition of orthonormality...but who
        %cares in the case of the SIE progam...??
        cond1=logical(rtoeval(:,3)>=0);
        cond2=logical(rtoeval(:,3)<0 & rtoeval(:,3)+t>=0);
        cond3=logical(rtoeval(:,3)+t<0);
        
        rtoeval(:,3)=rtoeval(:,3)+t/2;%this is to match the reference frame choice of urbach&ricken!    
        valE1s=zeros(numpoint,3);
        valE1s(cond1,:)=A*(exp(1i*dotmultivec(k1m,rtoeval(cond1,:)))*vecs(k1m)+R*exp(1i*dotmultivec(k1p,rtoeval(cond1,:)))*vecs(k1p));
        valE1s(cond2,:)=A*(U*exp(1i*dotmultivec(k2m,rtoeval(cond2,:)))*vecs(k2m)+ V*exp(1i*dotmultivec(k2p,rtoeval(cond2,:)))*vecs(k2p));
        valE1s(cond3,:)=A*T*exp(1i*dotmultivec(k3m,rtoeval(cond3,:)))*vecs(k3m); 
        
        %Checked
    end




    function valE1p=E1p(kx,ky,k1z,rtoeval)
        numpoint=size(rtoeval,1);
        
        n1=sqrt(struct(1,1)*struct(1,2));
        n2=sqrt(struct(2,1)*struct(2,2));
        n3=sqrt(struct(3,1)*struct(3,2));
        k=(omega/c);
        k2z=sqrt((omega/c)^2*struct(2,1)*struct(2,2)-kx^2-ky^2);
        k3z=sqrt((omega/c)^2*struct(3,1)*struct(3,2)-kx^2-ky^2);
        k1m=[kx,ky,-k1z];
        k2m=[kx,ky,-k2z];
        k3m=[kx,ky,-k3z];
        k1p=[kx,ky,k1z];
        k2p=[kx,ky,k2z];
        k3p=[kx,ky,k3z];
        
           %these are the rp tp coefficients
        r12=(eps2*k1z-eps1*k2z)/(eps2*k1z+eps1*k2z);
        r21=(eps1*k2z-eps2*k1z)/(eps2*k1z+eps1*k2z);
        r23=(eps3*k2z-eps2*k3z)/(eps3*k2z+eps2*k3z);
        r32=(eps2*k3z-eps3*k2z)/(eps3*k2z+eps2*k3z);
        t12=1+r12;%(2*eps2*k1z)/(eps2*k1z+eps1*k2z);
        t21=1+r21;%(2*eps2*k1z)/(eps2*k1z+eps1*k2z);
        t23=1+r23;%(2*eps3*k2z)/(eps3*k2z+eps2*k3z);
        t32=1+r32;%(2*eps3*k2z)/(eps3*k2z+eps2*k3z);
        %%%%%%%%%%%%%%%
        R=((r12+r23*exp(2*1i*k2z*t))/(1-r21*r23*exp(2*1i*k2z*t)))*(exp(-1i*k1z*t));
        U=((t12*exp(1i*(k2z-k1z)*t/2))/(1-r21*r23*exp(2*1i*k2z*t)));
        V=(( t12*r23*exp(1i*(3*k2z-k1z)*t/2))/(1-r21*r23*exp(2*1i*k2z*t)));
        T=((t23*t12*exp(1i*(2*k2z-k1z-k3z)*t/2))/(1-r21*r23*exp(2*1i*k2z*t)));
        
        
        %A=(1/(2*pi)^(3/2))*sqrt(((omega/c)/k1z));
        A=1;
        cond1=logical(rtoeval(:,3)>=0);
        cond2=logical(rtoeval(:,3)<0 & rtoeval(:,3)+t>=0);
        cond3=logical(rtoeval(:,3)+t<0);
        
        rtoeval(:,3)=rtoeval(:,3)+t/2;%this is to match the reference frame choice of urbach&ricken!
        valE1p=zeros(numpoint,3);
        valE1p(cond1,:)=A*mu1*(exp(1i*dotmultivec(k1m,rtoeval(cond1,:)))*vecp(k1m)   +   R*exp(1i*dotmultivec(k1p,rtoeval(cond1,:)))*vecp(k1p));
        valE1p(cond2,:)=A*mu2*(n1*sqrt(kx^2+ky^2+abs(k2z)^2)/(k*n2^2))*(U*exp(1i*dotmultivec(k2m,rtoeval(cond2,:)))*vecp(k2m)   +   V*exp(1i*dotmultivec(k2p,rtoeval(cond2,:)))*vecp(k2p));
        valE1p(cond3,:)=A*mu3*(n1*sqrt(kx^2+ky^2+abs(k3z)^2)/(k*n3^2))*T*exp(1i*dotmultivec(k3m,rtoeval(cond3,:)))*vecp(k3m);
    %Note: See the multiplication by mu1 mu2 and mu3 in the different
    %layers, these were fudge in in order to match the boundary conditions
    %for magnetic materials...
    end





 function valE3s=E3s(kx,ky,k3z,rtoeval)
        numpoint=size(rtoeval,1);
        n1=sqrt(struct(1,1)*struct(1,2));
        n2=sqrt(struct(2,1)*struct(2,2));
        n3=sqrt(struct(3,1)*struct(3,2));
        k=(omega/c);
        k1z=sqrt((omega/c)^2*struct(1,1)*struct(1,2)-kx^2-ky^2);
        k2z=sqrt((omega/c)^2*struct(2,1)*struct(2,2)-kx^2-ky^2);
        %k3z=sqrt((omega/c)^2*struct(3,1)*struct(3,2)-kx^2-ky^2);
        k1m=[kx,ky,-k1z];
        k2m=[kx,ky,-k2z];
        k3m=[kx,ky,-k3z];
        k1p=[kx,ky,k1z];
        k2p=[kx,ky,k2z];
        k3p=[kx,ky,k3z];
           %these are the rs coefficients
        r12=(mu2*k1z-mu1*k2z)/(mu2*k1z+mu1*k2z);
        r21=(mu1*k2z-mu2*k1z)/(mu2*k1z+mu1*k2z);
        r23=(mu3*k2z-mu2*k3z)/(mu3*k2z+mu2*k3z);
        r32=(mu2*k3z-mu3*k2z)/(mu3*k2z+mu2*k3z);
        t12=1+r12;%(2*mu2*k1z)/(mu2*k1z+mu1*k2z);
        t21=1+r21;%(2*mu1*k2z)/(mu2*k1z+mu1*k2z);
        t23=1+r23;%(2*mu3*k2z)/(mu3*k2z+mu2*k3z);
        t32=1+r32;%(2*mu3*k2z)/(mu3*k2z+mu2*k3z);
        %%%%%%%%%%%%%%%
        U=((t32*exp(1i*(k2z-k3z)*t/2))/(1-r23*r21*exp(2*1i*k2z*t)));
        V=((t32*r21*exp(1i*(3*k2z-k3z)*t/2))/(1-r23*r21*exp(2*1i*k2z*t)));
        T=((t21*t32*exp(1i*(2*k2z-k3z-k1z)*t/2))/(1-r23*r21*exp(2*1i*k2z*t)));
        
        R=((r32+r21*exp(2*1i*k2z*t))/(1-r23*r21*exp(2*1i*k2z*t)))*(exp(-1i*k3z*t));
        %A=(1/(2*pi)^(3/2))*sqrt(((omega/c)/k3z));
         A=1;      
        cond1=logical(rtoeval(:,3)>=0);
        cond2=logical(rtoeval(:,3)<0 & rtoeval(:,3)+t>=0);
        cond3=logical(rtoeval(:,3)+t<0);
        rtoeval(:,3)=rtoeval(:,3)+t/2;%this is to match the reference frame choice of urbach&ricken!    
        
        valE3s=zeros(numpoint,3);
        valE3s(cond1,:)=A*T*(exp(1i*dotmultivec(k1p,rtoeval(cond1,:)))*vecs(k1p));
        valE3s(cond2,:)=A*(U*exp(1i*dotmultivec(k2p,rtoeval(cond2,:)))*vecs(k2p)+V*exp(1i*dotmultivec(k2m,rtoeval(cond2,:)))*vecs(k2m));
        valE3s(cond3,:)=A*(exp(1i*dotmultivec(k3p,rtoeval(cond3,:)))*vecs(k3p)+R*exp(1i*dotmultivec(k3m,rtoeval(cond3,:)))*vecs(k3m)); 
        

   
       end


function valE3p=E3p(kx,ky,k3z,rtoeval)
        numpoint=size(rtoeval,1);
        n1=sqrt(struct(1,1)*struct(1,2));
        n2=sqrt(struct(2,1)*struct(2,2));
        n3=sqrt(struct(3,1)*struct(3,2));
        k=(omega/c);
        k1z=sqrt((omega/c)^2*struct(1,1)*struct(1,2)-kx^2-ky^2);
        k2z=sqrt((omega/c)^2*struct(2,1)*struct(2,2)-kx^2-ky^2);
        %k3z=sqrt((omega/c)^2*struct(3,1)*struct(3,2)-kx^2-ky^2);
        k1m=[kx,ky,-k1z];
        k2m=[kx,ky,-k2z];
        k3m=[kx,ky,-k3z];
        k1p=[kx,ky,k1z];
        k2p=[kx,ky,k2z];
        k3p=[kx,ky,k3z];
           %these are the rp tp coefficients
        r12=(eps2*k1z-eps1*k2z)/(eps2*k1z+eps1*k2z);
        r21=(eps1*k2z-eps2*k1z)/(eps2*k1z+eps1*k2z);
        r23=(eps3*k2z-eps2*k3z)/(eps3*k2z+eps2*k3z);
        r32=(eps2*k3z-eps3*k2z)/(eps3*k2z+eps2*k3z);
        t12=1+r12;%(2*eps2*k1z)/(eps2*k1z+eps1*k2z);
        t21=1+r21;%(2*eps2*k1z)/(eps2*k1z+eps1*k2z);
        t23=1+r23;%(2*eps3*k2z)/(eps3*k2z+eps2*k3z);
        t32=1+r32;%(2*eps3*k2z)/(eps3*k2z+eps2*k3z);
        %%%%%%%%%%%%%%%
        
        U=((t32*exp(1i*(k2z-k3z)*t/2))/(1-r23*r21*exp(2*1i*k2z*t)));
        V=(( t32*r21*exp(1i*(3*k2z-k3z)*t/2))/(1-r23*r21*exp(2*1i*k2z*t)));
        T=((t21*t32*exp(1i*(2*k2z-k3z-k1z)*t/2))/(1-r23*r21*exp(2*1i*k2z*t)));
       
        R=((r32+r21*exp(2*1i*k2z*t))/(1-r23*r21*exp(2*1i*k2z*t)))*(exp(-1i*k3z*t));
         %A=(1/(2*pi)^(3/2))*sqrt(((omega/c)/k3z));
        A=1;
        
        cond1=logical(rtoeval(:,3)>=0);
        cond2=logical(rtoeval(:,3)<0 & rtoeval(:,3)+t>=0);
        cond3=logical(rtoeval(:,3)+t<0);
        
        rtoeval(:,3)=rtoeval(:,3)+t/2;%this is to match the reference frame choice of urbach&ricken!    
        
        valE3p=zeros(numpoint,3);
        valE3p(cond1,:)=A*mu1*(n3*sqrt(kx^2+ky^2+abs(k1z)^2)/(k*n1^2))*T*(exp(1i*dotmultivec(k1p,rtoeval(cond1,:)))*vecp(k1p));
        valE3p(cond2,:)=A*mu2*(n3*sqrt(kx^2+ky^2+abs(k2z)^2)/(k*n2^2))*(U*exp(1i*dotmultivec(k2p,rtoeval(cond2,:)))*vecp(k2p)+V*exp(1i*dotmultivec(k2m,rtoeval(cond2,:)))*vecp(k2m));
        valE3p(cond3,:)=A*mu3*(exp(1i*dotmultivec(k3p,rtoeval(cond3,:)))*vecp(k3p)+R*exp(1i*dotmultivec(k3m,rtoeval(cond3,:)))*vecp(k3m)); 
%Note: See the multiplication by mu1 mu2 and mu3 in the different
    %layers, these were fudge in in order to match the boundary conditions
    %for magnetic materials...
        
end

    function  valdotmultivec=dotmultivec(k,r)
        numeropuntos=size(r,1);
        valdotmultivec=sum(repmat(k,numeropuntos,1).*r,2);
    end







end

