function epsilon=Gold(lambda)
%This is the epsilon of gold as given in a paper that fits the measured
%valeus from jhonson and christy.....
epsinf=1.53;
Lp=145;
gamap=17000;
A1=0.94;
phi1=-pi/4;
L1=468;
gama1=2300;
A2=1.36;
phi2=-pi/4;
L2=331;
gama2=940;

epsilon=epsinf-(1/((Lp^2)*(1./(lambda.^2)+(1i./(gamap*lambda)))))...
    +(A1/L1)*((exp(1i*phi1)/((1/L1)-(1./lambda)-(1i/gama1)))+(exp(-1i*phi1)/((1/L1)+(1./lambda)+(1i/gama1))))...
    +(A2/L2)*((exp(1i*phi2)/((1/L2)-(1./lambda)-(1i/gama2)))+(exp(-1i*phi2)/((1/L2)+(1./lambda)+(1i/gama2))));
