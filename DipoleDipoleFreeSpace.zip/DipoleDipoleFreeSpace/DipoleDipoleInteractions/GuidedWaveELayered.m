function valfunE= GuidedWaveELayered(omega,direction,pol,rtoeval,~,struct,t)
% Direction only determines kx and ky and the sign of kz...depending on if
% it goes up or down we choose which refractive index to use for findign
% kz....that makes the program a bit more esy to use.
%This function does not have guided modes....only real kz are possible.
%In this case pol is the polarization in the reference frame of the beam,
%and the plane, like that we avoid cases were people put pol and directions
%that are not perpendicular. so pol has a zero third component wich is th
%edirection of the beam, x is pol totally s polarized and y is polarization p polarized .
%global t;
%global struct;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

c=1;
%pol=[1 0 0];
%numr=size(rtoeval,1);

direction=direction./norm(direction);
pol=pol./norm(pol);

%kpar=Kparfinder(omega,direction);
k=omega/c;






%if you want to se antysimetric modes or a sum of symetric modes then you jsut need to change this
[betaS,simetryS,Ms]=SolutionsSpolarizedGuidedModes(k,t,struct)
[betaP,simetryP,Mp]=SolutionsPpolarizedGuidedModes(k,t,struct)


MODENUMBERS=1; %We would like to see only the first symetrical (not antysimetrycal!!) mode from the layer!!!!
MODENUMBERP=1;

% checker=0;
% simetryS
% while checker==0
% if simetryS(MODENUMBERS)==1
% checker=1;
% else
%     MODENUMBERS=MODENUMBERS+1;
%     MODENUMBERS
% end
% end
% 
% checker=0;
 %simetryP
% while checker==0
% if simetryP(MODENUMBERP)==1
% checker=1;
% else
%     MODENUMBERP=MODENUMBERP+1;
%     MODENUMBERP
% end
% end




theta=atan2(direction(2),direction(1));

kxS=betaS.*cos(theta);
kyS=betaS.*sin(theta);
kxP=betaP.*cos(theta);
kyP=betaP.*sin(theta);
if Ms>0&&Mp>0
    valfunE=pol(1)*GE1s(kxS(MODENUMBERS),kyS(MODENUMBERS),rtoeval)+pol(2)*GE1p(kxP(MODENUMBERP),kyP(MODENUMBERP),rtoeval);
elseif Ms>0
    valfunE=pol(1)*GE1s(kxS(MODENUMBERS),kyS(MODENUMBERS),rtoeval);
elseif Mp>0
    valfunE=pol(2)*GE1p(kxP(MODENUMBERP),kyP(MODENUMBERP),rtoeval);
else
    valfunE=zeros(size(rtoeval,1),3);
    disp('There were no guided modes for this structure at this frequency')
end
    function vecsval=vecs(k)
        kx=k(1);
        ky=k(2);
        kz=k(3);
        if k(1)==0 && k(2)==0
            %this is the condition in case we come strictly from top.
            vecsval=[-1,0,0];
            
        else
            vecsval=(1/sqrt(kx^2+ky^2))*[ky,-kx,0];
        end
        
    end

    function vecpval=vecp(k)
        kx=k(1);
        ky=k(2);
        kz=k(3);
        if k(1)==0 && k(2)==0
            %this is the condition in case we come strictly from top.
            vecpval=[0,1,0];
        else
            vecpval=(1/(sqrt(kx^2+ky^2+abs(kz)^2)*sqrt(kx^2+ky^2)))*[kx*kz,ky*kz,-(kx^2+ky^2)];
        end
    end

    function valGE1s=GE1s(kx,ky,rtoeval)
        numpoint=size(rtoeval,1);
        n1=sqrt(struct(1,1)*struct(1,2));
        n2=sqrt(struct(2,1)*struct(2,2));
        n3=sqrt(struct(3,1)*struct(3,2));
        k=(omega/c);
        
        k1z=sqrt(((omega/c)^2)*struct(1,1)*struct(1,2)-kx^2-ky^2);
        k2z=sqrt(((omega/c)^2)*struct(2,1)*struct(2,2)-kx^2-ky^2);
        k3z=sqrt(((omega/c)^2)*struct(3,1)*struct(3,2)-kx^2-ky^2);
        
        k1m=[kx,ky,-k1z];
        k2m=[kx,ky,-k2z];
        k3m=[kx,ky,-k3z];
        k1p=[kx,ky,k1z];
        k2p=[kx,ky,k2z];
        k3p=[kx,ky,k3z];
        %this are the rs coefficients
        %         r12=(mu2*k1z-mu1*k2z)/(mu2*k1z+mu1*k2z);
        r21=(mu1*k2z-mu2*k1z)/(mu2*k1z+mu1*k2z);
        r23=(mu3*k2z-mu2*k3z)/(mu3*k2z+mu2*k3z);
        %         r32=(mu2*k3z-mu3*k2z)/(mu3*k2z+mu2*k3z);
        
        %         t12=(2*mu2*k1z)/(mu2*k1z+mu1*k2z);
        %         t13=(2*mu3*k1z)/(mu3*k1z+mu1*k3z);
        
        t21=(2*mu1*k2z)/(mu2*k1z+mu1*k2z);
        t23=(2*mu3*k2z)/(mu3*k2z+mu2*k3z);
        %         t32=(2*mu3*k2z)/(mu3*k2z+mu2*k3z);
        %%%%%%%%%%%%%%%
        
        T1=t21*exp(1i*(k2z-k1z)*t/2);
        T3=(t23/r23)*exp(-1i*(k2z+k3z)*t/2);
        V=r21*exp(1i*k2z*t);
        
        %A=(1/(2*pi)^(3/2))*sqrt(((omega/c)/k1z));
        A=1;%I prefer amplitude 1 rather than an amplitud that dependds on the direction...
        %the fields will not hold the condition of orthonormality...but who
        %cares in the case of the SIE progam...??
        cond1=logical(rtoeval(:,3)>=0);
        cond2=logical(rtoeval(:,3)<0 & rtoeval(:,3)+t>=0);
        cond3=logical(rtoeval(:,3)+t<0);
        
        rtoeval(:,3)=rtoeval(:,3)+t/2;%this is to match the reference frame choice of urbach&ricken!
        valGE1s=zeros(numpoint,3);
        valGE1s(cond1,:)=A.*T1.*exp(1i*dotmultivec(k1p,rtoeval(cond1,:)))*vecs(k1p);
        valGE1s(cond2,:)=A*(exp(1i*dotmultivec(k2p,rtoeval(cond2,:)))*vecs(k2p)+ V*exp(1i*dotmultivec(k2m,rtoeval(cond2,:)))*vecs(k2m));
        valGE1s(cond3,:)=A*T3*exp(1i*dotmultivec(k3m,rtoeval(cond3,:)))*vecs(k3m);
        
        
    end




    function valGE1p=GE1p(kx,ky,rtoeval)
        numpoint=size(rtoeval,1);
        
        n1=sqrt(struct(1,1)*struct(1,2));
        n2=sqrt(struct(2,1)*struct(2,2));
        n3=sqrt(struct(3,1)*struct(3,2));
        k=(omega/c);
        
        k1z=sqrt((k^2)*struct(1,1)*struct(1,2)-kx^2-ky^2);
        k2z=sqrt(k^2*struct(2,1)*struct(2,2)-kx^2-ky^2);
        k3z=sqrt(k^2*struct(3,1)*struct(3,2)-kx^2-ky^2);
        %         k1m=[kx,ky,-k1z];
        k2m=[kx,ky,-k2z];
        k3m=[kx,ky,-k3z];
        k1p=[kx,ky,k1z];
        k2p=[kx,ky,k2z];
        %         k3p=[kx,ky,k3z];
        
        %these are the rp tp coefficients
        %r12=(eps2*k1z-eps1*k2z)/(eps2*k1z+eps1*k2z);
        r21=(eps1*k2z-eps2*k1z)/(eps2*k1z+eps1*k2z);
        r23=(eps3*k2z-eps2*k3z)/(eps3*k2z+eps2*k3z);
        %r32=(eps2*k3z-eps3*k2z)/(eps3*k2z+eps2*k3z);
        %t12=1+r12;%(2*eps2*k1z)/(eps2*k1z+eps1*k2z);
        %t21=...1+r21;%
        %(2*eps1*k2z)/(eps2*k1z+eps1*k2z);
        t21=(2*eps1*k2z)/(eps2*k1z+eps1*k2z);
        
         
         t23=...1+r23;%
            (2*eps3*k2z)/(eps2*k3z+eps3*k2z);
        %t32=1+r32;%(2*eps3*k2z)/(eps3*k2z+eps2*k3z);
        %%%%%%%%%%%%%%%
        T1=t21*exp(1i*(k2z-k1z)*t/2);
        %T1=eps3/eps2*t21*exp(1i*(k2z-k1z)*t/2);
        T3=(t23/r23)*exp(-1i*(k2z+k3z)*t/2);
        V=r21*exp(1i*k2z*t);
        
      
        
        %A=(1/(2*pi)^(3/2))*sqrt(((omega/c)/k1z));
        A=1;
        cond1=logical(rtoeval(:,3)>=0);
        cond2=logical(rtoeval(:,3)<0 & rtoeval(:,3)+t>=0);
        cond3=logical(rtoeval(:,3)+t<0);
        
        rtoeval(:,3)=rtoeval(:,3)+t/2;%this is to match the reference frame choice of urbach&ricken!
        valGE1p=zeros(numpoint,3);
        valGE1p(cond1,:)=mu1*A*(n2*(sqrt(kx^2+ky^2+abs(k1z)^2))/(n1^2*k)).*T1.*exp(1i*dotmultivec(k1p,rtoeval(cond1,:)))*vecp(k1p);
        valGE1p(cond2,:)=mu2*A*(exp(1i*dotmultivec(k2p,rtoeval(cond2,:)))*vecp(k2p)+ V*exp(1i*dotmultivec(k2m,rtoeval(cond2,:)))*vecp(k2m));
        valGE1p(cond3,:)=mu3*A*(n2*(sqrt(kx^2+ky^2+abs(k3z)^2))/(n3^2*k))*T3*exp(1i*dotmultivec(k3m,rtoeval(cond3,:)))*vecp(k3m);
        
        
        
        
        
        
        %Note: See the multiplication by mu1 mu2 and mu3 in the different
        %layers, these were fudge in in order to match the boundary conditions
        %for magnetic materials...
    end




    function  valdotmultivec=dotmultivec(k,r)
        numeropuntos=size(r,1);
        valdotmultivec=sum(repmat(k,numeropuntos,1).*r,2);
    end


    function [betaS,simetryS,Ms]=SolutionsSpolarizedGuidedModes(k,t,struct)
        c=1;
        omega=k/c;
        lambda=2*pi/k;
        n1=sqrt(struct(1,1)*struct(1,2));
        n2=sqrt(struct(2,1)*struct(2,2));
        n3=sqrt(struct(3,1)*struct(3,2));
        k1zf= @(beta) sqrt(repmat(k^2,size(beta,1),1)*n1^2-beta.^2);
        k2zf=@(beta) sqrt(repmat(k^2,size(beta,1),1)*n2^2-beta.^2);
        k3zf= @(beta) sqrt(repmat(k^2,size(beta,1),1)*n3^2-beta.^2);
        
        %Check if you have already looked for the solutions
        %If you have then just load the file with the different values
        %for beta.
        %If you have not then solve the equation and find all the
        %solutions..and voila..!
        
        sepsa=int2str(struct(1,1)*100);
        sepsb=int2str(struct(2,1)*100);
        sepsc=int2str(struct(3,1)*100);
        smua=int2str(struct(1,2)*100);
        smub=int2str(struct(2,2)*100);
        smuc=int2str(struct(3,2)*100);
        
        identifiername=[sepsa,sepsb,sepsc,smua,smub,smuc,'t',int2str(t*100),'L',int2str(lambda*1000)];
        namefile=['\\nanorfsrv\Users\Bernal\Simulations\LayeredGuidedModes\',identifiername,'SolutionsBetaS.mat'];
        
        if exist(namefile)==2
            
            BetasSaved=load(namefile);
            betaS=BetasSaved.betaS;
            simetryS=BetasSaved.simetryS;
            Ms=BetasSaved.Ms;
            
            
            %save(namefile,'struct','lambda','Greenscube','R','ZDet','Zsour','step','vectorconditions');
        else
            disp('Finding the S guided modes! you had not done it before for this structure or this wavelength');
            disp('If the last statement is false then just check in which folder is the program looking for your previous work. check in GuidedwaveELayered');
            
            if n3>=n1
                Ms=max([0,1+floor((k*t/pi)*sqrt(n2^2-n3^2)-(1/pi)*atan(sqrt((n3^2-n1^2)/(n2^2-n3^2))))]);%This is the number of solutions that we have to find
            else
                Ms=max([0,1+floor((k*t/pi)*sqrt(n2^2-n1^2)-(1/pi)*atan(sqrt((n1^2-n3^2)/(n2^2-n1^2))))]);%This is the number of solutions that we have to find
            end
            %eqS= @(beta) tan(k2zf(beta)*t)-(k2zf(beta).*(abs(k3zf(beta))+abs(k1zf(beta)))./(k2zf(beta).^2-(abs(k3zf(beta)).*abs(k1zf(beta)))));
           eqS= @(beta) tan(k2zf(beta)*t)-((k2zf(beta)/mu2).*((abs(k3zf(beta))/mu3)+(abs(k1zf(beta))/mu1))./((k2zf(beta).^2/mu2^2)-((abs(k3zf(beta)).*abs(k1zf(beta))./(mu3*mu1)))));
            if Ms>=1
                maxite=30;
                icont=0;
                cont=1;
                icont2=2;
                sol=-ones(Ms,1);
                step=((k*n2-k*max([n3,n1]))/(Ms/2))/icont2;
                while cont<=Ms && icont2<=maxite
                    
                    rootby=k*max([n3,n1])+icont*step;
                    if rootby>=k*n2&&icont2<maxite
                        icont=0;
                        sol=zeros(Ms,1);
                        cont=1;
                        icont2=icont2+1;
                        step=((k*n2-k*max([n3,n1]))/(Ms))/icont2;
                        rootby=k*max([n3,n1])+icont*step;
                        [temp,fval,flag]=fsolve(eqS,rootby);
                    elseif rootby>=k*n2&&icont2==maxite
                        icont2=icont2+1;
                    elseif rootby<k*n2
                         [temp,fval,flag]=fsolve(eqS,rootby);
                        
                    end
                     %[temp,fval,flag]=fzero(eqS,rootby);%This part finds the root around by rootby                      
                    
%                     disp('is rootby too big?')
%                     k
%                     n2
%                     k*n2
%                     rootby
%                     rootby>=k*n2
%                     disp('is it too small?')
%                     k*max([n3,n1])
%                     rootby
%                     rootby<k*max([n3,n1])
%                     disp('in which iteration are you?')
%                     icont
%                      disp('what is rootby?')
%                     rootby
%             
                    
                    %eqS(temp)
                    if cont==1&&real(temp)<k*n2&&real(temp)>k*max([n3,n1])&&imag(temp)==0&&abs(eqS(temp))<10^-6
                        sol(cont)=temp;
                        cont=cont+1;
                        icont=icont+1;
                    elseif cont~=1&&(real(temp)-real(sol(cont-1)))>10^(-7)*k&&real(temp)<k*n2&&real(temp)>k*max([n3,n1])&&imag(temp)==0&&abs(eqS(temp))<10^-6
                        sol(cont)=temp;
                        cont=cont+1;
                        icont=icont+1;
                    else
                        icont=icont+1;
                        
                    end
                end
                %This while does not assure that you will find all possible guided modes...also it is not the best method...and it requires a lot of
                %time and it will not use the already found solutions....so it is a crap of a method...I know.....
                %BUUUUUTTTTT it assures you tried hard!
                %and it used to work quite well in the past for at least 60 modes...had not tried more...than that though
                disp([int2str(cont-1),' modes out of ',int2str(Ms),' were found, after ',int2str(icont2-1), ' iteration(s). ']);
                %disp(['the posible betas are: ',int2str(100000*sol),'/100000']);
                betaS=sol;
                
                k1z=k1zf(betaS);
                k2z=k2zf(betaS);
                k3z=k3zf(betaS);
                
                r21=(mu1.*k2z-mu2.*k1z)./(mu2.*k1z+mu1.*k2z);
                %r23=(mu3*k2z-mu2*k3z)/(mu3*k2z+mu2*k3z);
                
                simetryS=sign(real(r21.*exp(1i.*k1z.*t)));
                save(namefile,'betaS','simetryS','Ms');
            else
                %don't even try, there are no guided modes in S
                betaS=0;
                simetryS=0;
                disp(' No s modes');
                save(namefile,'betaS','simetryS','Ms');
            end
            
        end
        
    end

    function [betaP,simetryP,Mp]=SolutionsPpolarizedGuidedModes(k,t,struct)
        omega=k/c;
        lambda=2*pi/k;
        eps1=struct(1,1);
        eps2=struct(2,1);
        eps3=struct(3,1);
        n1=sqrt(struct(1,1)*struct(1,2));
        n2=sqrt(struct(2,1)*struct(2,2));
        n3=sqrt(struct(3,1)*struct(3,2));
        k1zf= @(beta) sqrt(repmat(k^2,size(beta,1),1)*n1^2-beta.^2);
        k2zf=@(beta) sqrt(repmat(k^2,size(beta,1),1)*n2^2-beta.^2);
        k3zf= @(beta) sqrt(repmat(k^2,size(beta,1),1)*n3^2-beta.^2);
        
        %Check if you have already looked for the solutions
        %If you have then just load the file with the different values
        %for beta.
        %If you have not then solve the equation and find all the
        %solutions..and voila..!
        
        
        sepsa=int2str(struct(1,1)*100);
        sepsb=int2str(struct(2,1)*100);
        sepsc=int2str(struct(3,1)*100);
        smua=int2str(struct(1,2)*100);
        smub=int2str(struct(2,2)*100);
        smuc=int2str(struct(3,2)*100);
        
        identifiername=[sepsa,sepsb,sepsc,smua,smub,smuc,'t',int2str(t*100),'L',int2str(lambda*1000)];
        namefile=['\\nanorfsrv\Users\Bernal\Simulations\LayeredGuidedModes\',identifiername,'SolutionsBetaP.mat'];
        
        if exist(namefile)==2
            
            BetasSaved=load(namefile);
            betaP=BetasSaved.betaP;
            simetryP=BetasSaved.simetryP;
            Mp=BetasSaved.Mp;
            
            %save(namefile,'struct','lambda','Greenscube','R','ZDet','Zsour','step','vectorconditions');
        else
            disp('Finding the P guided modes! you had not done it before for this structure or this wavelength');
            disp('If the last statement is false then just check in which folder is the program looking for your previous work. check in GuidedwaveELayered');
            
            if n3>=n1
                Mp=max([0,1+floor((k*t/pi)*sqrt(n2^2-n3^2)-(1/pi)*atan((n2^2/n1^2)*sqrt((n3^2-n1^2)/(n2^2-n3^2))))]);%This is the number of solutions that we have to find
            else
                Mp=max([0,1+floor((k*t/pi)*sqrt(n2^2-n1^2)-(1/pi)*atan((n2^2/n3^2)*sqrt((n1^2-n3^2)/(n2^2-n1^2))))]);%This is the number of solutions that we have to find
            end
            
            eqP= @(beta) tan(k2zf(beta)*t)-((k2zf(beta)/eps2).*((abs(k3zf(beta))/eps3)+(abs(k1zf(beta))/eps1))./((k2zf(beta).^2/eps2^2)-((abs(k3zf(beta)).*abs(k1zf(beta))./(eps3*eps1)))));
            
            if Mp>=1
                maxite=30;
                icont=0;
                cont=1;
                icont2=2;
                sol=-ones(Mp,1);
                step=((k*n2-k*max([n3,n1]))/(Mp))/icont2;
                while cont<=Mp && icont2<=maxite
                    
                    
                    rootby=k*max([n3,n1])+icont*step;
                    
                    if rootby>=k*n2&&icont2<=(maxite-1)
                        icont=0;
                        sol=zeros(Mp,1);
                        cont=1;
                        icont2=icont2+1;
                        step=((k*n2-k*max([n3,n1]))/(Mp))/icont2;
                        rootby=k*max([n3,n1])+icont*step; 
                        [temp,fval,flag]=fsolve(eqP,rootby);
                    elseif rootby>=k*n2&&icont2==maxite
                        icont2=icont2+1;
                    elseif rootby<k*n2
                         [temp,fval,flag]=fsolve(eqP,rootby);
                        
                    end
                                                  
                     %[temp,fval,flag]=fzero(eqP,rootby);%This part finds the root around by rootby
                   
%if flag==-4
%                          icont
%                          icont2
%                          cont
%                          sol
%                      end
                                    
                    if cont==1&&real(temp)<k*n2&&real(temp)>k*max([n3,n1])&&imag(temp)==0&&abs(eqP(temp))<10^-6
                        sol(cont)=temp;
                        cont=cont+1;
                        icont=icont+1;
                    elseif cont~=1&&(real(temp)-real(sol(cont-1)))>10^(-10)*k&&real(temp)<k*n2&&real(temp)>k*max([n3,n1])&&imag(temp)==0&&abs(eqP(temp))<10^-6
                        sol(cont)=temp;
                        cont=cont+1;
                        icont=icont+1;
                    else
                        icont=icont+1;
                        
                    end
                end
                %This while does not assure that you will find all possible guided modes...but it assures you tried hard!
                %and it used to work quite well in the past for at least 60 modes...had not tried more...than that though
                disp([int2str(cont-1),' modes out of ',int2str(Mp),' were found, after ',int2str(icont2-1), ' iteration(s)']);
                %eqP(sol)
                betaP=sol;
                
                k1z=k1zf(betaP);
                k2z=k2zf(betaP);
                k3z=k3zf(betaP);
                
                r21=(eps1.*k2z-eps2.*k1z)./(eps2.*k1z+eps1.*k2z);
                %r23=(mu3*k2z-mu2*k3z)/(mu3*k2z+mu2*k3z);
                
                simetryP=sign(real(r21.*exp(1i*k1z*t)));
                %eqP(sol)
                save(namefile,'betaP','simetryP','Mp');
            else
                %don't even try, there are no guided modes in P
                betaP=0;
                simetryP=0;
                disp(' No P modes');
                save(namefile,'betaP','simetryP','Mp');
            end
            
        end
        
    end

end

