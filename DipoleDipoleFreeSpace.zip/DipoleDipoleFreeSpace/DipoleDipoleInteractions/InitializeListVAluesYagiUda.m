function [w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip)

%%
% a=75E-9;  %%%% radius long axis
% b=15E-9;  %%% radius short axis
% w0=4.76E15;  %%%% resonance frequency
% 
% gamma=8.3E13;  %% Ohmic damping frequency
% %gamma=0;
c=1;

if Ndip==5


%lambdas=[0.65;0.6;0.6;0.6;0.6];
  %lambdas=[0.8;0.62;0.62;0.62;0.62];
  lambdas=[0.85;0.63;0.63;0.63;0.63];
  
% w0list=2*pi*(c./lambdas);
% alist=[0.155;0.125;0.115;0.115;0.115];
% blist=[0.03;0.03;0.03;0.03;0.03];
% %gammalist=[0.405;0.405;0.405;0.405;0.405];
% gammalist=[0.000000001;0.000000001;0.000000001;0.000000001;0.000000001];
% lambdas=[0.5;0.49;0.43;0.43;0.43];
% 
w0list=2*pi*(c./lambdas);
alist=[0.155/2;0.125/2;0.115/2;0.115/2;0.115/2];
blist=[0.03;0.03;0.03;0.03;0.03];
%gammalist=[0.405;0.405;0.405;0.405;0.405];
gammalist=[0.1;0.1;0.1;0.1;0.1];

% %%maximum coupling for free space
% lambdas=[0.6;0.6;0.6;0.6;0.6];
% 
% w0list=2*pi*(c./lambdas);
% alist=[0.05;0.05;0.05;0.05;0.05];
% blist=[0.03;0.03;0.03;0.03;0.03];
% %gammalist=[0.405;0.405;0.405;0.405;0.405];
% gammalist=[0.1;0.1;0.1;0.1;0.1];


% lambdas=[0.52;0.51;0.5;0.5;0.5];
% 
% w0list=2*pi*(c./lambdas);
% alist=[0.155/2;0.125/2;0.115/2;0.115/2;0.115/2];
% blist=[0.06/2;0.06/2;0.06/2;0.06/2;0.06/2];
% %gammalist=[0.405;0.405;0.405;0.405;0.405];
% gammalist=[0.1;0.1;0.1;0.1;0.1];
% 


elseif Ndip==1

  lambdas=0.6;%this is in microns
% 
% %lambdas=0.8;%this is in microns
 w0list=2*pi*(c./lambdas);
alist=0.05;
blist=0.03;

%alist=0.035;
%blist=0.035;

% %blist=0.06;
% alist=0.071;
% blist=0.071;

gammalist=0.1;
%gammalist=0.000000001;


 %gammalist=0.00001;
  %gammalist=0;


elseif Ndip==2

lambdas=[0.6;0.6];%this is in microns
w0list=2*pi*(c./lambdas);
alist=[0.035;0.035];
blist=[0.035;0.035];
% alist=[0.044;0.044];
% blist=[0.044;0.044];
gammalist=[0.1;0.1];
%gammalist=[0;0];
% lambdas=[0.2;0.2];%this is in microns
% w0list=2*pi*(c./lambdas);
% alist=[0.125;0.125];
% blist=[0.030000001,0.030000001];
% gammalist=[0.7,0.7];
elseif Ndip==3
%lambdas=0.800;%this is in microns

% lambdas=0.8;%this is in microns
% w0list=2*pi*(c./lambdas);
% alist=0.155;
% blist=0.04;
% gammalist=1.9;
lambdas=[0.6;0.6;0.6];%this is in microns
w0list=2*pi*(c./lambdas);
alist=[0.05;0.05;0.05];
blist=[0.03;0.03;0.03];
gammalist=[0.1;0.1;0.1];
elseif Ndip==4
%lambdas=0.800;%this is in microns

% lambdas=0.8;%this is in microns
% w0list=2*pi*(c./lambdas);
% alist=0.155;
% blist=0.04;
% gammalist=1.9;
lambdas=[0.6;0.6;0.6;0.6];%this is in microns
w0list=2*pi*(c./lambdas);
alist=[0.05;0.05;0.05;0.05];
blist=[0.03;0.03;0.03;0.03];
gammalist=[0.1;0.1;0.1;0.1];
end
    