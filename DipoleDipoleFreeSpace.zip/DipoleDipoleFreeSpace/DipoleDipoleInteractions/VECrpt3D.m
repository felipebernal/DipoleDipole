%this function takes any list of 3-vectors and repeats them n times
%e.g. v=[1 2 3;4 5 6;7 8 9;] and you need to repeat it 3 times then:
%it will look like vrpt=[1 2 3;1 2 3;1 2 3;4 5 6;4 5 6;4 5 6;7 8 9;7 8 9;7 8 9;]

function valrptvec= VECrpt3D(vec,rpt)

line1=vec(:,1);
line2=vec(:,2);
line3=vec(:,3);
line1=line1(:,ones(rpt,1));
line2=line2(:,ones(rpt,1));
line3=line3(:,ones(rpt,1));
line1=line1.';
line2=line2.';
line3=line3.';
valrptvec=[line1(:),line2(:),line3(:)];
