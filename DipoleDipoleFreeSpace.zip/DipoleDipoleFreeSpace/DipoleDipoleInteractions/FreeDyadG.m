function dyadG=FreeDyadG(k,rdetect,rsource)

rvec=rdetect-rsource;
numpoints=size(rvec,1);
r=sqrt(rvec(:,1).^2+rvec(:,2).^2+rvec(:,3).^2); 
dyadG=zeros(3,3,numpoints);
F1=exp(1i*k*r)./(4*pi*r);
%MatIdentityGo=eye(3)*F1;
F2=exp(1i*k*r)./(4*pi*r.^5);
aux1=((r.^2).*(-1+1i*k*r));
aux2=-(-3+k*r.*(3*1i+k*r));
dyadG(1,1,:)=F1+(1/k^2).*F2.*(aux1+aux2.*rvec(:,1).^2);
dyadG(1,2,:)=(1/k^2).*F2.*aux2.*rvec(:,1).*rvec(:,2);
dyadG(1,3,:)=(1/k^2).*F2.*aux2.*rvec(:,1).*rvec(:,3);
dyadG(2,1,:)=(1/k^2).*F2.*aux2.*rvec(:,1).*rvec(:,2);
dyadG(2,2,:)=F1+(1/k^2).*F2.*(aux1+aux2.*rvec(:,2).^2);
dyadG(2,3,:)=(1/k^2).*F2.*aux2.*rvec(:,2).*rvec(:,3);
dyadG(3,1,:)=(1/k^2).*F2.*aux2.*rvec(:,3).*rvec(:,1);
dyadG(3,2,:)=(1/k^2).*F2.*aux2.*rvec(:,2).*rvec(:,3);
dyadG(3,3,:)=F1+(1/k^2).*F2.*(aux1+aux2.*rvec(:,3).^2);




% % function [scalG dyadG]=FreeDyadG(k,rvec)
% % A=1/(4*pi); %% remove 4pi to match de Abajo, and to get G in the (E,ZoH) unit system
% % 
% % r=norm(rvec); 
% %  
% %  
% % F=A*exp(1i*k*r)/r;
% %  
% % DF=(1i*k*r-1)*F/r^2;
% % DDF=-(k^2*r^2+3*1i*k*r-3)/r^4*F;
% % 
% % %rvec=reshape(rvec,1,3);
% % %aux1=rvec'*rvec;
% % %diagmat=(k^2*F+DF)*eye(3)+DDF*aux1;
% % 
% % %aux2=[0 -rvec(3) rvec(2); rvec(3) 0 -rvec(1); -rvec(2) rvec(1) 0];
% % %offdiagmat=-i*k*DF*aux2;
% % scalG=F;
% % %dyadG=[diagmat  -offdiagmat; offdiagmat diagmat];
% % 
% % 
% % aux1=k^2*eye(6);
% % aux2a=-i*k*[0 rvec(3) -rvec(2); -rvec(3),0,rvec(1); rvec(2) -rvec(1) 0];
% % 
% % 
% % aux2=[eye(3) aux2a;-aux2a eye(3)];
% % rvec=reshape(rvec,3,1);
% % 
% % aux3a=rvec*rvec';
% % aux3=[aux3a zeros(3); zeros(3) aux3a];
% % 
% % dyadG=(aux1*F + (aux2*DF+aux3*DDF));   %% verified diagonal matrices GEE and GHH against Linton / Mathematica
% % 
% % 
% % 
% % %% verified against two different mathematica
% % %% implementations of G(r,r')
% % 
% %  
% % 
% % %%% note: the 1/r term is e^ikr * k^2/4pi
% %  end