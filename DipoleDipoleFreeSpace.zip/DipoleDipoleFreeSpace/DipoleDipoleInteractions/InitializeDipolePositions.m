function [rdip]=InitializeDipolePositions(Ndip,dist,model)
%% routine that places n dipoles, given a certain model
%%
%% Model 'z-line':  A periodic finite chain along the z-axis
%% Model 'x-line':  A periodic finite chain along the x-axis
%% Model 'oligomer': Arrangement of 7 particles in xy plane with central
%% particle on x,y=0,0; input Ndip ignored
%% particle numbering as follows:
%% particle 1: top left
%% particle 2: top right
%% particle 3: left
%% particle 4: central
%% particle 5: right
%% particle 6: bottom left
%% particle 7: bottom right

%%%%%%%%%%%%%%%   where are the dipoles ?


if(strcmp(model,'z-line')),
    
    zdip=[0:Ndip-1]*dist;
    %zdip=zdip-mean(zdip);
    rdip=[0*zdip;0*zdip; zdip];
    
elseif(strcmp(model,'YU1CL')),
    refl=-0.094;
    dir1=0.100;
    dir2=0.200;
    dir3=0.300;
    z=0;
    
    rdip=[0,refl,z;
        0,0,z;
        0,dir1,z;
        0,dir2,z;
        0,dir3,z;
        ];
    
    
    
    
elseif(strcmp(model,'yagiuda')),
    if Ndip==5
        refl=-0.150;
        dir1=0.180;
        dir2=0.360;
        dir3=0.540;
        %
        % %this is for maximum coupling from free space
        % %plane wave
        %refl=-0.4934/2;
        %   dir1=0.4934/4;
        %    dir2=0.4934/2;
        %    dir3=3*0.4934/4;
        %
        z=0.03;
        %z=0.1;
        rdip=[0,refl,z;
            0,0,z;
            0,dir1,z;
            0,dir2,z;
            0,dir3,z;
            ];
        
        
        
        
        
    elseif Ndip==1
        %z=0.015;
        %z=0.03;
        z=1;
        rdip=[0,0,z];
    elseif Ndip==2
        z=1;
        rdip=[0,-0.1,z;0,0.1,z];
        
    elseif Ndip==3
        z=0.1;
        rdip=[0,-0.1,z;0,0,z;0,0.1,z];
    elseif Ndip==4
        z=0.1;
        rdip=[0,-0.1,z;0,0,z;0,0.1,z;0,0.2,z];
    end
    
    
    
    
    
elseif(strcmp(model,'singlerod')),
    rdip=[0 0 0];
    
    
    
elseif (strcmp(model,'x-line')),
    xdip=[0:Ndip-1]*dist;
    %zdip=zdip-mean(zdip);
    rdip=[xdip;0*xdip; 0*xdip];
    
elseif (strcmp(model,'oligomer')),
    h=sqrt(3)/2;
    a=dist;
    rdip= [-a/2, a/2, -a, 0, a, -a/2,  a/2; ...
        +h*a, h*a,  0, 0, 0, -h*a, -h*a; ...
        0*[1:7]];
    
elseif (strcmp(model,'hexamer')),
    h=sqrt(3)/2;
    a=dist;
    rdip= [0, h*a, h*a, 0, -h*a,  -h*a; ...
        a, a/2,  -a/2, -a, -a/2, a/2; ...
        0*[1:6]];
    
elseif (strcmp(model,'heptamer')),      % this is like oligomer by rotated by 60deg
    h=sqrt(3)/2;
    a=dist;
    rdip= [0, h*a, h*a, 0, -h*a,  -h*a 0; ...
        a, a/2,  -a/2, -a, -a/2, a/2 0; ...
        0*[1:7]];
    
elseif (strcmp(model,'trimer'));
    h=sqrt(3)/2;
    a=dist;
    rdip= [-a/2, a/2, 0; ...
        +h*a, h*a, 0; ...
        0*[1:3]];
    
    %     rdip= [-a/2, a/2, -a, a, -a/2,  a/2; ...
    %            +h*a, h*a,  0, 0, -h*a, -h*a; ...
    %            0*[1:6]];
    
 elseif(strcmp(model,'Array')),
    
     [xs,ys]=meshgrid(1:7,1:7);
     X=xs(:)*0.1-0.4;
     Y=ys(:)*0.1-0.4;
     rdip=[X,Y,Y*0];
        xpos=0.03;
        ypos=0.03;
        zpos=-0.01;
        delta=0.2;
     scatterers=[0+xpos,-delta+ypos,zpos;0+xpos,delta+ypos,zpos];
    
     rdip=[rdip;scatterers];
    
    
else    error('don t know where to put dipoles')
end


