function invalpha=INVPolarizabilityProlate(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv)
%Only free space
%p = path;
%path(p,'..\WaveguideGreensFunctionv2');
% this will set up a vector of inverse polarizabilities alpha^-1 for oblate
% spheroids, with short axis b along the z-axis and the long-axis a along x
% and y for Ndip particles
% invalphalist will be of form [alpha1x alpha2x alpha3x ... alpha1y alpha2y
% ... alpha1z alpha2z...]
% the treatment follows Zeman & Schatz.  J Phys Chem  91, 634.
numdipoles=size(rdip,1);
eps0=1;
mu0=1;
eps1=epsilonv;
mu1=muv;
c=1;

%kmed=sqrt(eps1*mu1)*k;

% c0=2.99792458e8;
% eps0=1/(4*pi*1E-7*c0^2) ;        % remember mu0=4*pi*10^-7
% eps=eps0*nrefr^2;
% v=c/nrefr;
% k=omega/v;
% kmed=nrefr*k;

% get the geometrical parameters 
% a long axis
% b axis
invalpha=zeros(3*numdipoles,3*numdipoles);
for cont=1:numdipoles
    a=alist(cont);
    b=blist(cont);
    
    gamma=gammalist(cont);
    w0=w0list(cont);
    k=omega/c;
    rdipole=rdip(cont,:);
    % let's figure out an epsilon according to Drude
    % if Drude: w0 = wp/Sqrt(3)
   epsilon=1-3*(w0.^2)./omega./(omega+1i*gamma);
   % epsilon=Gold((c/omega)*1000);
    %epsilon=-5+1i;
       
    ex=sqrt(1-(b./a).^2);   %% excentricity
       
    % get static polarizabilities
    if ex==0
        prolateL1=1/3;
    else
        prolateL1=((1-ex.^2)./(ex.^2)).*(-1+(1./(2.*ex)).*log((1+ex)./(1-ex)));
    end
    
    prolateL2=(1-prolateL1)/2;
    
    %em is the epsilon of the medium
    em=epsilonv;
    prolateL3=prolateL2;
    %since the geometrical factor c= b then we put a*b*b instead of a*b*c
    
    alphax=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL1*(epsilon-em)));
    alphay=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL2*(epsilon-em)));
    alphaz=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL3*(epsilon-em)));
    
    alphastatic=diag([alphax,alphay,alphaz]);
    
   %alphastatic=eye(3);
   
    %It is better to put the analitical expression for the imaginary part of the freeG.
    %Since we only need to be able to do energy conservation and the real
    %part of the scattered green's funciton only shifts the resonance then
    %we may as well just use the imaginary part of the scattered G and not
    %the total G
    
   %invalpha(3*(cont-1)+1:3*cont,3*(cont-1)+1:3*cont)=inv(alphastatic)-((omega.^2)*mu0*mu1)*1i*imag(GreenWaveguide(k,rdipole,rdipole,struct,t))-1i*((k)^2*(mu1)/(eps0))*(omega/(6*pi*c))*eye(3);
   invalpha(3*(cont-1)+1:3*cont,3*(cont-1)+1:3*cont)=inv(alphastatic)-1i*((k)^2*(mu1)/(eps0))*(omega/(6*pi*c))*eye(3);
    
end

