function valTheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv)

%% now set up the coupling matrix (M in Weber and Ford)
%% Choice to be aware of:
%% matrix first has all the x components (px and Ex at all dipole positions)
%% then all the y components
%% then all the z components

% c0=2.99792458e8;
% eps0=1/(4*pi*1E-7*c0^2) ;        % remember mu0=4*pi*10^-7
% %eps0=1/(4*pi*1E-7*c^2) ;
% eps=eps0*nrefr^2 ;
% v=c/nrefr;
% k=omega/v;
% 

% eps1=struct(1,1);
% eps2=struct(2,1);
% eps3=struct(3,1);
% mu1=struct(1,2);
% mu2=struct(2,2);
% mu3=struct(3,2);
c=1;
%k=omega/c;
k=sqrt(epsilonv*muv)*omega;

invalphas=INVPolarizabilityProlate(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
CouplingG=SetupDipoleCouplingmatrix(rdip,omega,muv,epsilonv);
valTheMat= invalphas-CouplingG;
 