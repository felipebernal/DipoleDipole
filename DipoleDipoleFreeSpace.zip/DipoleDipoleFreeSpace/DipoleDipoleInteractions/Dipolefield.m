function [Evec]=Dipolefield(p,R,k,epsilon)
% returns field of a dipole p at R=r-r' from dipole
% k = omega /v, epsilon = epsilon0*n^2

 
Rlen=norm(R);

%Rhat=R/Rlen;
%Evec=(k^2*mycross(mycross(Rhat,p),Rhat)/Rlen+(3*Rhat*mydot(Rhat,p)-p)*(1/Rlen^3-i*k/Rlen^2))*exp(i*k*Rlen)/(4*pi*epsilon);
%wrongEvec=(k^2*mycross(mycross(R ,p),R ) +(3*Rlen*R*mydot(R ,p)-p)*(1 -i*k*Rlen ))*exp(i*k*Rlen)/(4*pi*epsilon*Rlen^3);
Evec=(k^2*mycross(mycross(R ,p),R ) +(3/Rlen^2*R*mydot(R ,p)-p)*(1 -1i*k*Rlen ))*exp(1i*k*Rlen)/(4*pi*epsilon*Rlen^3);

function [out]=mycross(a,b)

out=zeros(size(a));
%out=0*a;  %%allocate
out(1)=a(2)*b(3)-a(3)*b(2);
out(2)=a(3)*b(1)-a(1)*b(3);
out(3)=a(1)*b(2)-a(2)*b(1);
%out =[a(2)*b(3)-a(3)*b(2)    a(3)*b(1)-a(1)*b(3) a(1)*b(2)-a(2)*b(1)];


function [out]=mydot(a,b)
out=a(1)*b(1)+a(2)*b(2)+a(3)*b(3);
