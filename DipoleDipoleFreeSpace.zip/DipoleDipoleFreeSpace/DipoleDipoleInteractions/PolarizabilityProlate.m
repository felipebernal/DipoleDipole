function alphalistProlate=PolarizabilityProlate(omega,w0,gamma,a,b,struct)

% this will set up a vector of inverse polarizabilities alpha^-1 for oblate
% spheroids, with short axis b along the z-axis and the long-axis a along x
% and y for Ndip particles
% invalphalist will be of form [alpha1x alpha2x alpha3x ... alpha1y alpha2y
% ... alpha1z alpha2z...]
% the treatment follows Zeman & Schatz.  J Phys Chem  91, 634.

eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);
c=1;
k=omega/c;
kmed=sqrt(eps1*mu1)*k;

% c0=2.99792458e8;
% eps0=1/(4*pi*1E-7*c0^2) ;        % remember mu0=4*pi*10^-7
% eps=eps0*nrefr^2;
% v=c/nrefr;
% k=omega/v;
% kmed=nrefr*k;

% let's figure out an epsilon according to Drude
% if Drude: w0 = wp/Sqrt(3)
epsilon=1-3*w0^2/omega/(omega+1i*gamma);



% get the geometrical parameters 
% a long axis
% b axis
ex=sqrt(1-(b./a).^2);   %% excentricity


% get static polarizabilities
V=4/9*pi*(b.^3+2*a.^3);   %% volume van een ellipsoiede met assen b,a,a

  if ex==0
        prolateL1=1/3;
    else
        prolateL1=((1-ex.^2)./(ex.^2)).*(-1+(1./(2.*ex)).*log((1+ex)./(1-ex)));
    end
    
    prolateL2=(1-prolateL1)/2;

% alpha1=((epsilon -1)./(1+oblateL1*(epsilon -1)).*V*eps);   %%%  without depolarization; along a
% alpha2=((epsilon -1)./(1+oblateL2*(epsilon -1)).*V*eps);   %%%  without depolarization b

%em is the epsilon of the medium
em=eps1;
prolateL3=prolateL2;
%since the geometrical factor c= b then we put a*b*b instead of a*b*c

alphax=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL1*(epsilon-em)));
alphay=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL2*(epsilon-em)));
alphaz=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL3*(epsilon-em)));

alphalistProlate=diag([alphax,alphay,alphaz]);



