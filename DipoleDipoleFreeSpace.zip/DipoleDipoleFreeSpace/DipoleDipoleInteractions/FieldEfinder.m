function valFieldEfinder = FieldEfinder(scattstr,nearfieldstr,rtoeval,omega,muv,epsilonv,direction,pol,rsource,funE,VECQ,matM,rdip)

%p = path;
%path(p,'..\WaveguideGreensFunctionv2');
%p3 = path;
%path(p3,'..\GreenWaveguideFarField');   
%Icon tell where to evaluate, if inside of the scatterer or outside of it.
%so far can only be 1 or 2...1 is outside and 2 is inside.
%scatt tells the program whether to find the total field 1 or only the
%scattered field=2.
%Nearfield tells the program to use  a near field propagation of the
%currents to find the field=1 or a farfield one=2

if strcmpi(scattstr,'scatt')
    scatt=2;
elseif strcmpi(scattstr,'total')
     scatt=1;
end


if strcmpi(nearfieldstr,'near')
    nearfield=1;
elseif strcmpi(nearfieldstr,'medium')
    %   nearfield=2; 
elseif strcmpi(nearfieldstr,'far')
     nearfield=3;
end

numdipoles=size(rdip,1);
eps0=1;
mu0=1;
mu1=muv;
eps1=epsilonv;
% eps1=struct(1,1);
% eps2=struct(2,1);
% eps3=struct(3,1);
% mu1=struct(1,2);
% mu2=struct(2,2);
% mu3=struct(3,2);
c=1;
k=omega*sqrt(mu1*eps1); 
%  k1=sqrt(eps1*mu1)*omega/c;
%  k2=sqrt(eps2*mu2)*omega/c;
% k3= sqrt(eps3*mu3)*omega/c;



%VECQ=TheVectorFiller(omega,direction,pol,rsource,funE,funH,LineNodes,triangle,positions);
Pvectortemp=matM\VECQ;
%We need to reorganize Pvector so that we get a Ndipx 3 matrix which is
%easier to work with when we use multiprod.
Pvector=reshape(Pvectortemp,3,numdipoles).';






%nearfield=2;
numrtoeval=size(rtoeval,1);


rptrtoeval=VECrpt3D(rtoeval,numdipoles); %here we repeat the positions where 
%we need the field by the number of dipoles that contribute to the field.
rptdip=repmat(rdip,numrtoeval,1);
if nearfield==1 %here you get the near and medium field!
    
   % FieldfromallDipoles=(omega^2)*mu0*mu1*multiprod(GreenWaveguide(k,rptrtoeval,rptdip,struct,t),VECrpt3D(Pvector,numrtoeval).',[1,2],[1]).';
     FieldfromallDipoles=(omega^2)*mu0*mu1*multiprod(FreeDyadG(k,rptrtoeval,rptdip),repmat(Pvector,numrtoeval,1).',[1,2],[1]).';
    %now we reorganize them in the number of dipoles by the number of
    %positions and then we sum the fields.
    totsum=reshape(sum(reshape(FieldfromallDipoles,numdipoles,[]),1),[],3);%this is the scattered field
    %totsum=sum(FieldfromallDipoles,1); %this is the scattered field
    
    
         if scatt==1 %This condition gives you the total field outside.
            valFieldEfinder=totsum+funE(omega,direction,pol,rtoeval,rsource,struct,t);
        else
            valFieldEfinder=totsum;%This condition gives you only the scattered field outside.
        end
   
    
elseif  nearfield==3 %From here on is when you want to get the far field!
    
    
    FieldfromallDipoles=(omega^2)*mu0*mu1*multiprod(FreeDyadG(k,rptrtoeval,rptdip),repmat(Pvector,numrtoeval,1).',[1,2],[1]).';
    %totsum=sum(FieldfromallDipoles,1); %this is the scattered field
    totsum=reshape(sum(reshape(FieldfromallDipoles,numdipoles,[]),1),[],3);%this is the scattered field
    
    
        if scatt==1
            valFieldEfinder=totsum+funE(omega,direction,pol,rtoeval,rsource,muv,epsilonv);
        else
            valFieldEfinder=totsum;
        end

end

