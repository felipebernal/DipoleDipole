function valfunE= TransitionFieldE(omega,direction,pol,rtoeval,rsource,~,~)
% Direction only determines kx and ky and the sign of kz...depending on if
% it goes up or down we choose which refractive index to use for findign
% kz....that makes the program a bit more esy to use.
%This function does not have guided modes....only real kz are possible.
%In this case pol is the polarization in the reference frame of the beam,
%and the plane, like that we avoid cases were people put pol and directions
%that are not perpendicular. so pol has a zero third component wich is th
%edirection of the beam, x is pol totally s polarized and y is polarization p polarized .

%global t;
%global struct;
%eps1=struct(1,1);
%eps2=struct(2,1);
%eps3=struct(3,1);
%mu1=struct(1,2);
%mu2=struct(2,2);
%mu3=struct(3,2);
mu=1;
mu0=1;
c=1;
%pol=[1 0 0];
%numr=size(rtoeval,1);

direction=direction./norm(direction);
pol=pol./norm(pol);
rtoeval=rtoeval-rsource;

%if (rtoeval(1)^2+rtoeval(2)^2)<=10^-3
%rtoeval=[0.001,0.001,rtoeval(3)];    
%end

%kpar=Kparfinder(omega,direction);

intlimit=100;

vbeta=0.271646;%for a 20 kev to m/s/c where c is 1;
chargeele=1;
int1=1i*omega*mu*mu0*quadv(@(zp)auxfuntion1(omega, rtoeval, zp,vbeta, chargeele),-intlimit,0);

int2=1i*omega*mu*mu0*quadv(@(zp)auxfuntion2(pol,omega, rtoeval, zp,vbeta, chargeele),-intlimit,0);
%int3=1i*omega*mu*mu0*quadgk(@(zp)auxfuntion4(omega, rtoeval, zp,vbeta, chargeele),-intlimit,0);
%int4=1i*omega*mu*mu0*quadgk(@(zp)auxfuntion5(omega, rtoeval, zp,vbeta, chargeele),-intlimit,0);
valfunE=int1*pol.'+int2;


function valauxfunc1=auxfuntion1(omega, rtoeval, zsource,vbeta, chargeele)
c=1;
k=omega/c;
valauxfunc1=(chargeele*exp(-1i*(omega/vbeta)*abs(zsource))*exp(1i*k*sqrt(rtoeval(1)^2+rtoeval(2)^2+(rtoeval(3)-zsource)^2)))/(4*pi*(k^2)*(rtoeval(1)^2+rtoeval(2)^2+(rtoeval(3)-zsource)^2)^(3/2));
end

function valauxfunc2=auxfuntion2(pol,omega, rtoeval, zsource,vbeta, chargeele)
c=1;
k=omega/c;
x=rtoeval(1);
y=rtoeval(2);
zmzp=(rtoeval(3)-zsource);
mataux=[x^2,x*y,x*zmzp;zmzp*y,y^2,y*zmzp;x*zmzp,y*zmzp,zmzp^2];
mat=mataux*pol.';
valauxfuncaux2=(chargeele*exp(-1i*(omega/vbeta)*abs(zsource))*exp(1i*k*sqrt(rtoeval(1)^2+rtoeval(2)^2+(rtoeval(3)-zsource)^2)))/(4*pi*(k^2)*(rtoeval(1)^2+rtoeval(2)^2+(rtoeval(3)-zsource)^2)^(2));
%valauxfunc3=auxfuntion2(omega, rtoeval, zsource,vbeta, chargeele)*mat;
valauxfunc2=valauxfuncaux2*mat;
end


end