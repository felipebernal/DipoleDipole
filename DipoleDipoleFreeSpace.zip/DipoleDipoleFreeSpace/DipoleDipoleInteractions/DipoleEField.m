function valfunEDipole= DipoleEField(omega,~,pol,rtoeval,rsource,muv,epsilonv)
% omega is the frequency at which the dipole radiates..
%polarization or pol is the orientation of the dipole in x y and z.
%direction is not used at all...
%rtoeval is the position at which we want to find the E field.
%rsource is the position of the dipole


numpoints=size(rtoeval,1);

mu0=1;
c=1;
epsilon=epsilonv;
mu=muv;
pol=repmat(pol,numpoints,1);
k=omega*sqrt(epsilon*mu)/c;

valfunEDipole=omega^2.*mu0*mu*multiprod(FreeDyadG(k,rtoeval,repmat(rsource,size(rtoeval,1),1)),pol.',[1,2],[1]).';

end