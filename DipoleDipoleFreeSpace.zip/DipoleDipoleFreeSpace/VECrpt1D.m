%this function takes any list of 1-vectors and repeats them n times
%e.g. v=[1 ;6; 9;] and you need to repeat it 3 times then:
%it will look like vrpt=[1 ; 1; 1; 6; 6; 6; 9; 9; 9]

function valrptvec= VECrpt1D(vec,rpt)

vec=vec(:,ones(rpt,1));
vec=vec.';
valrptvec=vec(:);
