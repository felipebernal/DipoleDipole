function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
  ...  [sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
          [Pwaveguide]=runnerBistaticGaussianExcIncoupling(Radius,lambda)
      name='yagiuda';
p = path;
%path(p,'..\WaveguideGreensFunctionQuadVGK');
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   
p4 = path;
path(p4,'..\MicroscopeVision');   
      



struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% %struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% t=0.1;
% %t=0;

%struct=[[1;1.000001;1],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%t=0.01;
t=0.1;

omega=2*pi/(lambda/1000);
%omega=pi;

eps0=1;
mu0=1;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

Ndip=1;
%Ndip=1;
rdip=InitializeDipolePositions(Ndip,1,name);%For the yagiUda Ndip and dist do not matter.
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);

direction=[0 0 -1];
pol=[1 0 0];
rsource=[0 0 0];

numberofpoints=400;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date; 

TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayeredGauss,rdip,struct,t);
%[vecplotparallel,vecplotperpedicular]= FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);


Pvectortemp=TheMat\TheV;
   
Pvector=reshape(Pvectortemp,3,Ndip).';
TheVarr=reshape(TheV,3,Ndip).'
Pextintion=(omega/2)*imag(sum(sum(Pvector.*conj(TheVarr),2),1))

%Now we find the power scattered out of plane
%first on top

thetarange=pi/2;
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@PlaneWaveELayeredGauss,TheV,TheMat,rdip);
vecplotTOP=(1/2)*sqrt((eps0*eps1)/(mu0*mu1))*(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1)

%Now for the bottom
thetarange=pi/2;
thetapoints=[pi/2:thetarange/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@PlaneWaveELayeredGauss,TheV,TheMat,rdip);
vecplotBOTTOM=(1/2)*sqrt((eps0*eps3)/(mu0*mu3))*(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1)


Pscattered=vecplotTOP+vecplotBOTTOM


%
%So the power got into the waveguide is

Pwaveguide=Pextintion-Pscattered;

