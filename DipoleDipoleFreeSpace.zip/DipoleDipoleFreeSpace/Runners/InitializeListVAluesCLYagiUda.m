function [w0list,gammalist,alist,blist]=InitializeListVAluesCLYagiUda(YU)
c=1;
%%%this is how we created the random numbers
% alist=[0.063;0.0525;0.0475;0.0475;0.0475];
% ALIST=repmat(alist,1,10);
% randommat=rand(5,10);
% randommatsign=rand(5,10)-0.5;
% randommatsign=sign(rand(5,10)-0.5);
% randomnumbers=(randommat*0.0025).*randommatsign;
% ALIST=repmat(alist,1,10)+randomnumbers;
%%%



if YU==0
    
  lambdas=[0.81025-0.2295;0.69225-0.14;0.70481-0.152;0.660371-0.0745;0.7125366-0.122;];%this is in microns
  w0list=2*pi*(c./lambdas);
  alist=[0.06089;0.0496658;0.0512252;0.039727;0.0459158];%alist is the list with the length of the element in microns
  blist=[0.03;0.03;0.03;0.03;0.03];
  %blist=[0.025;0.025;0.025;0.025;0.025];
  
        %gammalist=[0.325;0.4;0.4;0.45; 0.4];
        gammalist=[0.325;0.325;0.325;0.325; 0.3254];

%this is the list used for the first study and it works an it is nice
%lambdas=[0.81025-0.2295;0.69225-0.14;0.70481-0.152;0.660371-0.0745;0.7125366-0.122;];%this is in microns
%w0list=2*pi*(c./lambdas);
%alist=[0.06089;0.0496658;0.0512252;0.039727;0.0459158];%alist is the list with the length of the element in microns
%blist=[0.03;0.03;0.03;0.03;0.03];
elseif YU==100
%       %lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
%   %lambdas=[0.45;0.45;0.45;0.45;0.45];%this is in microns
%   lambdas=[0.3;0.3;0.3;0.3;0.3];%this is in microns
%   w0list=2*pi*(c./lambdas);
%  % alist=[0.063;0.0525;0.0475;0.0475;0.0475];%alist is the list with the length of the element in microns this is the perfect yagiUda
%   alist=[0.058;0.0485;0.0475;0.0475;0.047];%alist is the list with the length of the element in microns this is the perfect yagiUda
%  
%   %alist=[0.0650863353454219;0.0527482721516287;0.0520135805495764;0.0427760640513918;0.0450456795376596;];
%   %blist=[0.025;0.025;0.025;0.025;0.025];
%   %blist=[0.02;0.02;0.02;0.02;0.02];
%  blist=[0.01;0.01;0.01;0.01;0.01];
%   gammalist=[0.325;0.325;0.325;0.325; 0.325];



  
 lambdas=[0.81025-0.2295;0.69225-0.14;0.70481-0.152;0.660371-0.0745;0.7125366-0.122;];%this is in microns
        w0list=2*pi*(c./lambdas);
        alist=[0.06089;0.0496658;0.0512252;0.039727;0.0459158];%alist is the list with the length of the element in microns
        blist=[0.03;0.03;0.03;0.03;0.03];
        %gammalist=[0.325;0.4;0.4;0.45; 0.4];
        gammalist=[0.325;0.325;0.325;0.325; 0.3254];
  
  
  elseif YU==200
      %lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  %lambdas=[0.45;0.45;0.45;0.45;0.45];%this is in microns
  lambdas=[0.55;0.55;0.55;0.55;0.55];%this is in microns
  w0list=2*pi*(c./lambdas);
 % alist=[0.063;0.0525;0.0475;0.0475;0.0475];%alist is the list with the length of the element in microns this is the perfect yagiUda
  alist=[0.058;0.0485;0.0475;0.0475;0.0475];%alist is the list with the length of the element in microns this is the perfect yagiUda
 
  %alist=[0.0650863353454219;0.0527482721516287;0.0520135805495764;0.0427760640513918;0.0450456795376596;];
  %blist=[0.025;0.025;0.025;0.025;0.025];
  %blist=[0.02;0.02;0.02;0.02;0.02];
 blist=[0.027;0.027;0.027;0.027;0.027];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];


elseif YU==1
    
  lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  w0list=2*pi*(c./lambdas);
  %perfect alist=[0.063;0.0525;0.0475;0.0475;0.0475];%alist is the list with the length of the element in microns this is the perfect yagiUda
  alist=[0.0628509528310509;0.0507950702396273;0.0476060778437519;0.0473213863384984;0.0488041246061607;]
  
  blist=[0.025;0.025;0.025;0.025;0.025];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];

elseif YU==2
    
    lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  w0list=2*pi*(c./lambdas);  
  alist=[0.0632418250644522;0.0545453713846491;0.0454561322698018;0.0456939010190829;0.0471253363938051;];
   blist=[0.025;0.025;0.025;0.025;0.025];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];
  
    
elseif YU==3
      lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  w0list=2*pi*(c./lambdas);
    alist=[0.0646490131322708;0.0537964873562763;0.0450675636130904;0.0491224787317809;0.0495008264383810;];
     blist=[0.025;0.025;0.025;0.025;0.025];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];

elseif YU==4
      lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  w0list=2*pi*(c./lambdas);
  alist=[0.0641344942718173;0.0535809787594587;0.0454367155114949;0.0472913254628527;0.0478329275190179;];
    blist=[0.025;0.025;0.025;0.025;0.025];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];
 
elseif YU==5
      lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  w0list=2*pi*(c./lambdas);
  alist=[0.0634334715327975;0.0515226554941907;0.0454215506429023;0.0454915890209939;0.0473488220520753;];
      blist=[0.025;0.025;0.025;0.025;0.025];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];
 
elseif YU==6
    lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  w0list=2*pi*(c./lambdas);  
    alist=[0.0620018555734661;0.0511828104237293;0.0485419986698270;0.0458578502725657;0.0490699333979753;];
    blist=[0.025;0.025;0.025;0.025;0.025];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];
 
elseif YU==7
  lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  w0list=2*pi*(c./lambdas);
  alist=[0.0637299601999043;0.0535791279256218;0.0475387178140901;0.0499601593109479;0.0470820789752134;];
   blist=[0.025;0.025;0.025;0.025;0.025];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];
  
elseif YU==8
    lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  w0list=2*pi*(c./lambdas);
  alist=[0.0632655408623217;0.0515689756498612;0.0479952960063574;0.0487242190950401;0.0466512664665231;];
   blist=[0.025;0.025;0.025;0.025;0.025];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];
  
        
elseif YU==9
    lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  w0list=2*pi*(c./lambdas);  
    alist=[0.0606209238380557;0.0501991699004086;0.0476316924942020;0.0493446452387925;0.0468272014340036;];
     blist=[0.025;0.025;0.025;0.025;0.025];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];

elseif YU==10
  lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
  w0list=2*pi*(c./lambdas);
  alist=[0.0640570890375220;0.0538696772530371;0.0451431575393077;0.0485443602607917;0.0450423688338254;];
   blist=[0.025;0.025;0.025;0.025;0.025];
  gammalist=[0.325;0.325;0.325;0.325; 0.325];
 
end
%
% % a=75E-9;  %%%% radius long axis
% % b=15E-9;  %%% radius short axis
% % w0=4.76E15;  %%%% resonance frequency
% %
% % gamma=8.3E13;  %% Ohmic damping frequency
% % %gamma=0;
% c=1;
% 
% if Ndip==5
%     
%     
%     %lambdas=[0.65;0.6;0.6;0.6;0.6];
%     %lambdas=[0.8;0.62;0.62;0.62;0.62];
%     lambdas=[0.85;0.63;0.63;0.63;0.63];
%     
%     % w0list=2*pi*(c./lambdas);
%     % alist=[0.155;0.125;0.115;0.115;0.115];
%     % blist=[0.03;0.03;0.03;0.03;0.03];
%     % %gammalist=[0.405;0.405;0.405;0.405;0.405];
%     % gammalist=[0.000000001;0.000000001;0.000000001;0.000000001;0.000000001];
%     % lambdas=[0.5;0.49;0.43;0.43;0.43];
%     %
%     w0list=2*pi*(c./lambdas);
%     alist=[0.155/2;0.125/2;0.115/2;0.115/2;0.115/2];
%     blist=[0.03;0.03;0.03;0.03;0.03];
%     %gammalist=[0.405;0.405;0.405;0.405;0.405];
%     gammalist=[0.1;0.1;0.1;0.1;0.1];
%     
%     % %%maximum coupling for free space
%     % lambdas=[0.6;0.6;0.6;0.6;0.6];
%     %
%     % w0list=2*pi*(c./lambdas);
%     % alist=[0.05;0.05;0.05;0.05;0.05];
%     % blist=[0.03;0.03;0.03;0.03;0.03];
%     % %gammalist=[0.405;0.405;0.405;0.405;0.405];
%     % gammalist=[0.1;0.1;0.1;0.1;0.1];
%     
%     
%     % lambdas=[0.52;0.51;0.5;0.5;0.5];
%     %
%     % w0list=2*pi*(c./lambdas);
%     % alist=[0.155/2;0.125/2;0.115/2;0.115/2;0.115/2];
%     % blist=[0.06/2;0.06/2;0.06/2;0.06/2;0.06/2];
%     % %gammalist=[0.405;0.405;0.405;0.405;0.405];
%     % gammalist=[0.1;0.1;0.1;0.1;0.1];
%     %
%     
%     
% elseif Ndip==1
%     
%     lambdas=0.6;%this is in microns
%     %
%     % %lambdas=0.8;%this is in microns
%     w0list=2*pi*(c./lambdas);
%     alist=0.05;
%     blist=0.03;
%     
%     %alist=0.035;
%     %blist=0.035;
%     
%     % %blist=0.06;
%     % alist=0.071;
%     % blist=0.071;
%     
%     gammalist=0.1;
%     %gammalist=0.000000001;
%     
%     
%     %gammalist=0.00001;
%     %gammalist=0;
%     
%     
% elseif Ndip==2
%     
%     lambdas=[0.6;0.6];%this is in microns
%     w0list=2*pi*(c./lambdas);
%     alist=[0.035;0.035];
%     blist=[0.035;0.035];
%     % alist=[0.044;0.044];
%     % blist=[0.044;0.044];
%     gammalist=[0.1;0.1];
%     %gammalist=[0;0];
%     % lambdas=[0.2;0.2];%this is in microns
%     % w0list=2*pi*(c./lambdas);
%     % alist=[0.125;0.125];
%     % blist=[0.030000001,0.030000001];
%     % gammalist=[0.7,0.7];
% elseif Ndip==3
%     %lambdas=0.800;%this is in microns
%     
%     % lambdas=0.8;%this is in microns
%     % w0list=2*pi*(c./lambdas);
%     % alist=0.155;
%     % blist=0.04;
%     % gammalist=1.9;
%     lambdas=[0.6;0.6;0.6];%this is in microns
%     w0list=2*pi*(c./lambdas);
%     alist=[0.05;0.05;0.05];
%     blist=[0.03;0.03;0.03];
%     gammalist=[0.1;0.1;0.1];
% elseif Ndip==4
%     %lambdas=0.800;%this is in microns
%     
%     % lambdas=0.8;%this is in microns
%     % w0list=2*pi*(c./lambdas);
%     % alist=0.155;
%     % blist=0.04;
%     % gammalist=1.9;
%     lambdas=[0.6;0.6;0.6;0.6];%this is in microns
%     w0list=2*pi*(c./lambdas);
%     alist=[0.05;0.05;0.05;0.05];
%     blist=[0.03;0.03;0.03;0.03];
%     gammalist=[0.1;0.1;0.1;0.1];
% end
