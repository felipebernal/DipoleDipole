
%function RunnerArrayandScatterScanXY
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');
p4 = path;
path(p4,'..\MicroscopeVision');   

muv=1;
epsilonv=1;
c=1;

Radius=1000;
numberofpoints=200;

%rdip=InitializeDipolePositions(38,1,'Array');

% positionsscann=[-0.05:0.005:0.05];

% positionsscann=[-0.07:0.005:0.07];
%positionsscann=[-0.04:0.001:0.04];
positionsscann=[-0.03:0.001:0.03];

[Xscan,Yscan]=meshgrid(positionsscann,positionsscann);

Xscan2=Xscan(:);
Yscan2=Yscan(:);

numposscan=size(Xscan(:),1);

fourierImagesXMat=zeros([200,198,numposscan]);
fourierImagesYMat=zeros([200,198,numposscan]);
fourierImagesExMat=zeros([200,198,numposscan]);
fourierImagesEyMat=zeros([200,198,numposscan]);

for ipos=1:numposscan
    
   xpos=Xscan2(ipos);
   ypos=Yscan2(ipos); 
    
    
%%%%%%%%%%%%%
linenumant=9;%please put odd numbers
numscattererrs=3;
  [xs,ys]=meshgrid(1:linenumant,1:linenumant);
  spacing=0.125;%0.1
  centershift=round(linenumant/2)*spacing;
  X=xs(:)*spacing-centershift;
     Y=ys(:)*spacing-centershift;
     rdip=[X,Y,Y*0];
        
        zpos=-0.02;
        deltay=0.025;%0.012;
        %deltay=0;
        
        deltax=0;
        if numscattererrs==2
     scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos];
        elseif numscattererrs==3
            scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos;deltax+xpos+0.02,deltay+ypos,zpos]; 
        elseif numscattererrs==1
             scatterers=[-deltax+xpos,-deltay+ypos,zpos];
        end
     rdip=[rdip;scatterers];
    


%%%%%%%%%%%%%


[w0list,gammalist,alist,blist]=InitializeListValuesAntennaLensArray(linenumant,numscattererrs);

 direction=[0 0 -1];
    pol=[0 1 0];
    rsource=[0,0,0];
    
    lam=800;
    
    omega=2*pi/(lam/1000);
    
    TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
    TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveE,rdip,muv,epsilonv);
    %Pvector=TheMat\TheV;
    %valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@PlaneWaveE,TheV,TheMat,rdip);
        
   Radius=1800;
   NA=0.95;
   %NA=0.85;
   [x,y,Ebackx,Ebacky]=BackApertureNoImages(NA,Radius,TheV,TheMat,omega,muv,epsilonv,direction,pol,rsource,rdip);
    %[x,y,Ebackx,Ebacky]=BackAperture(NA,Radius,TheV,TheMat,omega,muv,epsilonv,direction,pol,rsource,rdip);
   fourierImagesXMat(:,:,ipos)=x(:,:);
   fourierImagesYMat(:,:,ipos)=y(:,:);
   fourierImagesExMat(:,:,ipos)=Ebackx(:,:);
   fourierImagesEyMat(:,:,ipos)=Ebacky(:,:);
   
   disp([num2str(ipos),' out of ',num2str(numposscan)])
end
    
nt=1;
Xscan2(nt)
Yscan2(nt)
figure(1)
pcolor(fourierImagesXMat(:,:,nt),fourierImagesYMat(:,:,nt),abs(fourierImagesExMat(:,:,nt)).^2);shading flat;axis image ;colorbar
 title({'|Ex|^2 back aperture/top/ missing jacobian, position',['x,y=',num2str([Xscan2(nt),Yscan2(nt)])]})

 %First type of unbalance check
 %this is half down-half up and half left minus half right.
 
unbalancex= (sum(sum(abs(fourierImagesExMat(1:100,:,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,:,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,:,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,:,:)).^2,1),2));
unbalancey= sum(sum(abs(fourierImagesExMat(:,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(:,100:198,:,:)).^2,1),2)./(sum(sum(abs(fourierImagesExMat(:,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(:,100:198,:,:)).^2,1),2));

sizescan=size(positionsscann,2);
figure(2)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancex),sizescan,sizescan))
title('unbalance in x fourier image')
figure(3)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancey),sizescan,sizescan))
 title('unbalance in y fourier image')
 
 %Second type of unbalance check
 %this is quarter down left minus quarter up rigth
 
 
 unbalancexy1= (sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2));
unbalancexy2= (sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2));

figure(4)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancexy2),sizescan,sizescan))
title('unbalance same side top-bottom fourier image')
 
unbalancexy3= (sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2));
figure(5)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancexy3),sizescan,sizescan))
title('unbalance corners 1 fourier image')
 
unbalancexy4= (sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2));
figure(6)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancexy4),sizescan,sizescan))
title('unbalance corners 2 fourier image')
 
 unbalancex2= (sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2));

figure(7)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancex2),sizescan,sizescan))
title('unbalance same side left-right fourier image')
 
 
  % drawpolarizabilityAntenna(Pvector,rdip);
   
%   figure(8)
% pcolor(Xscan,Yscan,cumsum(rot90(reshape(squeeze(unbalancexy4),sizescan,sizescan),2),1))
% title('integrated unbalance measure')

figure(8)
pcolor(Xscan,Yscan,rot90(cumsum(rot90(reshape(squeeze(unbalancexy4),sizescan,sizescan),2),1),-2))
title('integrated unbalance measure')


figure(9)
pcolor(Xscan,Yscan,rot90(cumsum((reshape(squeeze(unbalancexy4),sizescan,sizescan)),1),2))
title('integrated unbalance measure')

mat2int=reshape(squeeze(unbalancexy4),sizescan,sizescan);

figure(10)
pcolor(Xscan,Yscan,mat2int)


m=1;
n=floor(k/m);
reshpmat=reshape(mat2int(1:m*n,1:m*n),[m,n,m,n]);
finmat=reshape(sum(sum(reshpmat,1),3),[n,n]);
figure(11)
pcolor(finmat)

