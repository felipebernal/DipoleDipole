function [x,y,Ebackx,Ebacky]=...BackAperture(x,y,z,E,plotflag)
BackApertureGuided(NA,Radius,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip)

angleorNA=1;

numberofpoints=100;
numtiles=25;

neps=1;%This is the refractive index of the microscopeobjective medium
ApertureTheta=asin(NA/neps);
%thetapoints=[-pi/2:pi/(numberofpoints-1):pi/2]';
thetapoints=[-ApertureTheta:2*ApertureTheta/(numberofpoints-1):ApertureTheta].';

numthetapoints=size(thetapoints,1);
phipoints=[0:2*pi/(numberofpoints-1):2*pi].';
theta=[VECrpt1D(thetapoints(2:(end-1)),(numberofpoints))];
phi=[repmat(phipoints,(numberofpoints-2),1)];

clear('thetapoints','phipoints');
%Top
positionsphere=[Radius*sin(theta).*cos(phi),Radius*sin(theta).*sin(phi),Radius*cos(theta)];

%Bottom
%positionsphere=[Radius*sin(theta).*cos(phi),Radius*sin(theta).*sin(phi),-Radius*cos(theta)];


%x=Radius.*cos(phi).*sin(theta);
%y=Radius.*sin(phi).*sin(theta);
%z=Radius.*cos(theta);
x=positionsphere(:,1);
y=positionsphere(:,2);
z=positionsphere(:,3);


%E=FieldEfinder(1,'scatt','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveELayered,@PlaneWaveHLayered,TheV,TheMat,LineNodes,triangle,positions);
totnumposi=size(positionsphere,1);
E=zeros(totnumposi,3);
numblock=max(gcd(totnumposi,1:numtiles));
for cont=1:numblock
index1=((cont-1)*(totnumposi/numblock)+1);
index2=((cont)*(totnumposi/numblock));
E(index1:index2,:)=FieldEfinder('scatt','far',positionsphere(index1:index2,:),omega,struct,t,direction,pol,rsource,@GuidedWaveELayered,TheV,TheMat,rdip);
end

Ex=E(:,1);
Ey=E(:,2);
Ez=E(:,3);




% spherical coordinates
%phi=angle(x+1i*y);
%theta=acos(z);





%% unused, radial unit vector

%% radial
radialvecx=cos(phi).*sin(theta);
radialvecy=sin(phi).*sin(theta);
radialvecz=cos(theta);

% 
% $figure(1)
% 
% surf(0.98*x,0.98*y,0.98*z,0.9+0*z);shading flat; hold on
% quiver3(x,y,z,radialvecx,radialvecy,radialvecz); axis equal
% 



%% transverse tangential unit vectors

%% azimuthal
azimuthvecx=-sin(phi);
azimuthvecy=+cos(phi);

% 
% figure(2)
% surf(0.98*x,0.98*y,0.98*z,0.9+0*z);shading flat; hold on
% quiver3(x,y,z,azimuthvecx,azimuthvecy,0*azimuthvecx); axis equal
% 



% polar
tangentialvecx=cos(phi).*cos(theta);
tangentialvecy=sin(phi).*cos(theta);
tangentialvecz=-sin(theta);

% 
% figure(3)
% surf(0.98*x,0.98*y,0.98*z,0.9+0*z);shading flat; hold on
% quiver3(x,y,z,tangentialvecx,tangentialvecy,tangentialvecz); axis equal





%project field on sphere on those vectors
Eazimuth=azimuthvecx.*Ex+azimuthvecy.*Ey;
Etang=tangentialvecx.*Ex+tangentialvecy.*Ey+tangentialvecz.*Ez;


%figure(1)
%subplot(1,2,1)
%surf(x,y,z,abs(Eazimuth)) ; axis equal
%title('Eazi')

%subplot(1,2,2)
%surf(x,y,z,abs(Etang));axis equal
%titel('Etan')

%return


%
% now see what the lens does
Ebackpolar=Eazimuth;
Ebackradial=Etang;



% now project to cartesian in the backaperture plane

polarx=-sin(phi);polary=cos(phi);

radialx=cos(phi).*sign(z);
radialy=sin(phi).*sign(z);

% 
% figure(11)
% quiver(x,y,polarx,polary); axis equal
% 
% figure(12)
% quiver(x,y,radialx,radialy); axis equal

 


Ebackx=Ebackpolar.*polarx+Ebackradial.*radialx;
Ebacky=Ebackpolar.*polary+Ebackradial.*radialy;



%%Here we are trying to retrieve the matrix form the vectors of fields.





plotflag=3;





figure(plotflag+1)
colormap hot;

% split=floor(size(z,1)/2);
% range1=[1:split];    %% upper halfspace
% range2=[split+1:size(z,1)];   %% lower halfspace
if angleorNA==1
x=reshape(x,numthetapoints,[])/Radius;
y=reshape(y,numthetapoints,[])/Radius;
elseif angleorNA==0
x=asin(reshape(x,numthetapoints,[])/Radius)*180/pi;
y=asin(reshape(y,numthetapoints,[])/Radius)*180/pi;

end
%E=reshape(E,floor(sqrt(size(x,1))),[]);
Ebackx=reshape(Ebackx,numthetapoints,[]);
Ebacky=reshape(Ebacky,numthetapoints,[]);


subplot(2,2,[1,3])


pcolor(x,y,abs(Ebackx).^2+abs(Ebacky).^2);shading flat;axis image ;colorbar
title('|E|^2 back aperture/top/ missing jacobian')


%pcolor(x(range1,:),y(range1,:),abs(Ebackx(range1,:)).^2+abs(Ebacky(range1,:)).^2);shading flat;axis image ;colorbar
%title('|E|^2 back aperture/top/ missing jacobian')


%subplot(3,2,2)

% pcolor(x(range2,:),y(range2,:),abs(Ebackx(range2,:)).^2+abs(Ebacky(range2,:)).^2);shading flat;axis image ;colorbar
% title('|E|^2 back aperture/bottom/ missing jacobian')
% 
% 
 subplot(2,2,2)
 
% pcolor(x(range1,:),y(range1,:),abs(Ebackx(range1,:)).^2);shading flat;axis image ;colorbar
 %title('|Ex|^2 back aperture/top/ missing jacobian')
% subplot(3,2,4)

pcolor(x,y,abs(Ebackx).^2);shading flat;axis image ;colorbar
 title('|Ex|^2 back aperture/top/ missing jacobian')
 
% subplot(3,2,4)
% 
% pcolor(x(range2,:),y(range2,:),abs(Ebackx(range2,:)).^2);shading flat;axis image ;colorbar
% title('|Ex|^2 back aperture/bottom/ missing jacobian')
% 
 subplot(2,2,4)
 
% pcolor(x(range1,:),y(range1,:),abs(Ebacky(range1,:)).^2);shading flat;axis image ;colorbar
% title('|Ey|^2 back aperture/top/ missing jacobian')

pcolor(x,y,abs(Ebacky).^2);shading flat;axis image ;colorbar
 title('|Ey|^2 back aperture/top/ missing jacobian')
 
% subplot(3,2,6)
% pcolor(x(range2,:),y(range2,:),abs(Ebacky(range2,:)).^2);shading flat;axis image ;colorbar
% title('|Ey|^2 back aperture/bottom/ missing jacobian')

ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0
1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
text(0.5, 1,'\bf Linear analyzers','HorizontalAlignment','center','VerticalAlignment', 'top')

figure(plotflag+2)
colormap hot;

pcolor(x,y,abs(Ebackx).^2);shading flat;axis image ;colorbar
 title('|Ex|^2 POL V back aperture/top')

figure(plotflag+3)
colormap hot;

pcolor(x,y,abs(Ebacky).^2);shading flat;axis image ;colorbar
 title('|Ex|^2 POL H back aperture/top')

% % % 
% % % figure(plotflag+2)
% % % 
% % % 
% % % Eplus=1/sqrt(2)*(Ebackx-1i*Ebacky);
% % % Emin=1/sqrt(2)*(Ebackx+1i*Ebacky);
% % % 
% % % 
% % % 
% % % 
% % % 
% % % split=floor(size(z,1)/2);
% % % range1=[1:split];
% % % range2=[split+1:size(z,1)];
% % % 
% % % subplot(3,2,1)
% % % title('|E|^2 back aperture/top missing jacobian')
% % % pcolor(x(range1,:),y(range1,:),abs(Ebackx(range1,:)).^2+abs(Ebacky(range1,:)).^2);shading flat;axis image ;colorbar
% % % 
% % % subplot(3,2,2)
% % % title('|E|^2 back aperture/bottom missing jacobian')
% % % pcolor(x(range2,:),y(range2,:),abs(Ebackx(range2,:)).^2+abs(Ebacky(range2,:)).^2);shading flat;axis image ;colorbar
% % % 
% % % 
% % % 
% % % subplot(3,2,3)
% % % title('|Eplus|^2 back aperture/top missing jacobian')
% % % pcolor(x(range1,:),y(range1,:),abs(Eplus(range1,:)).^2);shading flat;axis image ;colorbar
% % % 
% % % subplot(3,2,4)
% % % title('|Eplus|^2 back aperture/bottom missing jacobian')
% % % pcolor(x(range2,:),y(range2,:),abs(Eplus(range2,:)).^2);shading flat;axis image ;colorbar
% % % 
% % % 
% % % subplot(3,2,5)
% % % title('|Emin|^2 back aperture/top missing jacobian')
% % % pcolor(x(range1,:),y(range1,:),abs(Emin(range1,:)).^2);shading flat;axis image ;colorbar
% % % 
% % % subplot(3,2,6)
% % % title('|Emin|^2 back aperture/bottom missing jacobian')
% % % pcolor(x(range2,:),y(range2,:),abs(Emin(range2,:)).^2);shading flat;axis image ;colorbar
% % % 
% % % 
% % % 
% % % 
% % % 
% % % ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0
% % % 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
% % % text(0.5, 1,'\bf Circular analyzers','HorizontalAlignment','center','VerticalAlignment', 'top')
% % % 
% % % 
% % % 
% % % 
