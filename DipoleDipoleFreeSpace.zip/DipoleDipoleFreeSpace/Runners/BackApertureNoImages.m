function [x,y,Ebackx,Ebacky]=...BackAperture(x,y,z,E,plotflag)
BackApertureNoImages(NA,Radius,TheV,TheMat,omega,muv,epsv,direction,pol,rsource,rdip)

numberofpoints=200;
numtiles=25;

neps=1;%This is the refractive index of the microscopeobjective medium
ApertureTheta=asin(NA/neps);
%thetapoints=[-pi/2:pi/(numberofpoints-1):pi/2]';
thetapoints=[-ApertureTheta:2*ApertureTheta/(numberofpoints-1):ApertureTheta]';

numthetapoints=size(thetapoints,1);
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
theta=[VECrpt1D(thetapoints(2:(end-1)),(numberofpoints))];
phi=[repmat(phipoints,(numberofpoints-2),1)];

clear('thetapoints','phipoints');
%Top
positionsphere=[Radius*sin(theta).*cos(phi),Radius*sin(theta).*sin(phi),Radius*cos(theta)];

%Bottom
%positionsphere=[Radius*sin(theta).*cos(phi),Radius*sin(theta).*sin(phi),-Radius*cos(theta)];


%x=Radius.*cos(phi).*sin(theta);
%y=Radius.*sin(phi).*sin(theta);
%z=Radius.*cos(theta);
x=positionsphere(:,1);
y=positionsphere(:,2);
z=positionsphere(:,3);


%E=FieldEfinder(1,'scatt','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveELayered,@PlaneWaveHLayered,TheV,TheMat,LineNodes,triangle,positions);
totnumposi=size(positionsphere,1);
E=zeros(totnumposi,3);
numblock=max(gcd(totnumposi,1:numtiles));
for cont=1:numblock
index1=((cont-1)*(totnumposi/numblock)+1);
index2=((cont)*(totnumposi/numblock));
E(index1:index2,:)=FieldEfinder('scatt','far',positionsphere(index1:index2,:),omega,muv,epsv,direction,pol,rsource,@PlaneWaveE,TheV,TheMat,rdip);
end

Ex=E(:,1);
Ey=E(:,2);
Ez=E(:,3);




% spherical coordinates
%phi=angle(x+1i*y);
%theta=acos(z);





%% unused, radial unit vector

%% radial
radialvecx=cos(phi).*sin(theta);
radialvecy=sin(phi).*sin(theta);
radialvecz=cos(theta);

% 
% $figure(1)
% 
% surf(0.98*x,0.98*y,0.98*z,0.9+0*z);shading flat; hold on
% quiver3(x,y,z,radialvecx,radialvecy,radialvecz); axis equal
% 



%% transverse tangential unit vectors

%% azimuthal
azimuthvecx=-sin(phi);
azimuthvecy=+cos(phi);

% 
% figure(2)
% surf(0.98*x,0.98*y,0.98*z,0.9+0*z);shading flat; hold on
% quiver3(x,y,z,azimuthvecx,azimuthvecy,0*azimuthvecx); axis equal
% 



% polar
tangentialvecx=cos(phi).*cos(theta);
tangentialvecy=sin(phi).*cos(theta);
tangentialvecz=-sin(theta);

% 
% figure(3)
% surf(0.98*x,0.98*y,0.98*z,0.9+0*z);shading flat; hold on
% quiver3(x,y,z,tangentialvecx,tangentialvecy,tangentialvecz); axis equal





%project field on sphere on those vectors
Eazimuth=azimuthvecx.*Ex+azimuthvecy.*Ey;
Etang=tangentialvecx.*Ex+tangentialvecy.*Ey+tangentialvecz.*Ez;


%figure(1)
%subplot(1,2,1)
%surf(x,y,z,abs(Eazimuth)) ; axis equal
%title('Eazi')

%subplot(1,2,2)
%surf(x,y,z,abs(Etang));axis equal
%titel('Etan')

%return


%
% now see what the lens does
Ebackpolar=Eazimuth;
Ebackradial=Etang;



% now project to cartesian in the backaperture plane

polarx=-sin(phi);polary=cos(phi);

radialx=cos(phi).*sign(z);
radialy=sin(phi).*sign(z);

% 
% figure(11)
% quiver(x,y,polarx,polary); axis equal
% 
% figure(12)
% quiver(x,y,radialx,radialy); axis equal

 


Ebackx=Ebackpolar.*polarx+Ebackradial.*radialx;
Ebacky=Ebackpolar.*polary+Ebackradial.*radialy;



%%Here we are trying to retrieve the matrix form the vectors of fields.

% split=floor(size(z,1)/2);
% range1=[1:split];    %% upper halfspace
% range2=[split+1:size(z,1)];   %% lower halfspace

x=reshape(x,numthetapoints,[])/Radius;
y=reshape(y,numthetapoints,[])/Radius;
%E=reshape(E,floor(sqrt(size(x,1))),[]);
Ebackx=reshape(Ebackx,numthetapoints,[]);
Ebacky=reshape(Ebacky,numthetapoints,[]);
