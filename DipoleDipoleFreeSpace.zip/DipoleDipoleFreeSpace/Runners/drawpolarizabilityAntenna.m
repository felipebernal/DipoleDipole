function drawpolarizabilityAntenna(Pvector,rdip)
Pvector=reshape(Pvector,3,[]).';
numdipoles=size(Pvector,1);

%first type of function...I don't like it very much cause it does not
%differentiate when two rods have the same amplitude...
% 
% colors=hot(5);
% colorchoser=abs(sum(Pvector.*conj(Pvector),2));
% [maxval,~]=max(colorchoser);
% normcolorchoser=colorchoser/maxval;
% [colororder,index]=sortrows(colorchoser);%with the first sortwos you can find the order in which they should go with the second you find the order in whoch they are!
% [~,indexindex]=sortrows(index);
% 
% %figure(7)
% rectangle('Position',[rdip(1,1)-0.155/2,rdip(1,2)-0.03/2,0.155,0.03],...
%           'Curvature',[0.03],...
%          'LineWidth',2,'LineStyle','-',...
%           'FaceColor',colors(indexindex(1),:));
% 
%    rectangle('Position',[rdip(2,1)-0.125/2,rdip(2,2)-0.03/2,0.125,0.03],...
%           'Curvature',[0.03],...
%          'LineWidth',2,'LineStyle','-',...
%           'FaceColor',colors(indexindex(2),:));   
%       
%       rectangle('Position',[rdip(3,1)-0.115/2,rdip(3,2)-0.03/2,0.115,0.03],...
%           'Curvature',[0.03],...
%          'LineWidth',2,'LineStyle','-',...
%           'FaceColor',colors(indexindex(3),:));   
%          
%         rectangle('Position',[rdip(4,1)-0.115/2,rdip(4,2)-0.03/2,0.115,0.03],...
%           'Curvature',[0.03],...
%          'LineWidth',2,'LineStyle','-',...
%           'FaceColor',colors(indexindex(4),:));   
%       
%               rectangle('Position',[rdip(5,1)-0.115/2,rdip(5,2)-0.03/2,0.115,0.03],...
%           'Curvature',[0.03],...
%          'LineWidth',2,'LineStyle','-',...
%           'FaceColor',colors(indexindex(5),:));   
%       
%       
%       daspect([1,1,1])
%Type 2
      
numcolors=10;
colors=hot(numcolors);
%colors=jet(numcolors);
colorchoser=abs(sum(Pvector.*conj(Pvector),2));
[maxval,~]=max(colorchoser);
normcolorchoser=colorchoser/maxval;
minvalue=min(normcolorchoser);
range=1-minvalue;
strechedcolorchoser=((normcolorchoser/range)-minvalue/range)*(numcolors-1)+1;

[colororder,index]=sortrows(colorchoser);%with the first sortwos you can find the order in which they should go with the second you find the order in whoch they are!

[~,indexindex]=sortrows(index);

%figure(7)
rectangle('Position',[rdip(1,1)-0.155/2,rdip(1,2)-0.03/2,0.155,0.03],...
          'Curvature',[0.03],...
         'LineWidth',2,'LineStyle','-','EdgeColor','k',...
         'FaceColor',colors(floor(strechedcolorchoser(1)),:));

   rectangle('Position',[rdip(2,1)-0.125/2,rdip(2,2)-0.03/2,0.125,0.03],...
          'Curvature',[0.03],...
         'LineWidth',2,'LineStyle','-','EdgeColor','k',...
          'FaceColor',colors(floor(strechedcolorchoser(2)),:));   
      
      rectangle('Position',[rdip(3,1)-0.115/2,rdip(3,2)-0.03/2,0.115,0.03],...
          'Curvature',[0.03],...
         'LineWidth',2,'LineStyle','-','EdgeColor','k',...
          'FaceColor',colors(floor(strechedcolorchoser(3)),:));   
         
        rectangle('Position',[rdip(4,1)-0.115/2,rdip(4,2)-0.03/2,0.115,0.03],...
          'Curvature',[0.03],...
         'LineWidth',2,'LineStyle','-','EdgeColor','k',...
          'FaceColor',colors(floor(strechedcolorchoser(4)),:));   
      
              rectangle('Position',[rdip(5,1)-0.115/2,rdip(5,2)-0.03/2,0.115,0.03],...
          'Curvature',[0.03],...
         'LineWidth',2,'LineStyle','-','EdgeColor','k',...
          'FaceColor',colors(floor(strechedcolorchoser(5)),:));   
      
      
      daspect([1,1,1])

      %%%Now we put the arrows that show the strength and direction of the
%%%dipoles.
startpos=0.25;
lengthar=0.2;
 beginA=0.25;
 EndA=0.25+0.1;
 


beginA=zeros(5,1);
EndA=zeros(5,1);
signo=sign(real(Pvector(:,1)));
cond=logical(signo>=1);
beginA(cond)=startpos;
EndA(cond)=startpos+lengthar;
beginA(not(cond))=startpos+lengthar;
EndA(not(cond))=startpos;


arrow([beginA(1),rdip(1,2)],[EndA(1),rdip(1,2)]);
arrow([beginA(2),rdip(2,2)],[EndA(2),rdip(2,2)]);
arrow([beginA(3),rdip(3,2)],[EndA(3),rdip(3,2)]);
arrow([beginA(4),rdip(4,2)],[EndA(4),rdip(4,2)]);
arrow([beginA(5),rdip(5,2)],[EndA(5),rdip(5,2)]);



end