
function RunnerArrayandScatterScanXYPoliestyrene
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');
p4 = path;
path(p4,'..\MicroscopeVision');   

muv=1;
epsilonv=1;
c=1;


%rdip=InitializeDipolePositions(38,1,'Array');

% positionsscann=[-0.05:0.005:0.05];

positionsscann=[-0.1:0.01:0.1];

[Xscan,Yscan]=meshgrid(positionsscann,positionsscann);

Xscan2=Xscan(:);
Yscan2=Yscan(:);

numposscan=size(Xscan(:),1);

fourierImagesXMat=zeros([200,198,numposscan]);
fourierImagesYMat=zeros([200,198,numposscan]);
fourierImagesExMat=zeros([200,198,numposscan]);
fourierImagesEyMat=zeros([200,198,numposscan]);


% TNOpos=[-3.5,1;-3,1;-2.5,1;-2,1;-2.75,0.5;-2.75,0;-2.75,-0.5;-2.75,-1;...
%     -1,-1;-1,-0.5;-1,0;-1,0.5;-1,1;-0.5,0.5;0,0;0.5,-0.5;1,-1;1,-0.5;1,0;1,0.5;1,1;...
%     2,0;2.29,0.71;3,1;3.71,0.71;4,0;3.71,-0.71;3,-1;2.29,-0.71];

%TNOpos=[-1,-1;-1,-0.5;-1,0;-1,0.5;-1,1;-0.5,0.5;0,0;0.5,-0.5;1,-1;1,-0.5;1,0;1,0.5;1,1];%this is an N
%TNOpos=[0,-1;0,-0.5;0,0;0,0.5;0,1];%This is a line
%TNOpos=[0,-1;0,-0.5;0,0;0,0.5;0,1;1,-1;1,-0.5;1,0;1,0.5;1,1];%This is a double vertical line
%TNOpos=[-1,0;-0.5,0;0,0;0.5,0;1,0;-1,1;-0.5,1;0,1;0.5,1;1,1];%This is a double horizontal line
%TNOpos=[-1,-1;-1,-0.5;-1,0;-1,0.5;-1,1;-0.5,0.5;0,0;0.5,-0.5;1,-1;1,-0.5;1,0;1,0.5;1,1];%this is an N
%TNOpos=[-3.5,1;-3,1;-2.5,1;-2,1;-2.75,0.5;-2.75,0;-2.75,-0.5;-2.75,-1]+repmat([2.75,0],8,1);%This is a T

%TNOpos=[-0.025,-0.025;0.025,0.025;0,0;-0.025,0.025;0.025,-0.025];%This is a T
TNOpos=[-0.045,-0.025;0.03,-0.025;0.03,0.025];
%TNOpos=[-0.045,-0.025;0,-0.025;0,0.025;0.03,0];

%scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos;deltax+xpos+0.05,deltay+ypos,zpos]; 
%TNOpos=[-0.05,0.025;-0.025,0.025; 0,0.025;0.025,0.025;0.05,0.025; 0,0.015;0,0.005;0,-0.005;0,-0.015;0,-0.025;0,-0.035;0,-0.045;0,-0.055];
 %TNOpos=(([2,0;2.29,0.71;3,1;3.71,0.71;4,0;3.71,-0.71;3,-1;2.29,-0.71]-repmat([3,0],8,1)))*(1/20)*(3/5);%This is an O

  
numscatTNO=size(TNOpos,1);
epsscatterers=6;
radius=0.02;



for ipos=1:numposscan
    
   xpos=Xscan2(ipos);
   ypos=Yscan2(ipos); 
    
    
%%%%%%%%%%%%%
linenumant=13;%please put odd numbers
numscatterers=numscatTNO;
  [xs,ys]=meshgrid(1:linenumant,1:linenumant);
  spacing=0.15;
  centershift=round(linenumant/2)*spacing;
  X=xs(:)*spacing-centershift;
     Y=ys(:)*spacing-centershift;
     rdipantnenna=[X,Y,Y*0];
     zpos=-0.05;    
%         deltay=0.03;
%         %deltay=0;
%         deltax=0;
%         if numscattererrs==2
%             scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos];
%         elseif numscattererrs==3
%             scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos;deltax+xpos+0.05,deltay+ypos,zpos];
%         elseif numscattererrs==1
%             scatterers=[-deltax+xpos,-deltay+ypos,zpos];
%         end

%scatterers=[TNOpos*0.1/4,repmat(zpos,numscatTNO,1)]+repmat([xpos,ypos,0],numscatTNO,1);%Scaled
scatterers=[TNOpos,repmat(zpos,numscatTNO,1)]+repmat([xpos,ypos,0],numscatTNO,1);%Not scaled

rdip=[rdipantnenna;scatterers];      
%%%%%%%%%%%%%

[w0list,gammalist,alist,blist]=InitializeListValuesAntennaLensArray(linenumant,0);

 direction=[0 0 -1];
    pol=[0 1 0];
    rsource=[0,0,0];
    
    lam=8000;
    
    omega=2*pi/(lam/1000);
    
    TheMat=TheMatrixFillerwithGenEpsilonScatterers(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv,numscatterers,epsscatterers,radius);
    TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveE,rdip,muv,epsilonv);
    %Pvector=TheMat\TheV;
    %valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@PlaneWaveE,TheV,TheMat,rdip);
        
   Radius=1800;
   NA=0.95;
   %NA=0.85;
   [x,y,Ebackx,Ebacky]=BackApertureNoImages(NA,Radius,TheV,TheMat,omega,muv,epsilonv,direction,pol,rsource,rdip);
    %[x,y,Ebackx,Ebacky]=BackAperture(NA,Radius,TheV,TheMat,omega,muv,epsilonv,direction,pol,rsource,rdip);
   fourierImagesXMat(:,:,ipos)=x(:,:);
   fourierImagesYMat(:,:,ipos)=y(:,:);
   fourierImagesExMat(:,:,ipos)=Ebackx(:,:);
   fourierImagesEyMat(:,:,ipos)=Ebacky(:,:);
   
   disp([num2str(ipos),' out of ',num2str(numposscan)])
end
    
nt=1;
Xscan2(nt)
Yscan2(nt)
figure(1)
pcolor(fourierImagesXMat(:,:,nt),fourierImagesYMat(:,:,nt),abs(fourierImagesExMat(:,:,nt)).^2);shading flat;axis image ;colorbar
 title({'|Ex|^2 back aperture/top/ missing jacobian, position',['x,y=',num2str([Xscan2(nt),Yscan2(nt)])]})

 %First type of unbalance check
 %this is half down-half up and half left minus half right.
 
unbalancex= (sum(sum(abs(fourierImagesExMat(1:100,:,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,:,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,:,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,:,:)).^2,1),2));
unbalancey= sum(sum(abs(fourierImagesExMat(:,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(:,100:198,:,:)).^2,1),2)./(sum(sum(abs(fourierImagesExMat(:,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(:,100:198,:,:)).^2,1),2));

sizescan=size(positionsscann,2);
figure(2)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancex),sizescan,sizescan))
title('unbalance in x fourier image')
figure(3)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancey),sizescan,sizescan))
 title('unbalance in y fourier image')
 
 %Second type of unbalance check
 %this is quarter down left minus quarter up rigth
 
 
 unbalancexy1= (sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2));
unbalancexy2= (sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2));

figure(4)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancexy2),sizescan,sizescan))
title('unbalance same side top-bottom fourier image')
 
unbalancexy3= (sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2));
figure(5)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancexy3),sizescan,sizescan))
title('unbalance corners 1 fourier image')
 
unbalancexy4= (sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2));
figure(6)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancexy4),sizescan,sizescan))
title('unbalance corners 2 fourier image')
 
 unbalancex2= (sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2));

figure(7)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancex2),sizescan,sizescan))
title('unbalance same side top-bottom fourier image')
 
 
  % drawpolarizabilityAntenna(Pvector,rdip);

figure(8)
pcolor(Xscan,Yscan,cumsum(rot90(reshape(squeeze(unbalancexy4),sizescan,sizescan),2),1))
title('integrated unbalance measure')

figure(9)
pcolor(Xscan,Yscan,rot90(cumsum((reshape(squeeze(unbalancexy4),sizescan,sizescan)),1),2))
title('integrated unbalance measure')
