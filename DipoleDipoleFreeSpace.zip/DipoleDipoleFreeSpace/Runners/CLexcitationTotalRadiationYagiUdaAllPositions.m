function vecplot=CLexcitationTotalRadiationYagiUdaAllPositions


p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');

muv=1;
epsilonv=1;
c=1;


Radius=10000000;
numberofpoints=50;

Ndip=5;

rdip=InitializeDipolePositions(Ndip,1,'YU1CL');%For the singlerod Ndip and dist do not matter.



YU=200;
[w0list,gammalist,alist,blist]=InitializeListVAluesCLYagiUda(YU);


%this is the CL or better dipole orientation and 
%pol is the orientation
%direction is not used at all
%rsource is the position of the dipole
    direction=[0 0 -1];
    pol=[0 0 1];
    %posit='edgeReflector';
    %  posit='edgefeed';
    % posit='edgedir1';
    %  posit='edgedir2';


    
    
thetapoints=[0:pi/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];

minlambda=400;
maxlambda=1000;
deltalambda=5;
vecplot=zeros(size([minlambda:deltalambda:maxlambda].',1),5);    
    
for positiondipoles=1:5
    

    if positiondipoles==1
         rsource=rdip(1,:)+[alist(1,:),0,0.03];
    elseif positiondipoles==2
         rsource=rdip(2,:)+[alist(2,:),0,0.03];
    elseif positiondipoles==3
         rsource=rdip(3,:)+[alist(3,:),0,0.03];
    elseif positiondipoles==4
         rsource=rdip(4,:)+[alist(4,:),0,0.03];
    elseif positiondipoles==5
         rsource=rdip(5,:)+[alist(5,:),0,0.03];
    end


cont=1;
for lam=minlambda:deltalambda:maxlambda
    omega=2*pi/(lam/1000);
    
    TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
    %save([directory, dia,'\',name,'.mat'],'TheMat');
   
        TheV=TheVectorFiller(omega, direction,pol,rsource,@DipoleEField,rdip,muv,epsilonv);
        valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@DipoleEField,TheV,TheMat,rdip);
        %TheV=TheVectorFiller(omega, direction,pol,rsource,@TransitionFieldE,rdip,muv,epsilonv);
        %valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@TransitionFieldE,TheV,TheMat,rdip);
               
        P0=(omega^4)/(12*pi*epsilonv*c^3); 
        vecplot(cont,positiondipoles)=(1/P0)*(1/2)*(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);   
    %([int2str(cont),' out of', int2str((maxlambda-minlambda)/deltalambda)])
    cont=cont+1;
end

end
figure(2)
wavelengths=[minlambda:deltalambda:maxlambda].';
plot(wavelengths,vecplot(:,1),wavelengths,vecplot(:,2),wavelengths,vecplot(:,3),wavelengths,vecplot(:,4),wavelengths,vecplot(:,5));

end