%function ForuerTimeCLexcitationTotalRadiationYagiUda

%p = path;
%path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');

muv=1;
epsilonv=1;
c=1;

Radius=10000000;
numberofpoints=50;

Ndip=5;
rdip=InitializeDipolePositions(Ndip,1,'YU1CL');%For the singlerod Ndip and dist do not matter.


%[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);
YU=1;
[w0list,gammalist,alist,blist]=InitializeListVAluesCLYagiUda(YU);
%[w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('reflector',1);
%[w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('feed',1)
%  [w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('dir1',1)
% [w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('dir2',1)
%[w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('dir3',1)


%this is the dipole excitaiton 
%pol is the orientation
%direction is not used at all
%rsource is the position of the dipole
    direction=[0 0 -1];
    pol=[0 0 1];
    %posit='edgeReflector';
    posit='edgefeed';
    %posit='edgedir1';
    %posit='edgedir2';
    %posit='edgedir3';
    if strcmp(posit,'edgeReflector')
         rsource=rdip(1,:)+[alist(1,:),0,0.03];
    elseif strcmp(posit,'edgefeed')
         rsource=rdip(2,:)+[alist(2,:),0,0.03];
    elseif strcmp(posit,'edgedir1')
         rsource=rdip(3,:)+[alist(3,:),0,0.03];
    elseif strcmp(posit,'edgedir2')
         rsource=rdip(4,:)+[alist(4,:),0,0.03];
    elseif strcmp(posit,'edgedir3')
         rsource=rdip(5,:)+[alist(5,:),0,0.03];
    end

%%Excitation in time is
omega=2*pi/0.7;
smpT=0.005;
smpF=1/smpT;
time=[0:smpT:10].';
Lsgn=size(time,1);
tau=1.5;
t0=5;
ft=exp(-100*((time-t0)/tau).^2).*cos(omega.*time+pi/4);
figure(1)
plot(time,ft);
NFFT = 2^nextpow2(Lsgn);
Fft=fft(ft,NFFT)/Lsgn; 
freq= smpF/2*linspace(0,1,NFFT/2+1);
% Plot single-sided amplitude spectrum.
figure(2)
plot(freq,2*abs(Fft(1:NFFT/2+1))) 
title('Single-Sided Amplitude Spectrum of f(t)')
xlabel('Frequency')
ylabel('|Fft(f)|') 
figure(3)
plot(1./freq,2*abs(Fft(1:NFFT/2+1))) 
title('Single-Sided Amplitude Spectrum of f(t)')
xlabel('wavelength')
ylabel('|Fft(lambda)|') 
%%%

figure(6+10)
plot(freq,2*imag(Fft(1:NFFT/2+1)),'-') 
figure(7+10)
plot(freq,2*real(Fft(1:NFFT/2+1)),'-') 

signalfrq=Fft(1:NFFT/2+1);
lengthsignal=size(freq,2);
retrievedft=ifft(signalfrq,Lsgn)*2*Lsgn;

figure(8+10)
% plot(freq,retrievedft(1:NFFT/2+1),'-') ;
plot(time, real(retrievedft),'-') ;
% Plot single-sided amplitude spectrum in wavelength.
%     
% thetapoints=[0:pi/(numberofpoints-1):pi]';
% phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
% 
% alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
% allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
% positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
wavelengths=1./freq;
% minlambda=400;
% maxlambda=1000;
% deltalambda=15;
% vecplot=zeros(size([minlambda:deltalambda:maxlambda].',1),1);
% dipolesFrq=zeros(size([minlambda:deltalambda:maxlambda].',1),3,Ndip);
%cont=1;
%vecplot=zeros(size([minlambda:deltalambda:maxlambda].',1),1);
dipolesFrq=zeros(size(wavelengths,2),3,Ndip);
wavelengths(1)=10^6;
for cont=1:size(wavelengths,2)
%lam=minlambda:deltalambda:maxlambda
    lam=wavelengths(cont);
    %omega=2*pi/(lam/1000);
    omega=2*pi/(lam);
    TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
    %save([directory, dia,'\',name,'.mat'],'TheMat');
    TheV=TheVectorFiller(omega, direction,pol,rsource,@DipoleEField,rdip,muv,epsilonv);
    dipolesFrq(cont,:,:)=reshape(reshape(TheMat\TheV,3,[]),1,3,[]);
    %valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@DipoleEField,TheV,TheMat,rdip);
     %TheV=TheVectorFiller(omega, direction,pol,rsource,@TransitionFieldE,rdip,muv,epsilonv);
     %valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@TransitionFieldE,TheV,TheMat,rdip);
     %   P0=(omega^4)/(12*pi*epsilonv*c^3); 
     %   vecplot(cont)=(1/P0)*(1/2)*(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);   
    %([int2str(cont),' out of', int2str((maxlambda-minlambda)/deltalambda)])
    %cont=cont+1;
end
plotdipoles=0;
if plotdipoles==1
%wavel=[minlambda:deltalambda:maxlambda].';
wavel=wavelengths.';
figure(4)
plot(wavel,imag(dipolesFrq(:,1,1)),'.',wavel,real(dipolesFrq(:,1,1)),'-');
title('Reflector x');
figure(5)
plot(wavel,imag(dipolesFrq(:,2,1)),'.',wavel,real(dipolesFrq(:,2,1)),'-');
title('Reflector y');
figure(6)
plot(wavel,imag(dipolesFrq(:,3,1)),'.',wavel,real(dipolesFrq(:,3,1)),'-');
title('Reflector z');
figure(7)
plot(wavel,imag(dipolesFrq(:,1,2)),'.',wavel,real(dipolesFrq(:,1,2)),'-');
title('feed x');
figure(8)
plot(wavel,imag(dipolesFrq(:,2,2)),'.',wavel,real(dipolesFrq(:,2,2)),'-');
title('feed y');
figure(9)
plot(wavel,imag(dipolesFrq(:,3,2)),'.',wavel,real(dipolesFrq(:,3,2)),'-');
title('feed z');
figure(10)
%plot(wavel,norm(dipolesFrq(:,:,1)),'.',wavel,norm(dipolesFrq(:,:,2)),'.',wavel,norm(dipolesFrq(:,:,3)),'.',wavel,norm(dipolesFrq(:,:,4)),'.',wavel,norm(dipolesFrq(:,:,5)),'.');
plot(wavel,sum(abs(dipolesFrq(:,:,1)),2),'-',wavel,sum(abs(dipolesFrq(:,:,2)),2),'-',wavel,sum(abs(dipolesFrq(:,:,3)),2),'-',wavel,sum(abs(dipolesFrq(:,:,4)),2),'-',wavel,sum(abs(dipolesFrq(:,:,5)),2),'-');
title('all');
end

figure(7)
plot(freq,imag(dipolesFrq(:,1,2)),'-',freq,real(dipolesFrq(:,1,2)),'-');
title('feed x');

figure(8)
plot(freq,imag(signalfrq.*dipolesFrq(:,1,2)),'-',freq,real(signalfrq.*dipolesFrq(:,1,2)),'-');
title('feed x multiplied by the fourier components');

%retrievedFeedXt=ifft(signalfrq.*dipolesFrq(:,1,2),Lsgn)*2*Lsgn;
retrievedFeedXt=ifft(signalfrq.*dipolesFrq(:,1,2),Lsgn)*2* Lsgn;
figure(11)
plot(time, abs(retrievedFeedXt),'-') ;
title('time evolution feed')
%plot(abs(retrievedFeedXt),'-') ;
%time evolution of the feed polarization in x direciton
retrieveddir2Xt=ifft(signalfrq.*dipolesFrq(:,1,4),Lsgn)*2* Lsgn;
figure(12)
plot(time, abs(retrieveddir2Xt),'-') ;
title('time evolution dir2')


figure(13)
plot(1./freq,abs(dipolesFrq(:,1,1)),'-',1./freq,abs(dipolesFrq(:,1,2)),'-',1./freq,abs(dipolesFrq(:,1,3)),'-',1./freq,abs(dipolesFrq(:,1,4)),'-',1./freq,abs(dipolesFrq(:,1,5)),'-');
xlim([0,1])
title('all elements x component')

figure(14)
plot(1./freq,abs(signalfrq.*dipolesFrq(:,1,1)),'-',1./freq,abs(signalfrq.*dipolesFrq(:,1,2)),'-',1./freq,abs(signalfrq.*dipolesFrq(:,1,3)),'-',1./freq,abs(signalfrq.*dipolesFrq(:,1,4)),'-',1./freq,abs(signalfrq.*dipolesFrq(:,1,5)),'-');
xlim([0,1])
title('all elements x component after multiplication with Fourier components')


%end