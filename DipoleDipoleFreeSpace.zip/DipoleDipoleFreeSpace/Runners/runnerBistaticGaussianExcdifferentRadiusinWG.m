function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
  ...  [sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
          [fieldsquare]=runnerBistaticGaussianExcdifferentRadiusinWG(lambda)

p = path;
%path(p,'..\WaveguideGreensFunctionQuadVGK');
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   
p4 = path;
path(p4,'..\MicroscopeVision');   
      



struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% %struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% t=0.1;
% %t=0;

%struct=[[1;1.000001;1],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%t=0.01;
t=0.1;

omega=2*pi/(lambda/1000);
%omega=pi;


Ndip=1;
%Ndip=1;
%rdip=InitializeDipolePositions(Ndip,1,name);%For the yagiUda Ndip and dist do not matter.

numposz=10;
minhz=5;
maxhz=40;
fieldsquare=zeros(numposz,2);

fieldsquare(:,1)=linspace(minhz,maxhz,numposz).';



rdip=[0,0,0.02];
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);
direction=[0 0 -1];
pol=[1 0 0];
rsource=[0 0 0];
numberofpoints=100;
TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);

polarizabilitytensor=inv(TheMat)
TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayeredGauss,rdip,struct,t)
Pvector=TheMat\TheV

% drawpolarizabilityAntenna(Pvector,rdip);
   
 %%%HEre we find what is the total intensity at [0,0,0] integral of
  %%%int(|E|^2dx^2)
rcentergauss=[0,0,0]; 
[Xint,Yint]=meshgrid(-2+rcentergauss(1):0.01:2+rcentergauss(1),-2+rcentergauss(2):0.01:2+rcentergauss(2)); 
xnew=Xint(:);
ynew=Yint(:);
rpos=[xnew,ynew,ynew*0+rdip(1,3)];
valfunEgauss= PlaneWaveELayeredGauss(2*pi/0.7,[0,0,-1],[1,0,0],rpos,rcentergauss,struct,t);
totalEsquareGaussian=sum(sum(valfunEgauss.*conj(valfunEgauss),2),1);
   %Now we have here the part for the incoupled ligth into the waveguide.
   %and we try to get what is the efficiency at which it incouples the
   %light
   numberofpointsincouping=20;
   numberpointsheight=10;

cont=1;
for RadiusIncoupling=linspace(minhz,maxhz,numposz)


   [vecplotcylinder,integratedint]=FieldGuidedCylinder(RadiusIncoupling,numberofpointsincouping, numberpointsheight,TheV,TheMat,omega,struct,t,direction,pol,rcentergauss,rdip);
   efficiencycoupling=integratedint/totalEsquareGaussian;
   EscatsqrIncouplingant=reshape(abs(vecplotcylinder(:,1)),numberofpointsincouping,[]);%sum(abs(vecplotparallel).^2,2);
   EscatsqrIncoupling=EscatsqrIncouplingant(:,floor(numberpointsheight/2));
  

   % figure(6)
   %polar(sigmaincoupling(:,1),sigmaincoupling(:,2),'.');
   
   fieldsquare(cont,2)= integratedint;
   cont=cont+1
end
   plot(fieldsquare(:,1),fieldsquare(:,2));
   
   