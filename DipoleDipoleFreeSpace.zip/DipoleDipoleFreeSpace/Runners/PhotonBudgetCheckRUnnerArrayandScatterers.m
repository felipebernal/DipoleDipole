p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');
p4 = path;
path(p4,'..\MicroscopeVision');   
close all
muv=1;
epsilonv=1;
c=1;
 epszero=8.854e-12;%F/m....A^2�s^4�kg^?1�m^?3
 co=2.99e-8;%m/s
 hpl=6.626e-34;




Radius=1000;
numberofpoints=200;

%rdip=InitializeDipolePositions(38,1,'Array');

%%%%%%%%%%%%% Definition of the structure
linenumant=9;%(please put odd numbers )This is the number n of antennas in a linear direction i.e.e.g nxn
numscattererrs=1; % This is the number of scatterers different from the antennas
%Definition of the position of the antennas 
[xs,ys]=meshgrid(1:linenumant,1:linenumant);
  spacing=0.15;
  centershift=round(linenumant/2)*spacing;
  X=xs(:)*spacing-centershift;
     Y=ys(:)*spacing-centershift;
     rdip=[X,Y,Y*0];
 %Definition of the position of the scatterers 
        xpos=0;
        ypos=0;
        zpos=-0.02;
        deltay=0*0.05/2;
        deltax=0.05;
        if numscattererrs==2
     scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos];
        elseif numscattererrs==3
            
           scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos;deltax+xpos+0.05,deltay+ypos,zpos]; 
        
        elseif numscattererrs==1
             scatterers=[-deltax+xpos,-deltay+ypos,zpos];
        end
    %JOined positions of the scatterers and the antennas
        rdip=[rdip;scatterers];
    


%%%%%%%%%%%%%

%definition of the values for the polarizabilities of the antennas and the
%scatterers
[w0list,gammalist,alist,blist]=InitializeListValuesAntennaLensArray(linenumant,numscattererrs);


 %blist=alist*1000000;
 %alist=alist*1000000;
 %gammalist=gammalist*0;
 
 %let's imagine that we illuminate the field of view which is 1 mm
 P0=0.001;%power in W
 radfoc=5e-6;%this is the radius of the focus for the incoming light (This is an aproximation since we work with plane waves)
 S0=P0/(pi*(radfoc)^2);%this is in W/m^2
E0m=sqrt((2*S0/(epszero*co)));%This is in V/m
E0=E0m*10^-6;%This is the field in V/micron
%Definition of the field excitation
direction=[0 0 -1];
pol=[0 E0 0];
rsource=[0,0,0];
    
lam=800;%wavelength in nm
omega=2*pi/(lam/1000);
    
%Calculation of the matrix with the polarizabilities
TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
%Calculation of the fields at the position of the scatterers
TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveE,rdip,muv,epsilonv);
%Calculation of the dipolar moments induced by the field
Pvector=TheMat\TheV
%valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@PlaneWaveE,TheV,TheMat,rdip);
        
    
   if 1>-1
   Radius=1800;
   NA=0.95;
   %NA=0.85;
   [x,y,Ebackx,Ebacky]=BackAperture(NA,Radius,TheV,TheMat,omega,muv,epsilonv,direction,pol,rsource,rdip);
   
   nfigs = get(0,'Children');
   plotflag=size(nfigs,1);
   
   
  
   photenerg=hpl*co/(lam*1e-9);
   con1omicrto1ovm=10^6;%change of 1/micron to 1/m
   %Plot of the number of photons per second per square meter
   photpersperm=(1/photenerg)*(1/2)*epszero*co*abs(Ebackx*con1omicrto1ovm).^2;%[photons/(s.m^2)
   figure(plotflag+1)
   pcolor(Radius*x/1000,Radius*y/1000,photpersperm);shading flat;axis image ;colorbar
   title('[photons/(s.m^2)] back aperture/top/ missing jacobian')
   xlabel('position (mm)')
   ylabel('position (mm)')
   
   
   toalnumphot=sum(sum(photpersperm,1),2)*pi*(Radius*NA)^2;
   %Plot of the integrated phot per pixel per second
   
%    xcheck=[-1500:6:1500];
%    ycheck=[-1500:6:1500];
%    fpix=interp2(0,0,photpersperm,Radius*x,Radius*y);
   
   XX=Radius*x;
   YY=Radius*y;
   VV=photpersperm;
   F=scatteredInterpolant(XX(:),YY(:),VV(:),'linear','none');
  
   pixellen=6;%6 microns
   convmtousq=10^-12;%this is the conversion from 1/square meters to 1/square microns
   xcheck=[-2000:pixellen:2000];
   [xq,yq] = meshgrid(xcheck,xcheck);
   fpix=convmtousq*pixellen^2*F(xq,yq);
   figure(plotflag+4)
   pcolor(xq,yq,fpix);shading flat;axis image ;colorbar
    title(['[photons/(s.px)] input power=',num2str(P0*1000),'mW'])
   xlabel('position (\mum)')
   ylabel('position (\mum)')
   
   
     
   fmicroscope=1800;%microns
   ftubelens=100000;%microns
   nlenses=1.5; %refractive index of the lenses used
   [Efocal,numpixelsx,xgrid,ygrid]=microscopevision(omega,TheMat,TheV,rdip,fmicroscope,NA,ftubelens,nlenses,muv,epsilonv);
   matrixintensity=reshape(sqrt(sum(Efocal.*conj(Efocal),2)),numpixelsx,numpixelsx);
   

   figure(plotflag+2)
   imagesc(xgrid,ygrid,matrixintensity);
   colormap(hot)
   title('Microscope image (|E|)')
   xlabel('X')
   ylabel('Y')
   colorbar
   %cross polarized
%    numpointsfield=size(Efocal,3);
   Polarizer=[1,0,0];
   [Efocalpol,numpixelsxpol,xgridpol,ygridpol]=microscopevisionpolarized(omega,TheMat,TheV,rdip,fmicroscope,NA,ftubelens,nlenses,muv,epsilonv,Polarizer);
    matrixintensitypolarized=reshape(sqrt(sum(Efocalpol.*conj(Efocalpol),2)),numpixelsxpol,numpixelsxpol);
   figure(plotflag+3)
   imagesc(xgridpol,ygridpol,matrixintensitypolarized);
   colormap(hot)
   title('Microscope image (|E|)')
   xlabel('X')
   ylabel('Y')
   colorbar
   
  % drawpolarizabilityAntenna(Pvector,rdip);
   
end