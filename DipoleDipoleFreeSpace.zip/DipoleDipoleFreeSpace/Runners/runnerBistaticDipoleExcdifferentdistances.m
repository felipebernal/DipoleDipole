function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
  ...  [sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
          [couplingefficiencies]=runnerBistaticDipoleExcdifferentdistances(lambda)
      name='yagiuda';
p = path;
%path(p,'..\WaveguideGreensFunctionQuadVGK');
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   
p4 = path;
path(p4,'..\MicroscopeVision');   
      


c=1;
eps0=1;
mu0=1;
struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;12;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)

% %struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% t=0.1;
% %t=0;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);



%struct=[[1;1.000001;1],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%t=0.01;
t=0.1;

omega=2*pi/(lambda/1000);
%omega=pi;

Ndip=2;
%Ndip=1;
%rdip=InitializeDipolePositions(Ndip,1,name);%For the yagiUda Ndip and dist do not matter.

numposl=100;
minl=0.06;
maxl=3;
couplingefficiencies=zeros(numposl,1);

couplingefficiencies(:,1)=linspace(minl,maxl,numposl).';
cont=1;
Radius=100;
for heig=linspace(minl,maxl,numposl)

if  Ndip==1
 rdip=[0,0,heig];   
elseif  Ndip==2
 rdip=[0,0,0.03;
     0,0.4934*heig,0.03];   
 elseif  Ndip==3
  rdip=[0, -0.4934*heig,0.03;
      0,0,0.03;
      0, 0.4934*heig,0.03];   
  elseif  Ndip==4
  rdip=[0, -3*(0.4934/2)*heig,0.03;
      0, -(0.4934/2)*heig,0.03;
        0, (0.4934/2)*heig,0.03;
        0, 3*(0.4934/2)*heig,0.03;
        ]; 
end

[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);
direction=[1 0 0];
pol=[1 0 0];%this one is not used here
dipoleheightplus=0.01;

rsource=rdip(1,:)+[0,0,dipoleheightplus];%this one is very important cause it defines what is the position of the dipole point.
numberofpoints=500;
TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
polari=1/(TheMat(1,1));

TheV=TheVectorFiller(omega, direction,pol,rsource,@DipoleEFieldLayered,rdip,struct,t);
%[vecplotparallel,vecplotperpedicular]= FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);

Pvectortemp=TheMat\TheV;
Pvector=reshape(Pvectortemp,3,Ndip).';
TheVarr=reshape(TheV,3,Ndip).';
Pextintion=(omega/2)*imag(sum(sum(Pvector.*conj(TheVarr),2),1));

%Now we find the power scattered out of plane
%first on top

thetarange=pi/2;
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end)),(numberofpoints))];
allphi=[0;repmat(phipoints,(numberofpoints-1),1)];

positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@DipoleEFieldLayered,TheV,TheMat,rdip);
vecplotTOP=(1/2)*sqrt((eps0*eps1)/(mu0*mu1))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);

%Now for the bottom
thetarange=pi/2-(pi/2)/(numberofpoints);
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end)),(numberofpoints))];
allphi=[0;repmat(phipoints,(numberofpoints-1),1)];

positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),-Radius*cos(alltheta)];%notice the minus in front of the angle for z
valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@DipoleEFieldLayered,TheV,TheMat,rdip);
vecplotBOTTOM=(1/2)*sqrt((eps0*eps3)/(mu0*mu3))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);

Pscattered=vecplotTOP+vecplotBOTTOM;




%%%
%EIncomingfield=PlaneWaveELayeredGauss(omega,direction,pol,rdip,rdip,struct,t);
%EIncomingfield=PlaneWaveE(omega,direction,pol,rdip,[0,0,0],struct,t);
%POWincoming=eps0*c*sum(EIncomingfield.*conj(EIncomingfield),2)/2;
%

%So the power got into the waveguide is

Pwaveguide=Pextintion-Pscattered;
%efficiencycoupling=Pwaveguide/Pextintion; %This would be the portion of the
%work absorved or incoupled
%efficiencycoupling=Pwaveguide/POWincoming;%This would be the portion of the
%incoming power from the plane wave absorved or incoupled
efficiencycoupling=Pwaveguide/Pextintion;%This would be the portion of the

couplingefficiencies(cont,2)= efficiencycoupling;
cont=cont+1
end
plot(couplingefficiencies(:,1),couplingefficiencies(:,2));
% TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayeredGauss,rdip,struct,t);
% 
% Pvector=TheMat\TheV
% 
%   % drawpolarizabilityAntenna(Pvector,rdip);
%    
%  %%%HEre we find what is the total intensity at [0,0,0] integral of
%   %%%int(|E|^2dx^2)
% rcentergauss=[0,0,0]; 
% [Xint,Yint]=meshgrid(-2+rcentergauss(1):0.01:2+rcentergauss(1),-2+rcentergauss(2):0.01:2+rcentergauss(2)); 
% xnew=Xint(:);
% ynew=Yint(:);
% rpos=[xnew,ynew,ynew*0+rdip(1,3)];
% valfunEgauss= PlaneWaveELayeredGauss(2*pi/0.7,[0,0,-1],[1,0,0],rpos,rcentergauss,struct,t);
% totalEsquareGaussian=sum(sum(valfunEgauss.*conj(valfunEgauss),2),1);
%    %Now we have here the part for the incoupled ligth into the waveguide.
%    %and we try to get what is the efficiency at which it incouples the
%    %light
%    numberofpointsincouping=20;
%    numberpointsheight=10;
%    
%    RadiusIncoupling=5;
%    
%    [vecplotcylinder,integratedint]=FieldGuidedCylinder(RadiusIncoupling,numberofpointsincouping, numberpointsheight,TheV,TheMat,omega,struct,t,direction,pol,rcentergauss,rdip);
%    efficiencycoupling=integratedint/totalEsquareGaussian;
%    EscatsqrIncouplingant=reshape(abs(vecplotcylinder(:,1)),numberofpointsincouping,[]);%sum(abs(vecplotparallel).^2,2);
%    EscatsqrIncoupling=EscatsqrIncouplingant(:,floor(numberpointsheight/2));
%    sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',EscatsqrIncoupling];
% 
%    % figure(6)
%    %polar(sigmaincoupling(:,1),sigmaincoupling(:,2),'.');
%    
%    couplingefficiencies(cont,2)= efficiencycoupling;
%    cont=cont+1
% end
%    plot(couplingefficiencies(:,1),couplingefficiencies(:,2));
%    
   