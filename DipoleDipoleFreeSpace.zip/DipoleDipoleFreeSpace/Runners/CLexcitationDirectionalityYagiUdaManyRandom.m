function Matrixdirectivity=CLexcitationDirectionalityYagiUdaManyRandom

%p = path;
%path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');

%guided=0; %0 means free space and 1 means guided

%struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive
% %index database for siN is 2.00347)
% t=0.1;

muv=1;
epsilonv=1;
c=1;
%struct=[[1;1;1],[1;1;1]];%for glass the n is 1.45846(refractive
%index database for siN is 2.00347)
%t=0.1;

Radius=10000000;
numberofpoints=50;

Ndip=5;
%rdip=InitializeDipolePositions(Ndip,1,'yagiuda');%For the yagiUda Ndip and dist do not matter.
%rdip=InitializeDipolePositions(Ndip,1,'singlerod');%For the singlerod Ndip and dist do not matter.
rdip=InitializeDipolePositions(Ndip,1,'YU1CL');%For the singlerod Ndip and dist do not matter.


%[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);
%YU=7;


%day=date;
%day='19-Nov-2011';

thetapoints=[0:pi/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];

minlambda=550;
maxlambda=1000;
deltalambda=2.5;



 alist=[0.063;0.0525;0.0475;0.0475;0.0475];
 numantenn=5000;
%random aleatorium distribution
if -1>1
 randommat=rand(5,numantenn);
 randommatsign=sign(rand(5,numantenn)-0.5);
 randomnumbers=(randommat*0.0025).*randommatsign;
 ALIST=repmat(alist,1,numantenn)+randomnumbers;
end
 %random normal distribution
  randommat=0.0025*randn(5,numantenn); %numbers with standard deviation 2.5
  ALIST=repmat(alist,1,numantenn)+randommat;
 
lambdas=[0.5;0.5;0.5;0.5;0.5];%this is in microns
w0list=2*pi*(c./lambdas); 
blist=[0.025;0.025;0.025;0.025;0.025];
gammalist=[0.325;0.325;0.325;0.325; 0.325];


Matrixdirectivity=zeros(numantenn,10);
t=zeros(numantenn,1);

for YU=1:numantenn
tic;
totaltime=sum(t,1);
    disp(['antena number ',num2str(YU),' out of ',num2str(numantenn)]);
    if YU~=1
    timetogo=((totaltime/(YU-1))*numantenn-totaltime);
    disp(['time to go ',num2str(timetogo),' sec']);
    end
%[w0list,gammalist,alist,blist]=InitializeRandomListVAluesCLYagiUda(YU);
alist=ALIST(:,YU);

%this is the CL or better dipole orientation and 
%pol is the orientation
%direction is not used at all
%rsource is the position of the dipole
    direction=[0 0 -1];
    pol=[0 0 1];
    %posit='edgeReflector';
    %  posit='edgefeed';
    % posit='edgedir1';
    %  posit='edgedir2';
     posit='edgefeed';
     if strcmp(posit,'edgeReflector')
         rsource=rdip(1,:)+[alist(1,:),0,0.03];
    elseif strcmp(posit,'edgefeed')
         rsource=rdip(2,:)+[alist(2,:),0,0.03];
    elseif strcmp(posit,'edgedir1')
         rsource=rdip(3,:)+[alist(3,:),0,0.03];
    elseif strcmp(posit,'edgedir2')
         rsource=rdip(4,:)+[alist(4,:),0,0.03];
    elseif strcmp(posit,'edgedir3')
         rsource=rdip(5,:)+[alist(5,:),0,0.03];
    end



vecplot=zeros(size([minlambda:deltalambda:maxlambda].',1),1);
Dir=zeros(size([minlambda:deltalambda:maxlambda].',1),size(allphi,1));
LDOS=zeros(size([minlambda:deltalambda:maxlambda].',1),1);
c=1;
cont=1;
for lam=minlambda:deltalambda:maxlambda
    omega=2*pi/(lam/1000);
    
    TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
    %save([directory, dia,'\',name,'.mat'],'TheMat');
    TheV=TheVectorFiller(omega, direction,pol,rsource,@DipoleEField,rdip,muv,epsilonv);
    valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@DipoleEField,TheV,TheMat,rdip);
    P0=(omega^4)/(12*pi*epsilonv*c^3); 
    powerperangle=(1/2)*c*(Radius^2)*sum(valE.*conj(valE),2);
    Ptot=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*sum(sin(alltheta).*powerperangle,1); 
    Dir(cont,:)=(4*pi*powerperangle/Ptot).';
    LDOS(cont)=Ptot/P0;
    %vecplot(cont)=(1/P0)*(1/2)*(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);   
    %([int2str(cont),' out of', int2str((maxlambda-minlambda)/deltalambda)])
    cont=cont+1;
end

%a=[[minlambda:deltalambda:maxlambda].',vecplot];
%save(['\\nanorfsrv\Users\Bernal\Simulations\',day,'\TotalScattCrossSecYagiUda.txt'], 'a','-ascii');

%WE know that ther are two peaks, one centered at around 690 nm and the second centered at 822 nm, therefore we need to divide the
%wavelenght range to find the directivity of peak 1 one and peak 2

centerrange=(813+674)/2;
wavelengths=[minlambda:deltalambda:maxlambda].';
[delatas,indexdelatas]=min(abs(wavelengths-centerrange));
indexcenter=indexdelatas;
wavelengths1=wavelengths(1:indexcenter-1);
wavelengths2=wavelengths(indexcenter:end);

Dir1=Dir(1:indexcenter-1,:);
Dir2=Dir(indexcenter:end,:);

[directivity1,angleindic1]=max(Dir1,[],2);
[directivity2,angleindic2]=max(Dir2,[],2);
anglesphidir1=allphi(angleindic1)/pi*180;
anglesthetadir1=alltheta(angleindic1)/pi*180;
anglesphidir2=allphi(angleindic2)/pi*180;
anglesthetadir2=alltheta(angleindic2)/pi*180;
[maxdirect1,direcindic1]=max(directivity1);
[maxdirect2,direcindic2]=max(directivity2);
wavemaxdirect1=wavelengths1(direcindic1);
wavemaxdirect2=wavelengths2(direcindic2);
anglephimaxdirect1=anglesphidir1(direcindic1);
anglethetamaxdirect1=anglesthetadir1(direcindic1);
anglephimaxdirect2=anglesphidir2(direcindic2);
anglethetamaxdirect2=anglesthetadir2(direcindic2);
[maxLDOS,indicLDOS]=max(LDOS,[],1);
waveLDOS=wavelengths(indicLDOS);
Matrixdirectivity(YU,:)=[maxdirect1,wavemaxdirect1,maxdirect2,wavemaxdirect2,anglephimaxdirect1,anglephimaxdirect2,anglethetamaxdirect1,anglethetamaxdirect2,maxLDOS,waveLDOS];
t(YU)=toc;
end

figure(1)
plot(Matrixdirectivity(:,1),'.')
figure(2)
plot(Matrixdirectivity(:,2),'.')
figure(3)
plot(Matrixdirectivity(:,3),'.')
figure(4)
plot(Matrixdirectivity(:,4),'.')
figure(5)
hist(Matrixdirectivity(:,1))
title('Directivity low wavelength peak')
figure(6)
[nelLowWave,centersLowWave]=hist(Matrixdirectivity(:,2));
title('Wavelength low wavelength peak')
figure(7)
hist(Matrixdirectivity(:,3))
title('Directivity high wavelength peak')
figure(8)
[nelHighWave,centersHighWave]=hist(Matrixdirectivity(:,4));
title('Wavelength high wavelength peak')
figure(9)
hist(Matrixdirectivity(:,5))
title('anglephimaxdirect1')
figure(10)
hist(Matrixdirectivity(:,6))
title('anglephimaxdirect2')
figure(11)
hist(Matrixdirectivity(:,7))
title('anglethetamaxdirect1')
figure(12)
hist(Matrixdirectivity(:,8))
title('anglethetamaxdirect2')
figure(13)
hist(Matrixdirectivity(:,9))
title('maxLDOS')
figure(14)
hist(Matrixdirectivity(:,10))
title('waveLDOS')
figure(15)
bar([centersLowWave,centersHighWave],[nelLowWave,nelHighWave]);
%------------------------------------------------------
% 
% [directivity,angleindic]=max(Dir,[],2);
% 
% % figure(1)
% % plot(wavelengths,directivity);
% % title('Directivity vs. Wavelength')
% 
% % figure(2)
% % plot(wavelengths,allphi(angleindic)/pi*180,[minlambda:deltalambda:maxlambda].',alltheta(angleindic)/pi*180);
% % title('Directivity vs. Anglephi and Theta')
% % legend('phi','theta');
% % vecplot=[wavelengths,max(Dir,[],2)];
% %we also need to find what is the wavelength at which this directivity is
% %maximum.
% anglesphidir=allphi(angleindic)/pi*180;
% anglesthetadir=alltheta(angleindic)/pi*180;
% [maxdirect,direcindic]=max(directivity);
% wavemaxdirect=wavelengths(direcindic);
% anglephimaxdirect=anglesphidir(direcindic);
% anglethetamaxdirect=anglesthetadir(direcindic);
% [maxLDOS,indicLDOS]=max(LDOS,[],1);
% waveLDOS=wavelengths(indicLDOS);
% Matrixdirectivity(YU,:)=[maxdirect,wavemaxdirect,anglephimaxdirect,anglethetamaxdirect,maxLDOS,waveLDOS];
% end
% 
% figure(1)
% plot(Matrixdirectivity(:,1),'.')
% figure(2)
% plot(Matrixdirectivity(:,2),'.')
% figure(3)
% plot(Matrixdirectivity(:,3),'.')
% figure(4)
% plot(Matrixdirectivity(:,4),'.')
% figure(5)
% hist(Matrixdirectivity(:,1))
% figure(6)
% hist(Matrixdirectivity(:,2))
% figure(7)
% hist(Matrixdirectivity(:,3))
% figure(8)
% hist(Matrixdirectivity(:,4))
% figure(9)
% hist(Matrixdirectivity(:,5))
% figure(10)
% hist(Matrixdirectivity(:,6))

end
