
function [Eigenvalue1,Eigenvalue2,dall,LS]=DimerDistanceEigenvaluePolarizabilities
p = path;
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   


struct=[[1;4.01;2.127],[1;1;1]];
%struct=[[1;1.000001;1.000001],[1;1;1]];

eps0=1;
mu0=1;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);
c=1;

t=0.1;

Li=0.5;
Lf=2;
% Li=0.7;
% Lf=0.9;
numL=20;
LS=linspace(Li,Lf,numL);

dmax=2;
dmin=0.09;
% dmax=10;
% dmin=5;
numh=50;
%dall=logspace(log10(dmax),log10(dmin),numh);
dall=linspace((dmax),(dmin),numh);
Eigenvalue1=zeros(3,3,numL,numh);
Eigenvalue2=zeros(3,3,numL,numh);
Ndip=2;
for conth=1:numh
for conti=1:numL

lambda=LS(conti);
omega=2*pi/lambda;
k=omega/c;

heig=0.07;

%dipole positions
dist=dall(conth);
rdip=[0,0,heig;dist,0,heig];
rdipi=rdip(1,:);
rdipj=rdip(2,:);

%dipole strength
lambdas=[0.8];%this is in microns
w0=2*pi*(c./lambdas);
a=[0.06];
b=[0.06];
gamma=[3.9];
%polarizability
INValphastatic=inv(PolarizabilityProlate(omega,w0,gamma,a,b,struct));
diagonalCorrectionterm=-((omega.^2)*mu0*mu1)*1i*imag(GreenWaveguide(k,rdipi,rdipi,struct,t))-1i*((k)^2*(mu1)/(eps0))*(omega/(6*pi*c))*eye(3);
offdiagonalCorrectionterm=((omega.^2)*mu0*mu1)*(GreenWaveguide(k,rdipi,rdipj,struct,t)+FreeDyadG(k,rdipi,rdipj));
% diagonalCorrectionterm=-((omega.^2)*mu0*mu1)*GreenWaveguide(k,rdipi,rdipi,struct,t)-1i*((k)^2*(mu1)/(eps0))*(omega/(6*pi*c))*eye(3);
% offdiagonalCorrectionterm=((omega.^2)*mu0*mu1)*(GreenWaveguide(k,rdipi,rdipj,struct,t)+FreeDyadG(k,rdipi,rdipj));
% diagonalCorrectionterm=-1i*((k)^2*(mu1)/(eps0))*(omega/(6*pi*c))*eye(3);
% offdiagonalCorrectionterm=((omega.^2)*mu0*mu1)*(FreeDyadG(k,rdipi,rdipj));

Eigenvalue1(:,:,conti,conth)=inv(INValphastatic+diagonalCorrectionterm+offdiagonalCorrectionterm);
Eigenvalue2(:,:,conti,conth)=inv(INValphastatic+diagonalCorrectionterm-offdiagonalCorrectionterm);
conti
  
end
conth
end
figure(1)
plot(LS,squeeze(imag(Eigenvalue2(1,1,:,:))))
title('Im[alpha]xx vs wavelength Eigenvalue2')
figure(2)
plot(LS,squeeze(imag(Eigenvalue2(2,2,:,:))))
title('Im[alpha]yy vs wavelength Eigenvalue2')
figure(3)
plot(LS,squeeze(imag(Eigenvalue2(2,2,:,:))))
title('Im[alpha]zz vs wavelength Eigenvalue2')

figure(4)
plot(dall,max(squeeze(imag(Eigenvalue2(1,1,:,:))),[],1),'.')
title('max Im[alpha]xx vs distance between particles Eigenvalue2')
figure(5)
plot(dall,max(squeeze(imag(Eigenvalue2(2,2,:,:))),[],1),'.')
title('max Im[alpha]yy vs distance between particles Eigenvalue2')
figure(6)
plot(dall,max(squeeze(imag(Eigenvalue2(3,3,:,:))),[],1),'.')
title('max Im[alpha]zz vs distance between particles Eigenvalue2')



figure(7)
plot(LS,squeeze(imag(Eigenvalue1(1,1,:,:))))
title('Im[alpha]xx vs wavelength Eigenvalue1')
figure(8)
plot(LS,squeeze(imag(Eigenvalue1(2,2,:,:))))
title('Im[alpha]yy vs wavelength Eigenvalue1')
figure(9)
plot(LS,squeeze(imag(Eigenvalue1(2,2,:,:))))
title('Im[alpha]zz vs wavelength Eigenvalue1')

figure(10)
plot(dall,max(squeeze(imag(Eigenvalue1(1,1,:,:))),[],1),'.')
title('max Im[alpha]xx vs distance between particles Eigenvalue1')
figure(11)
plot(dall,max(squeeze(imag(Eigenvalue1(2,2,:,:))),[],1),'.')
title('max Im[alpha]yy vs distance between particles Eigenvalue1')
figure(12)
plot(dall,max(squeeze(imag(Eigenvalue1(3,3,:,:))),[],1),'.')
title('max Im[alpha]zz vs distance between particles Eigenvalue1')




