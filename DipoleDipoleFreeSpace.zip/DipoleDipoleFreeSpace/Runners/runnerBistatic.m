function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
  ...  [sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
         ... [sigmascatparallel, sigmascatperpend,TheMat,TheV,omega,rdip,struct,t,Pvector,integratedint,efficiencycoupling]=runnerBistatic(Radius,lambda)
        [efficiencycoupling]=runnerBistatic(Radius,lambda)
      name='yagiuda';
p = path;
%path(p,'..\WaveguideGreensFunctionQuadVGK');
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   
p4 = path;
path(p4,'..\MicroscopeVision');   
      
clear('Greenscube');
clear('CurlGreenscube');

c=1;
eps0=1;
mu0=1;
struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;1.000000001;1.000000001],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;100;100],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)

% t=0.1;
% %t=0;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

%t=0;
t=0.1;

omega=2*pi/(lambda/1000);
%omega=pi;


Ndip=5;
%Ndip=2;
rdip=InitializeDipolePositions(Ndip,1,name);%For the yagiUda Ndip and dist do not matter.
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);

direction=[0 0 -1];
pol=[1 0 0];
rsource=[0 0 0];

numberofpoints=100;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date; 

if exist([directory, dia])==0
    mkdir([directory, dia]);
    
    TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
    %save([directory, dia,'\',name,'.mat'],'TheMat');
    TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayered,rdip,struct,t);
   
    [vecplotparallel,vecplotperpedicular]= FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
else
    if exist([directory, dia,'\',name,'.mat'])==0
         TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
        %save([directory, dia,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
         %TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayered,rdip,struct,t);
          TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayered,rdip,struct,t);
        [vecplotparallel,vecplotperpedicular]= FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
    
    else
        %Structi=load([directory, dia,'\',name,'.mat']);
        %TheMat=Structi.TheMat;
         TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
        TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayered,rdip,struct,t);
        
        
        [vecplotparallel,vecplotperpedicular]= FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
    end
end
    Pvector=TheMat\TheV;

if 1<-1 
 %%%%This part gives the bistatic scattering cross section
    Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
    sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrparallel];
    Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
    sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* Escatsqrperpendm];
    %save([directory, dia,'\',name,'DrawingparallelperpendMatrix.mat'],'sigmascatparallel','sigmascatperpend'); 
    figure(1)
    polar(sigmascatparallel(:,1),sigmascatparallel(:,2));
    figure(2)
    polar(sigmascatperpend(:,1),sigmascatperpend(:,2));
    figure(3)
    polar([sigmascatparallel(:,1);NaN;sigmascatperpend(:,1)],[sigmascatparallel(:,2);NaN;sigmascatperpend(:,2)]); 
end
if -1>1
%%%%This part gives the Fourier image of the sample
   NA=0.95;
   %NA=0.85;
   BackAperture(NA,Radius,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
 %%%%This part gives the Fourier microscopeimage  
   fmicroscope=1800;%microns
   ftubelens=100000;%microns
   nlenses=1.5; %refractive index of the lenses used
   [Efocal,numpixelsx,xgrid,ygrid]=microscopevision(omega,TheMat,TheV,rdip,fmicroscope,NA,ftubelens,nlenses,struct,t);
   matrixintensity=reshape(sqrt(sum(Efocal.*conj(Efocal),2)),numpixelsx,numpixelsx);
   figure(5)
   imagesc(xgrid,ygrid,matrixintensity);
   colormap(hot)
   title('Microscope image')
   xlabel('X')
   ylabel('Y')
   
drawpolarizabilityAntenna(Pvector,rdip);
   
end 
   
 if 1>-1  
%This part for the incoupled ligth into the waveguide in the greens function way...very slow.
   numberofpointsincouping=50;
   RadiusIncoupling=20;
   vecplotcircle=FieldGuidedCircleBistaticCrossSec(RadiusIncoupling,numberofpointsincouping,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
   
    %EscatsqrIncoupling=sum( vecplotcircle.*conj( vecplotcircle),2);%sum(abs(vecplotparallel).^2,2);
    EscatsqrIncoupling=abs(vecplotcircle(:,1));%sum(abs(vecplotparallel).^2,2);
    %sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',2*pi*RadiusIncoupling*EscatsqrIncoupling];
    sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',EscatsqrIncoupling];
    figure(6)
   polar(sigmaincoupling(:,1),sigmaincoupling(:,2),'.');
   integratedint=1;
 end 

%    %Now we have here the part for the incoupled ligth into the waveguide.
%    %and we try to get what is the efficiency at which it incouples the
%    %light
%    numberofpointsincouping=50;
%    numberpointsheight=5;
%    RadiusIncoupling=10;
%    [vecplotcylinder,integratedint]=FieldGuidedCylinder(RadiusIncoupling,numberofpointsincouping, numberpointsheight,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
%    
%   
%    integratedint
%    
%     %EscatsqrIncoupling=sum( vecplotcircle.*conj( vecplotcircle),2);%sum(abs(vecplotparallel).^2,2);
%     %EscatsqrIncoupling=reshape(sum(reshape(abs(vecplotcylinder(:,1)),numberpointsheight,[]),1),[],1);%sum(abs(vecplotparallel).^2,2);
%     EscatsqrIncouplingant=reshape(abs(vecplotcylinder(:,1)),numberpointsheight,[]);%sum(abs(vecplotparallel).^2,2);
%     EscatsqrIncoupling=EscatsqrIncouplingant(2,:).';
%     %sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',2*pi*RadiusIncoupling*EscatsqrIncoupling];
%     sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',EscatsqrIncoupling];
%     figure(6)
%    polar(sigmaincoupling(:,1),sigmaincoupling(:,2),'.');
% 
%    
   
%%%%%%here we found how much gets incoupled into the waveguide in the other
%%%%%%way
if 1<-1
numberofpoints=400;
Radius=1;
Pvectorlong=reshape(Pvector,3,Ndip).';

TheVarr=reshape(TheV,3,Ndip).';%this is only the values of the incident field at the dipoles position

%TheVarr0=reshape(TheV,3,Ndip).';%this is only the values of the incident field at the dipoles position
%TheVarrScatt=FieldEfinder('scatt','near',rdip,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);%Here we find the reflected field from the dipoles.
% 
% Pextintion0=(omega/2)*imag(sum(sum(Pvectorlong.*conj(TheVarr0),2),1));
% PextintionScatt=(omega/2)*imag(sum(sum(conj(Pvectorlong).*TheVarrScatt,2),1));
% Pextintion=Pextintion0-PextintionScatt;

Pextintion=(omega/2)*imag(sum(sum(Pvectorlong.*conj(TheVarr),2),1));



%Now we find the power scattered out of plane
%first on top

thetarange=pi/2;
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end)),(numberofpoints))];
allphi=[0;repmat(phipoints,(numberofpoints-1),1)];

positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
vecplotTOP=(1/2)*sqrt((eps0*eps1)/(mu0*mu1))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);

%Now for the bottom
thetarange=pi/2-(pi/2)/(numberofpoints);
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end)),(numberofpoints))];
allphi=[0;repmat(phipoints,(numberofpoints-1),1)];

positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),-Radius*cos(alltheta)];%notice the minus in front of the angle for z
valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
vecplotBOTTOM=(1/2)*sqrt((eps0*eps3)/(mu0*mu3))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);

Pscattered=vecplotTOP+vecplotBOTTOM;


%So the power got into the waveguide is

Pwaveguide=Pextintion-Pscattered;

efficiencycoupling=Pwaveguide/Pextintion;%This would be the portion of the
end  