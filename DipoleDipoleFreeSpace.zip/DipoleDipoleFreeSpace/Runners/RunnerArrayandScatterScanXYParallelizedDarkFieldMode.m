%%%
%function RunnerArrayandScatterScanXY
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');
p4 = path;
path(p4,'..\MicroscopeVision');   

muv=1;
epsilonv=1;
c=1;
epszero=8.854e-12;%F/m....A^2�s^4�kg^?1�m^?3
co=2.99e8;%m/s
hpl=6.626e-34;
eps0=1;
eps1=1;
eps3=1;
mu3=1;
mu1=1;
mu0=1;
lam=845;%wavelength in nm

Radius=1000;
numberofpoints=200;

%rdip=InitializeDipolePositions(38,1,'Array');
 positionsscann=[-0.07:0.001:0.07];
% positionsscann=[-0.07:0.005:0.07];
%positionsscann=[-0.04:0.001:0.04];
%positionsscann=[-0.03:0.001:0.03];

[Xscan,Yscan]=meshgrid(positionsscann,positionsscann);

Xscan2=Xscan(:);
Yscan2=Yscan(:);

numposscan=size(Xscan(:),1);

fourierImagesXMat=zeros([200,198,numposscan]);
fourierImagesYMat=zeros([200,198,numposscan]);
fourierImagesExMat=zeros([200,198,numposscan]);
fourierImagesEyMat=zeros([200,198,numposscan]);
readerhowmany=zeros(numposscan);
%parpool(24)
tic;
parfor_progress(numposscan);
parfor ipos=1:numposscan
    
     
   xpos=Xscan2(ipos);
   ypos=Yscan2(ipos); 
    
    
%%%%%%%%%%%%%
linenumant=9;%please put odd numbers
numscattererrs=3;
  [xs,ys]=meshgrid(1:linenumant,1:linenumant);
  spacing=0.15;
  centershift=round(linenumant/2)*spacing;
  X=xs(:)*spacing-centershift;
     Y=ys(:)*spacing-centershift;
     rdip=[X,Y,Y*0];
        
        zpos=-0.02;
        deltay=0.02;
        %deltay=0;
        deltax=0;
        
        if numscattererrs==2
            scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos];
        elseif numscattererrs==3
            doubledelatx=0.015;
            scatterers=[-deltax+xpos-doubledelatx,-deltay+ypos,zpos;deltax+xpos-doubledelatx,deltay+ypos,zpos;deltax+xpos+doubledelatx,deltay+ypos,zpos];
        elseif numscattererrs==1
            scatterers=[-deltax+xpos,-deltay+ypos,zpos];
        end
        rdip=[rdip;scatterers];
    
%%%%%%%%%%%%%

[w0list,gammalist,alist,blist]=InitializeListValuesAntennaLensArray(linenumant,numscattererrs);

    %let's imagine that we illuminate the field of view which is 1 mm
P0=0.002;%power in W
%radfoc=5e-6;%this is the radius of the focus for the incoming light (This is an aproximation since we work with plane waves)
radfoc=100e-6;%this is the radius of the focus for the incoming light (This is an aproximation since we work with plane waves)
S0=P0/(pi*(radfoc)^2);%this is in W/m^2
S0mu=S0/10^12;%this is in W/mum^2
E0m=sqrt((2*S0/(epszero*co)));%This is in V/m
E0=E0m*10^-6;%This is the field in V/micron

%E0=1;
%Definition of the field excitation
angleexcit=70*pi/180;
zinc=cos(angleexcit);
xinc=sin(angleexcit);

direction=[xinc 0 -zinc];
pol=[0 E0 0];% This is the polarization before the lens and the block
rsource=[0,0,0];

omega=2*pi/(lam/1000);
    
    TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
    TheV=TheVectorFiller(omega, direction,pol,rsource,@DarkConeWaveE,rdip,muv,epsilonv);
    %Pvector=TheMat\TheV;
    %valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@PlaneWaveE,TheV,TheMat,rdip);
        
   Radius=1800;
   NA=0.95;
   %NA=0.85;
   [x,y,Ebackx,Ebacky]=BackApertureNoImages(NA,Radius,TheV,TheMat,omega,muv,epsilonv,direction,pol,rsource,rdip);
    %[x,y,Ebackx,Ebacky]=BackAperture(NA,Radius,TheV,TheMat,omega,muv,epsilonv,direction,pol,rsource,rdip);
   fourierImagesXMat(:,:,ipos)=x(:,:);
   fourierImagesYMat(:,:,ipos)=y(:,:);
   fourierImagesExMat(:,:,ipos)=Ebackx(:,:);
   fourierImagesEyMat(:,:,ipos)=Ebacky(:,:);
   readerhowmany(ipos)=1;
  %disp([num2str(ipos),' out of ',num2str(numposscan)])
  %disp([num2str( sum(readerhowmany)),' out of ',num2str(numposscan)])
  %a=sum(readerhowmany);
parfor_progress;
end
   parfor_progress(0); 
   toc
nt=1;
Xscan2(nt)
Yscan2(nt)
figure(1)
pcolor(fourierImagesXMat(:,:,nt),fourierImagesYMat(:,:,nt),abs(fourierImagesExMat(:,:,nt)).^2);shading flat;axis image ;colorbar
 title({'|Ex|^2 back aperture/top/ missing jacobian, position',['x,y=',num2str([Xscan2(nt),Yscan2(nt)])]})

 %First type of unbalance check
 %this is half down-half up and half left minus half right.
 
unbalancex= (sum(sum(abs(fourierImagesExMat(1:100,:,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,:,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,:,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,:,:)).^2,1),2));
unbalancey= sum(sum(abs(fourierImagesExMat(:,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(:,100:198,:,:)).^2,1),2)./(sum(sum(abs(fourierImagesExMat(:,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(:,100:198,:,:)).^2,1),2));

sizescan=size(positionsscann,2);
figure(2)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancex),sizescan,sizescan))
title('unbalance in x fourier image')
figure(3)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancey),sizescan,sizescan))
 title('unbalance in y fourier image')
 
 %Second type of unbalance check
 %this is quarter down left minus quarter up rigth
 
 
 unbalancexy1= (sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2));
unbalancexy2= (sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2));

figure(4)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancexy2),sizescan,sizescan))
title('unbalance same side top-bottom fourier image')
 
unbalancexy3= (sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2));
figure(5)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancexy3),sizescan,sizescan))
title('unbalance corners 1 fourier image')
 
unbalancexy4= (sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2));
figure(6)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancexy4),sizescan,sizescan))
title('unbalance corners 2 fourier image')
 
 unbalancex2= (sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(101:200,1:99,:)).^2,1),2));

figure(7)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancex2),sizescan,sizescan))
title('unbalance same side left-right fourier image')
 
%%%

%unbalanceyyx1= (sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2))./(sum(sum(abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)+sum(sum(abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2));
photenerg=hpl*co/(lam*1e-9);%this is in jules
Radius=1800;
NA=0.95;
figure(18)
prefactor=(epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))/photenerg);
%%%this is the difference unbalance between half bottom and half top
unbalancenumphotons=prefactor*2*asin(NA)/(199)*(2*pi)/(199)*(Radius^2).*(sum(sum(repmat(sqrt(fourierImagesXMat(1:100,1:99,1).^2+fourierImagesYMat(1:100,1:99,1).^2),[1,1,19881]).*abs(fourierImagesExMat(1:100,1:99,:)).^2,1),2)-sum(sum(repmat(sqrt(fourierImagesXMat(1:100,100:198,1).^2+fourierImagesYMat(1:100,100:198,1).^2),[1,1,19881]).*abs(fourierImagesExMat(1:100,100:198,:)).^2,1),2));

%this is the difference unbalance between two corners only 
% unbalancenumphotons=prefactor*2*asin(NA)/(199)*(2*pi)/(199)*(Radius^2).*(sum(sum(repmat(sqrt(fourierImagesXMat(1:50,1:99,1).^2+fourierImagesYMat(1:50,1:99,1).^2),[1,1,19881]).*abs(fourierImagesExMat(1:50,1:99,:)).^2,1),2)-sum(sum(repmat(sqrt(fourierImagesXMat(1:50,100:198,1).^2+fourierImagesYMat(1:50,100:198,1).^2),[1,1,19881]).*abs(fourierImagesExMat(1:50,100:198,:)).^2,1),2));

%This is the total number of photons for an NA of 0.95
%totalnumphotnumphotons=prefactor*2*asin(NA)/(199)*(2*pi)/(199)*(Radius^2).*(sum(sum(repmat(sqrt(fourierImagesXMat(:,:,1).^2+fourierImagesYMat(:,:,1).^2),[1,1,19881]).*abs(fourierImagesExMat(:,:,:)).^2,1),2));

%this is the difference between half bottom half top but until na=0.6
unbalancenumphotons=prefactor*2*asin(NA)/(199)*(2*pi)/(199)*(Radius^2).*(sum(sum(repmat(sqrt(fourierImagesXMat(1:100,45:99,1).^2+fourierImagesYMat(1:100,45:99,1).^2),[1,1,19881]).*abs(fourierImagesExMat(1:100,45:99,:)).^2,1),2)-sum(sum(repmat(sqrt(fourierImagesXMat(101:200,45:99,1).^2+fourierImagesYMat(101:200,45:99,1).^2),[1,1,19881]).*abs(fourierImagesExMat(101:200,45:99,:)).^2,1),2));
unbalancenormalized=sum(sum(abs(fourierImagesExMat(1:100,45:99,:)).^2-abs(fourierImagesExMat(101:200,45:99,:)).^2,1),2)./sum(sum(abs(fourierImagesExMat(1:100,45:99,:)).^2+abs(fourierImagesExMat(101:200,45:99,:)).^2,1),2);


%This is the total number of photons for an NA of 0.65
totalnumphotnumphotons=prefactor*2*asin(NA)/(199)*(2*pi)/(199)*(Radius^2).*(sum(sum(repmat(sqrt(fourierImagesXMat(:,45:99,1).^2+fourierImagesYMat(:,45:99,1).^2),[1,1,19881]).*abs(fourierImagesExMat(:,45:99,:)).^2,1),2));


figure(17)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancenumphotons),sizescan,sizescan))
title('unbalance number photons')
shading interp
title('unbalance number photons')
xlabel('X (\mum)','FontSize',20);
ylabel('Y (\mum)','FontSize',20);
%colorbar
t = colorbar('peer',gca);
set(get(t,'ylabel'),'String', 'Number of Photons','FontSize',20);
set(gca,'fontsize',16,'LineWidth',2,'TickLength',[0.025 0.025]);
set(gca,'layer','top')
%set(gca,'YTick',-0.04:0.01:0.04)
set(gca,'XMinorTick','on','YMinorTick','on')



figure(30)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancenormalized),sizescan,sizescan))
title('unbalance normalized mesure')
shading interp
%title('unbalance number photons')
xlabel('X (\mum)','FontSize',20);
ylabel('Y (\mum)','FontSize',20);
%colorbar
t = colorbar('peer',gca);
set(get(t,'ylabel'),'String', 'Normalized Intensity','FontSize',20);
set(gca,'fontsize',16,'LineWidth',2,'TickLength',[0.025 0.025]);
set(gca,'layer','top')
%set(gca,'YTick',-0.04:0.01:0.04)
set(gca,'XMinorTick','on','YMinorTick','on')

figure(40)
pcolor(Xscan,Yscan,abs(rot90(cumsum(rot90(reshape(squeeze(unbalancenormalized),sizescan,sizescan),2),1),-2)))
shading interp
title('Integrated unbalance measure')
xlabel('X (\mum)','FontSize',20);
ylabel('Y (\mum)','FontSize',20);
%colorbar
t = colorbar('peer',gca);
set(get(t,'ylabel'),'String', 'Normalized Intensity','FontSize',20);
set(gca,'fontsize',16,'LineWidth',2,'TickLength',[0.025 0.025]);
set(gca,'layer','top')
%set(gca,'YTick',-0.04:0.01:0.04)
set(gca,'XMinorTick','on','YMinorTick','on')




figure(20)
pcolor(Xscan,Yscan,abs(rot90(cumsum(rot90(reshape(squeeze(unbalancenumphotons),sizescan,sizescan),2),1),-2)))
shading interp
title('Integrated unbalance measure')
xlabel('X (\mum)','FontSize',20);
ylabel('Y (\mum)','FontSize',20);
%colorbar
t = colorbar('peer',gca);
set(get(t,'ylabel'),'String', 'Normalized Intensity','FontSize',20);
set(gca,'fontsize',16,'LineWidth',2,'TickLength',[0.025 0.025]);
set(gca,'layer','top')
%set(gca,'YTick',-0.04:0.01:0.04)
set(gca,'XMinorTick','on','YMinorTick','on')




figure(19)
pcolor(Xscan,Yscan,reshape(squeeze(totalnumphotnumphotons),sizescan,sizescan))
title('total number photons')
shading interp
title('number photons')
xlabel('X (\mum)','FontSize',20);
ylabel('Y (\mum)','FontSize',20);
%colorbar
t = colorbar('peer',gca);
set(get(t,'ylabel'),'String', 'Number of Photons','FontSize',20);
set(gca,'fontsize',16,'LineWidth',2,'TickLength',[0.025 0.025]);
set(gca,'layer','top')
%set(gca,'YTick',-0.04:0.01:0.04)
set(gca,'XMinorTick','on','YMinorTick','on')

%%













%%%%%%%%%%
 
  % drawpolarizabilityAntenna(Pvector,rdip);
   
%   figure(8)
% pcolor(Xscan,Yscan,cumsum(rot90(reshape(squeeze(unbalancexy4),sizescan,sizescan),2),1))
% title('integrated unbalance measure')

figure(8)
pcolor(Xscan,Yscan,abs(rot90(cumsum(rot90(reshape(squeeze(unbalancexy4),sizescan,sizescan),2),1),-2)))
shading interp
title('Integrated unbalance measure')
xlabel('X (\mum)','FontSize',20);
ylabel('Y (\mum)','FontSize',20);
%colorbar
t = colorbar('peer',gca);
set(get(t,'ylabel'),'String', 'Normalized Intensity','FontSize',20);
set(gca,'fontsize',16,'LineWidth',2,'TickLength',[0.025 0.025]);
set(gca,'layer','top')
%set(gca,'YTick',-0.04:0.01:0.04)
set(gca,'XMinorTick','on','YMinorTick','on')


figure(9)
pcolor(Xscan,Yscan,rot90(cumsum((reshape(squeeze(unbalancexy4),sizescan,sizescan)),1),2))
title('Integrated unbalance measure')

mat2int=reshape(squeeze(unbalancexy4),sizescan,sizescan);

figure(10)
pcolor(Xscan,Yscan,mat2int)


m=1;
k=size(mat2int,1);
n=floor(k/m);
reshpmat=reshape(mat2int(1:m*n,1:m*n),[m,n,m,n]);
finmat=reshape(sum(sum(reshpmat,1),3),[n,n]);
figure(11)
pcolor(finmat)

figure(12)
pcolor(Xscan,Yscan,cumsum(cumsum(mat2int,1),1))



figure(13)
pcolor(abs(rot90(cumsum(rot90(reshape(squeeze(unbalancexy4),sizescan,sizescan),2),1),-2)))


arrayplot=abs(rot90(cumsum(rot90(reshape(squeeze(unbalancexy4),sizescan,sizescan),2),1),-2));
%%
figure(14)
pos=17;
plot(Xscan(pos,:)*1000, arrayplot(pos,:),'Linewidth',2)
xlabel('Position (nm)','FontSize',20);
ylabel('Intensity (a.u.)','FontSize',20);
set(gca,'fontsize',16,'LineWidth',2,'TickLength',[0.025 0.025]);
%%
figure(15)
pcolor(Xscan,Yscan,reshape(squeeze(unbalancexy4),sizescan,sizescan))
title('Unbalance measure corners Fourier image')
shading interp
%title('Integrated unbalance measure')
xlabel('X (\mum)','FontSize',20);
ylabel('Y (\mum)','FontSize',20);
%colorbar
t = colorbar('peer',gca);
set(get(t,'ylabel'),'String', 'Normalized Intensity','FontSize',20);
set(gca,'fontsize',16,'LineWidth',2,'TickLength',[0.025 0.025]);
set(gca,'layer','top')
%set(gca,'YTick',-0.04:0.01:0.04)
set(gca,'XMinorTick','on','YMinorTick','on')

