function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
  ...  [sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
          [PolarizabVsDistance,Distances]=runnerPolarizabilities2ParticlesDifferentDistances(lambda)
      name='yagiuda';
p = path;
%path(p,'..\WaveguideGreensFunctionQuadVGK');
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   
p4 = path;
path(p4,'..\MicroscopeVision');   
c=1;
eps0=1;
mu0=1;
%struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% %struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
struct=[[1;1.000001;1.000001],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
t=0;
%t=0.1;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

omega=2*pi/(lambda/1000);
%omega=pi;
Ndip=2;
%Ndip=1;
%rdip=InitializeDipolePositions(Ndip,1,name);%For the yagiUda Ndip and dist do not matter.
numposz=20;
mindist=0.01;
maxdist=0.5;
PolarizabVsDistance=zeros(6,6,numposz);
Distances=logspace(log10(mindist),log10(maxdist),numposz).';
cont=1;
Radius=100;
for distance=logspace(log10(mindist),log10(maxdist),numposz)
heig=5;
rdip=[0,0,heig;distance,0,heig];
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);
TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
PolarizabVsDistance(:,:,cont)=inv(TheMat);
cont=cont+1
end

%plot(couplingefficiencies(:,1),couplingefficiencies(:,2));
