%function vecplot=CLexcitationBistaticRadiationYagiUda

%p = path;
%path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');

%guided=0; %0 means free space and 1 means guided

%struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive
% %index database for siN is 2.00347)
% t=0.1;

muv=1;
epsilonv=1;
c=1;
%struct=[[1;1;1],[1;1;1]];%for glass the n is 1.45846(refractive
%index database for siN is 2.00347)
%t=0.1;

Radius=1000;
numberofpoints=200;

Ndip=5;
%rdip=InitializeDipolePositions(Ndip,1,'yagiuda');%For the yagiUda Ndip and dist do not matter.
%rdip=InitializeDipolePositions(Ndip,1,'singlerod');%For the singlerod Ndip and dist do not matter.

nameantenna='YU1CL';
rdip=InitializeDipolePositions(Ndip,1,nameantenna);%For the singlerod Ndip and dist do not matter.
%[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);
YU=1;
[w0list,gammalist,alist,blist]=InitializeListVAluesCLYagiUda(YU);

%[w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('reflector',1);
%[w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('feed',1)
%  [w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('dir1',1)
% [w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('dir2',1)
%[w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('dir3',1)


%this is the CL or better dipole orientation and 
%pol is the orientation
%direction is not used at all
%rsource is the position of the dipole
    direction=[0 0 -1];
    pol=[0 0 1];
    %posit='edgeReflector';
    %posit='edgefeed';
    %posit='edgedir1';
    %posit='edgedir2';
    posit='edgedir3';
    if strcmp(posit,'edgeReflector')
         rsource=rdip(1,:)+[alist(1,:),0,0.03];
    elseif strcmp(posit,'edgefeed')
         rsource=rdip(2,:)+[alist(2,:),0,0.03];
    elseif strcmp(posit,'edgedir1')
         rsource=rdip(3,:)+[alist(3,:),0,0.03];
    elseif strcmp(posit,'edgedir2')
         rsource=rdip(4,:)+[alist(4,:),0,0.03];
    elseif strcmp(posit,'edgedir3')
         rsource=rdip(5,:)+[alist(5,:),0,0.03];
    end
%circles in the plane of the antenna
thetapoints=pi/2;
phipoints=[0:2*pi/(numberofpoints-1):2*pi].';
numphi=size(phipoints,1);
alltheta=repmat(thetapoints,numphi,1);
allphi=phipoints;
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
minlambda=400;
maxlambda=1000;
deltalambda=1;
vecplot=zeros(size([minlambda:deltalambda:maxlambda].',1),numphi);
cont=1;
fig=figure;
aviobj = avifile([nameantenna,'_',posit,'.avi']); %#ok<*REMFF1>
%aviobj = VideoWriter('example.avi');
%open(aviobj);
for lam=minlambda:deltalambda:maxlambda
    omega=2*pi/(lam/1000);
    
    TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
    %save([directory, dia,'\',name,'.mat'],'TheMat');
   
        TheV=TheVectorFiller(omega, direction,pol,rsource,@DipoleEField,rdip,muv,epsilonv);
        valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@DipoleEField,TheV,TheMat,rdip);
        %TheV=TheVectorFiller(omega, direction,pol,rsource,@TransitionFieldE,rdip,muv,epsilonv);
        %valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@TransitionFieldE,TheV,TheMat,rdip);
        %P0=(omega^4)/(12*pi*epsilonv*c^3); 
        vecplot(cont,:)=(Radius^2)*sum((valE.*conj(valE)),2);   
    %([int2str(cont),' out of', int2str((maxlambda-minlambda)/deltalambda)])
    
    %polar(0,3500,'-k')
    %hold on
    colorthingy=(Wavelength_to_RGB(lam)/255);
    h=polar(allphi,(vecplot(cont,:)).','-');
    title(['wavelength=',num2str(lam),' excited at ',posit])
    %hold off
    patch( get(h,'XData'), get(h,'YData'), 'g','FaceColor', colorthingy,'FaceAlpha',0.6,'EdgeColor',colorthingy)
    %axis tight
    %frame = getframe;
   %writeVideo(aviobj,frame);
    F = getframe(fig);
    aviobj = addframe(aviobj,F);
    cont=cont+1;
%end

%a=[[minlambda:deltalambda:maxlambda].',vecplot];
%save(['\\nanorfsrv\Users\Bernal\Simulations\',day,'\TotalScattCrossSecYagiUda.txt'], 'a','-ascii');
end
%lambdas=minlambda:deltalambda:maxlambda;
%figure(1)
%polar(allphi,vecplot(21,:).','.');

close(fig);
aviobj = close(aviobj);
%implay('example.avi',5);