clear all
close all
clc
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');
p4 = path;
path(p4,'..\MicroscopeVision');
close all
muv=1;
epsilonv=1;
c=1;
epszero=8.854e-12;%F/m....A^2�s^4�kg^?1�m^?3
co=2.99e8;%m/s
hpl=6.626e-34;
eps0=1;
eps1=1;
eps3=1;
mu3=1;
mu1=1;
mu0=1;



Radius=1000;
numberofpoints=200;

%rdip=InitializeDipolePositions(38,1,'Array');

%%%%%%%%%%%%% Definition of the structure
linenumant=9;%(please put odd numbers )This is the number n of antennas in a linear direction i.e.e.g nxn
numscattererrs=1; % This is the number of scatterers different from the antennas
%Definition of the position of the antennas
[xs,ys]=meshgrid(1:linenumant,1:linenumant);
spacing=0.15;
centershift=round(linenumant/2)*spacing;
X=xs(:)*spacing-centershift;
Y=ys(:)*spacing-centershift;
rdip=[X,Y,Y*0];
%Definition of the position of the scatterers
xpos=0;
ypos=0;
zpos=-0.02;
deltay=-0.025;
deltax=-0.025;
if numscattererrs==2
    scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos];
elseif numscattererrs==3
    
    scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos;deltax+xpos+0.05,deltay+ypos,zpos];
    
elseif numscattererrs==1
    scatterers=[-deltax+xpos,-deltay+ypos,zpos];
elseif  numscattererrs==0
    scatterers=[];
end



%JOined positions of the scatterers and the antennas
rdip=[rdip;scatterers];



%%%%%%%%%%%%%

%definition of the values for the polarizabilities of the antennas and the
%scatterers
[w0list,gammalist,alist,blist]=InitializeListValuesAntennaLensArray(linenumant,numscattererrs);

%blist=alist*1000000;
%alist=alist*1000000;
%gammalist=gammalist*0;

%let's imagine that we illuminate the field of view which is 1 mm
P0=0.002;%power in W
%radfoc=5e-6;%this is the radius of the focus for the incoming light (This is an aproximation since we work with plane waves)
radfoc=100e-6;%this is the radius of the focus for the incoming light (This is an aproximation since we work with plane waves)
S0=P0/(pi*(radfoc)^2);%this is in W/m^2
S0mu=S0/10^12;%this is in W/mum^2
E0m=sqrt((2*S0/(epszero*co)));%This is in V/m
E0=E0m*10^-6;%This is the field in V/micron

%E0=1;
%Definition of the field excitation
angleexcit=70*pi/180;
zinc=cos(angleexcit);
xinc=sin(angleexcit);

direction=[xinc 0 -zinc];
pol=[0 E0 0];% This is the polarization before the lens and the block
rsource=[0,0,0];

lam=845;%wavelength in nm
omega=2*pi/(lam/1000);
photenerg=hpl*co/(lam*1e-9);%this is in jules

%Calculation of the matrix with the polarizabilities
TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
%Calculation of the fields at the position of the scatterers
TheV=TheVectorFiller(omega, direction,pol,rsource,@DarkConeWaveE,rdip,muv,epsilonv);
%Calculation of the dipolar moments induced by the field
Pvector=TheMat\TheV
%valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@PlaneWaveE,TheV,TheMat,rdip);


if 1>-1
    Radius=1800;
    NA=0.90;%1;
    %NA=0.85;
    [x,y,Ebackx,Ebacky]=BackAperture(NA,Radius,TheV,TheMat,omega,muv,epsilonv,direction,pol,rsource,rdip);
    
    
    PowerBackfocPlaneX=epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))*(2*pi/(199))*(asin(NA)/(198))*(Radius^2)*sum(sum(sqrt(x.^2+y.^2).*Ebackx.*conj(Ebackx),2),1);
    display('PowerBackfocPlaneX [W/mum^2]'); display(PowerBackfocPlaneX);
    display('PowerBackfocPlaneX [S0]'); display(PowerBackfocPlaneX/S0mu);
    
    PowerBackfocPlaneY=epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))*(2*pi/(199))*(asin(NA)/(198))*(Radius^2)*sum(sum(sqrt(x.^2+y.^2).*Ebacky.*conj(Ebacky),2),1);
    display('PowerBackfocPlaneY [W/mum^2]'); display(PowerBackfocPlaneY);
    display('PowerBackfocPlaneY [S0]'); display(PowerBackfocPlaneY/S0mu);
    
    nfigs = get(0,'Children');
    plotflag=size(nfigs,1);
end

if 1>-1    
    
    photenerg=hpl*co/(lam*1e-9);%this is in jules
    con1omicrto1ovm=10^6;%change of 1/micron to 1/m
    %Plot of the number of photons per second per square meter
    photpersperm=(1/photenerg)*(1/2)*epszero*co*abs(Ebackx*con1omicrto1ovm).^2;%[photons/(s.m^2)
    figure(plotflag+1)
    pcolor(Radius*x/1000,Radius*y/1000,photpersperm);shading flat;axis image ;colorbar
    title('[photons/(s.m^2)] back aperture/top')
    xlabel('position (mm)')
    ylabel('position (mm)')
    
    
    toalnumphot=sum(sum(photpersperm,1),2)*pi*(Radius*NA)^2;
    %Plot of the integrated phot per pixel per second
    
    %    xcheck=[-1500:6:1500];
    %    ycheck=[-1500:6:1500];
    %    fpix=interp2(0,0,photpersperm,Radius*x,Radius*y);
    
    XX=Radius*x;
    YY=Radius*y;
    VV=photpersperm;
    F=scatteredInterpolant(XX(:),YY(:),VV(:),'linear','none');
    
    pixellen=6;%6 microns
    convmtousq=10^-12;%this is the conversion from 1/square meters to 1/square microns
    xcheck=[-2000:pixellen:2000];
    [xq,yq] = meshgrid(xcheck,xcheck);
    fpix=convmtousq*pixellen^2*F(xq,yq);
    figure(plotflag+4)
    pcolor(xq,yq,fpix);shading flat;axis image ;colorbar
    title(['[photons/(s.px)] input power=',num2str(P0*1000),'mW'])
    xlabel('position (\mum)')
    ylabel('position (\mum)')
    
    
    
    fmicroscope=1800;%microns
    ftubelens=100000;%microns
    nlenses=1.5; %refractive index of the lenses used
    [Efocal,numpixelsx,xgrid,ygrid]=microscopevision(omega,TheMat,TheV,rdip,fmicroscope,NA,ftubelens,nlenses,muv,epsilonv);
    matrixintensity=reshape(sqrt(sum(Efocal.*conj(Efocal),2)),numpixelsx,numpixelsx);
    
    
    figure(plotflag+2)
    imagesc(xgrid,ygrid,matrixintensity);
    colormap(hot)
    title('Microscope image (|E|)')
    xlabel('X')
    ylabel('Y')
    colorbar
    %cross polarized
    %    numpointsfield=size(Efocal,3);
    Polarizer=[1,0,0];
    [Efocalpol,numpixelsxpol,xgridpol,ygridpol]=microscopevisionpolarized(omega,TheMat,TheV,rdip,fmicroscope,NA,ftubelens,nlenses,muv,epsilonv,Polarizer);
    matrixintensitypolarized=reshape(sqrt(sum(Efocalpol.*conj(Efocalpol),2)),numpixelsxpol,numpixelsxpol);
    figure(plotflag+3)
    imagesc(xgridpol,ygridpol,matrixintensitypolarized);
    colormap(hot)
    title('Microscope image (|E|_{x})')
    xlabel('X')
    ylabel('Y')
    colorbar
    
    % drawpolarizabilityAntenna(Pvector,rdip);
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Now we find the power scattered out of plane
%first on top
%PlaneWaveE

thetarange=pi/2;
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end)),(numberofpoints))];
allphi=[0;repmat(phipoints,(numberofpoints-1),1)];

positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
valE=FieldEfinder('scatt','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@DarkConeWaveE,TheV,TheMat,rdip);
vecplotTOP=epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1)
valEx=valE(:,1);
valEy=valE(:,2);
vecplotTOPX=epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valEx.*conj(valEx),2)),1)
vecplotTOPY=epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valEy.*conj(valEy),2)),1)

%Now for the bottom
thetarange=pi/2-(pi/2)/(numberofpoints);
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end)),(numberofpoints))];
allphi=[0;repmat(phipoints,(numberofpoints-1),1)];

positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),-Radius*cos(alltheta)];%notice the minus in front of the angle for z
valE=FieldEfinder('scatt','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@DarkConeWaveE,TheV,TheMat,rdip);
vecplotBOTTOM=epszero*co*(1/2)*sqrt((epsilonv*eps3)/(mu0*mu3))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1)

Pscattered=vecplotTOP+vecplotBOTTOM

%When we have only one scatterre we can calculate the theoretical power
%scattered which is
%p0=Pvector(end-1);
%Ptheorysingle=(omega^4)*(abs(p0)^2)/(4*pi*eps0*3*c^3)

calcScattcrosssec=Pscattered/(epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))*E0^2)
Photonsin=P0/photenerg
% convfact=10^-12;%W/mu^2 to W/m^2
Photonsreflected=vecplotTOP/photenerg
PhotonsreflectedX=vecplotTOPX/photenerg
PhotonsreflectedY=vecplotTOPY/photenerg

RateRefl=Photonsreflected/Photonsin