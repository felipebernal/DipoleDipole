    function val=gaussian(rpos,center,radius)
        Acons=1;
        numpos=size(rpos,1);
        centernew=repmat(center,numpos,1);
        val=Acons*exp(-sum((rpos-centernew).^2,2)./(2*radius^2));
        
        
    end