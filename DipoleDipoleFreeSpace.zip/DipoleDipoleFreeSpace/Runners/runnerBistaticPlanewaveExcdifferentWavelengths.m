function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
  ...  [sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
          [couplingefficiencies]=runnerBistaticPlanewaveExcdifferentWavelengths(height)
      name='yagiuda';
p = path;
%path(p,'..\WaveguideGreensFunctionQuadVGK');
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   
p4 = path;
path(p4,'..\MicroscopeVision');   
      


c=1;
eps0=1;
mu0=1;
%struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
struct=[[1;3.61;3.61],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)

% %struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;1.000001;1.000001],[1;1;1]];
% t=0.1;
% %t=0;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);



%struct=[[1;1.000001;1],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
t=0;
%t=0.1;


%omega=pi;


Ndip=2;
%Ndip=1;
%rdip=InitializeDipolePositions(Ndip,1,name);%For the yagiUda Ndip and dist do not matter.

numlambda=10;
minlambda=0.4;
maxlambda=0.8;
couplingefficiencies=zeros(numlambda,2);
couplingefficiencies(:,1)=linspace(minlambda,maxlambda,numlambda).';

scatteredPower=zeros(numlambda,2);
scatteredPower(:,1)=linspace(minlambda,maxlambda,numlambda).';
extintion=zeros(numlambda,2);
extintion(:,1)=linspace(minlambda,maxlambda,numlambda).';
cont=1;
Radius=1;

heig=height;
for lambda=linspace(minlambda,maxlambda,numlambda)
omega=2*pi/(lambda);
%rdip=[0,0,heig];
     rdip=[0,-0.1,heig;0,0.1,heig]; 
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);
direction=[0 0 -1];
pol=[1 0 0];
rsource=rdip;
numberofpoints=400;
TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
polari=1/(TheMat(1,1));

TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayered,rdip,struct,t)
%[vecplotparallel,vecplotperpedicular]= FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);


Pvectortemp=TheMat\TheV;
   
Pvector=reshape(Pvectortemp,3,Ndip).';
TheVarr=reshape(TheV,3,Ndip).';
Pextintion=(omega/2)*imag(sum(sum(Pvector.*conj(TheVarr),2),1)); %this one is novotny eq.12.50
%Pextintion=-(omega/2)*imag(sum(sum(conj(Pvector).*TheVarr,2),1)) %this one is novotny eq.8.74
%Now we find the power scattered out of plane
%first on top

thetarange=pi/2;
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end)),(numberofpoints))];
allphi=[0;repmat(phipoints,(numberofpoints-1),1)];

positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
vecplotTOP=(1/2)*sqrt((eps0*eps1)/(mu0*mu1))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);

%Now for the bottom
thetarange=pi/2-(pi/2)/(numberofpoints);
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end)),(numberofpoints))];
allphi=[0;repmat(phipoints,(numberofpoints-1),1)];

positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),-Radius*cos(alltheta)];%notice the minus in front of the angle for z
valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
vecplotBOTTOM=(1/2)*sqrt((eps0*eps3)/(mu0*mu3))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);

Pscattered=vecplotTOP+vecplotBOTTOM;


EIncomingfield=PlaneWaveELayered(omega,direction,pol,rdip,[0,0,0],struct,t)
POWincoming=eps0*c*sum(EIncomingfield.*conj(EIncomingfield),2)/2;
POWincoming=POWincoming(1,1);
%
%So the power got into the waveguide is

Pwaveguide=Pextintion-Pscattered;
%efficiencycoupling=Pwaveguide/Pextintion; %This would be the portion of the
%work absorved or incoupled
efficiencycoupling=(Pwaveguide/POWincoming);%This would be the portion of the
%incoming power from the plane wave absorved or incoupled



couplingefficiencies(cont,2)= efficiencycoupling;
scatteredPower(cont,2)=Pscattered;
extintion(cont,2)=Pextintion;
cont=cont+1
end
figure(1)
plot(couplingefficiencies(:,1),couplingefficiencies(:,2));
figure(2)
plot(2*pi*(3*10^8)./(scatteredPower(:,1)/(10^6)),scatteredPower(:,2)/(POWincoming));
figure(3)
plot(2*pi*(3*10^8)./(extintion(:,1)/(10^6)),extintion(:,2)/(POWincoming));

% TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayeredGauss,rdip,struct,t);
% 
% Pvector=TheMat\TheV
% 
%   % drawpolarizabilityAntenna(Pvector,rdip);
%    
%  %%%HEre we find what is the total intensity at [0,0,0] integral of
%   %%%int(|E|^2dx^2)
% rcentergauss=[0,0,0]; 
% [Xint,Yint]=meshgrid(-2+rcentergauss(1):0.01:2+rcentergauss(1),-2+rcentergauss(2):0.01:2+rcentergauss(2)); 
% xnew=Xint(:);
% ynew=Yint(:);
% rpos=[xnew,ynew,ynew*0+rdip(1,3)];
% valfunEgauss= PlaneWaveELayeredGauss(2*pi/0.7,[0,0,-1],[1,0,0],rpos,rcentergauss,struct,t);
% totalEsquareGaussian=sum(sum(valfunEgauss.*conj(valfunEgauss),2),1);
%    %Now we have here the part for the incoupled ligth into the waveguide.
%    %and we try to get what is the efficiency at which it incouples the
%    %light
%    numberofpointsincouping=20;
%    numberpointsheight=10;
%    
%    RadiusIncoupling=5;
%    
%    [vecplotcylinder,integratedint]=FieldGuidedCylinder(RadiusIncoupling,numberofpointsincouping, numberpointsheight,TheV,TheMat,omega,struct,t,direction,pol,rcentergauss,rdip);
%    efficiencycoupling=integratedint/totalEsquareGaussian;
%    EscatsqrIncouplingant=reshape(abs(vecplotcylinder(:,1)),numberofpointsincouping,[]);%sum(abs(vecplotparallel).^2,2);
%    EscatsqrIncoupling=EscatsqrIncouplingant(:,floor(numberpointsheight/2));
%    sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',EscatsqrIncoupling];
% 
%    % figure(6)
%    %polar(sigmaincoupling(:,1),sigmaincoupling(:,2),'.');
%    
%    couplingefficiencies(cont,2)= efficiencycoupling;
%    cont=cont+1
% end
%    plot(couplingefficiencies(:,1),couplingefficiencies(:,2));
%    
   