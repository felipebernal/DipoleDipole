function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
  ...  [sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
          [sigmascatparallel, sigmascatperpend,TheMat,TheV,omega,rdip,struct,t,Pvector, efficiencycoupling, sigmaincoupling,   sigmaincouplinglinear]=runnerBistaticGaussianExc(Radius,lambda)
      name='yagiuda';
p = path;
%path(p,'..\WaveguideGreensFunctionQuadVGK');
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   
p4 = path;
path(p4,'..\MicroscopeVision');   
      



struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% %struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% t=0.1;
% %t=0;

%struct=[[1;1.000001;1],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%t=0.01;
t=0.1;

omega=2*pi/(lambda/1000);
%omega=pi;


Ndip=1;
%Ndip=1;
rdip=InitializeDipolePositions(Ndip,1,name);%For the yagiUda Ndip and dist do not matter.
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);

direction=[0 0 -1];
pol=[1 0 0];
rsource=[0 0 rdip(1,3)];

numberofpoints=100;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date; 

TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayeredGauss,rdip,struct,t);
[vecplotparallel,vecplotperpedicular]= FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);


Pvector=TheMat\TheV;
   
    
     Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
     sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrparallel];
     
     Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
     sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* Escatsqrperpendm];
     
          
    %save([directory, dia,'\',name,'DrawingparallelperpendMatrix.mat'],'sigmascatparallel','sigmascatperpend'); 
    figure(1)
    polar(sigmascatparallel(:,1),sigmascatparallel(:,2));
    figure(2)
    polar(sigmascatperpend(:,1),sigmascatperpend(:,2));
    figure(3)
    polar([sigmascatparallel(:,1);NaN;sigmascatperpend(:,1)],[sigmascatparallel(:,2);NaN;sigmascatperpend(:,2)]); 
   % figure(4)
   %subplot(2,1,1), polar([0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* sum(Efieldsparallel.*conj(Efieldsparallel),2)),title('\it{Circle parallel to the polarization-k plane }','FontSize',16);
   %subplot(2,1,2), polar([0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* sum(Efieldsperpendicular.*conj(Efieldsperpendicular),2)),title('\it{Circle perpendicular to the polarization-k plane }','FontSize',16);
   
%    vecplotcircle=FieldGuidedCircleBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
%     Escatsqrcircle=sum(vecplotcircle.*conj(vecplotcircle),2);%sum(abs(vecplotparallel).^2,2);
%      sigmascatcircle=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrcircle];
%    figure(5)
%     polar(sigmascatcircle(:,1),sigmascatcircle(:,2));


   NA=0.95;
   %NA=0.85;
   BackAperture(NA,Radius,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
   fmicroscope=1800;%microns
   ftubelens=100000;%microns
   nlenses=1.5; %refractive index of the lenses used
   [Efocal,numpixelsx,xgrid,ygrid]=microscopevision(omega,TheMat,TheV,rdip,fmicroscope,NA,ftubelens,nlenses,struct,t);
   matrixintensity=reshape(sqrt(sum(Efocal.*conj(Efocal),2)),numpixelsx,numpixelsx);
   figure(5)
   imagesc(xgrid,ygrid,matrixintensity);
   colormap(hot)
   title('Microscope image')
   xlabel('X')
   ylabel('Y')
   
  % drawpolarizabilityAntenna(Pvector,rdip);
   

  
   
%    
%    %Now we have here the part for the incoupled ligth into the waveguide.
%    numberofpointsincouping=50;
%    RadiusIncoupling=10;
%    vecplotcircle=FieldGuidedCircleBistaticCrossSec(RadiusIncoupling,numberofpointsincouping,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
%    
%     %EscatsqrIncoupling=sum( vecplotcircle.*conj( vecplotcircle),2);%sum(abs(vecplotparallel).^2,2);
%     EscatsqrIncoupling=abs(vecplotcircle(:,1));%sum(abs(vecplotparallel).^2,2);
%     %sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',2*pi*RadiusIncoupling*EscatsqrIncoupling];
%     sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',EscatsqrIncoupling];
%     figure(6)
%    polar(sigmaincoupling(:,1),sigmaincoupling(:,2),'.');
%    integratedint=1;
%    
% 


 %%%HEre we find what is the total intensity at [0,0,0] integral of
  %%%int(|E|^2dx^2)
 rcentergauss=[0,0,0]; 
 
[Xint,Yint]=meshgrid(-2+rcentergauss(1):0.01:2+rcentergauss(1),-2+rcentergauss(2):0.01:2+rcentergauss(2)); 
xnew=Xint(:);
ynew=Yint(:);

% 
rpos=[xnew,ynew,ynew*0+rdip(1,3)];
valfunEgauss= PlaneWaveELayeredGauss(omega,direction,pol,rpos,rcentergauss,struct,t);
totalEsquareGaussian=sum(sum(valfunEgauss.*conj(valfunEgauss),2),1);


   %Now we have here the part for the incoupled ligth into the waveguide.
   %and we try to get what is the efficiency at which it incouples the
   %light
   numberofpointsincouping=50;
   numberpointsheight=10;
   RadiusIncoupling=40;
   [vecplotcylinder, integratedint, integraH]=FieldGuidedCylinder(RadiusIncoupling,numberofpointsincouping, numberpointsheight,TheV,TheMat,omega,struct,t,direction,pol,rcentergauss,rdip);
   integratedint
   efficiencycoupling=integratedint/totalEsquareGaussian;
   
      valfunEgausscenter= PlaneWaveELayeredGauss(omega,direction,pol,rcentergauss,rcentergauss,struct,t);
    EscatsqrIncouplingant=reshape(abs(vecplotcylinder(:,1)),numberofpointsincouping,[]);%sum(abs(vecplotparallel).^2,2);
    EscatsqrIncoupling=EscatsqrIncouplingant(:,floor(numberpointsheight/2))./sum(valfunEgausscenter.*conj(valfunEgausscenter),2);

    sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',EscatsqrIncoupling];
    figure(6)
   polar(sigmaincoupling(:,1),sigmaincoupling(:,2),'.');
   title('|Ex|^2/|E_o|^2')

   sigmaincouplinglinear=[[0:2*pi/(numberofpointsincouping-1):2*pi]', integraH/sum(valfunEgausscenter.*conj(valfunEgausscenter),2)];
   figure(7)
   polar(   sigmaincouplinglinear(:,1),   sigmaincouplinglinear(:,2),'.');
   title('2*pi*r*|E|^2/|E_o|^2')
   

   
   
   