%load the statistic file
%all these files have the excitation based on each one of the elements of the antennas
clear all
close all
clc

%a=load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\statistics2000YU2p5nmAllAntennas.mat'); 
%a=load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\statistics2000YU2p5nmWithNormaldistributionv3.mat');
%b= load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\LDOSmatrix2000YU2p5nmWithNormaldistributionv3.mat');

a=load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\statistics5000YU2p5nmWithNormaldistributionv3plusLDOS.mat');
b= load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\LDOSmatrix5000YU2p5nmWithNormaldistributionv3.mat');



%LDOSMatrixLambda=b.LDOSMatrixLambda;
Matrixdirectivity=a.Matrixdirectivity;
 
 
 %close all;
 %Matrixdirectivity=a.Matrixdirectivity;

randommat=0.0025*randn(1,5000);
%plot



numbars=200;
  exc=2;%feed Excitation
if 1<-1
    figure(1)
plot(Matrixdirectivity(:,1,exc),Matrixdirectivity(:,2,exc),'.')    
figure(2)
plot(Matrixdirectivity(:,3,exc),Matrixdirectivity(:,4,exc),'.')    
figure(3)
plot(Matrixdirectivity(:,9,exc),Matrixdirectivity(:,1,exc),'.')    
figure(4)
plot(Matrixdirectivity(:,9,exc),Matrixdirectivity(:,10,exc),'.')    
figure(5)
plot(Matrixdirectivity(:,2,exc),Matrixdirectivity(:,10,exc),'.')    
figure(6)
plot(Matrixdirectivity(:,3,exc),Matrixdirectivity(:,10,exc),'.') 

figure(7)
plot(Matrixdirectivity(:,3,1),Matrixdirectivity(:,9,1),'.')
title('dir vs. LDOS exited at Reflector')
xlabel('Directivity')
ylabel('maxLDOS')



figure(8)
plot(Matrixdirectivity(:,3,2),Matrixdirectivity(:,9,2),'.')
title('dir vs. LDOS exited at Feed')
xlabel('Directivity')
ylabel('maxLDOS')

figure(9)
plot(Matrixdirectivity(:,3,3),Matrixdirectivity(:,9,3),'.')
title('dir vs. LDOS exited at Dir1')
xlabel('Directivity')
ylabel('maxLDOS')

figure(10)
plot(Matrixdirectivity(:,3,4),Matrixdirectivity(:,9,4),'.')
title('dir vs. LDOS exited at Dir2')
xlabel('Directivity')
ylabel('maxLDOS')

figure(11)
plot(Matrixdirectivity(:,3,5),Matrixdirectivity(:,9,5),'.')
title('dir vs. LDOS exited at Dir3')
xlabel('Directivity')
ylabel('maxLDOS')




else
   
figure(1)
plot(Matrixdirectivity(:,1,exc),'.')
figure(2)
plot(Matrixdirectivity(:,2,exc),'.')
figure(3)
plot(Matrixdirectivity(:,3,exc),'.')
figure(4)
plot(Matrixdirectivity(:,4,exc),'.')
figure(5)
hist(Matrixdirectivity(:,1,exc),numbars)
title('Directivity low wavelength peak')
[nelLowWave,centersLowWave]=hist(Matrixdirectivity(:,2,exc),numbars);
figure(6)
hist(Matrixdirectivity(:,2,exc),numbars);
title('Wavelength low wavelength peak')
figure(7)
hist(Matrixdirectivity(:,3,exc),numbars);
title('Directivity high wavelength peak')
[nelHighWave,centersHighWave]=hist(Matrixdirectivity(:,4,exc),numbars);
figure(8)
hist(Matrixdirectivity(:,4,exc),numbars);
title('Wavelength high wavelength peak')
figure(9)
hist(Matrixdirectivity(:,5,exc),numbars);
title('anglephimaxdirect1')
figure(10)
hist(Matrixdirectivity(:,6,exc),numbars);
title('anglephimaxdirect2')
figure(11)
hist(Matrixdirectivity(:,7,exc),numbars);
title('anglethetamaxdirect1')
figure(12)
hist(Matrixdirectivity(:,8,exc),numbars);
title('anglethetamaxdirect2')
figure(13)
hist(Matrixdirectivity(:,9,exc),numbars);
title('maxLDOS')
figure(14)
hist(Matrixdirectivity(:,10,exc),numbars);
title('waveLDOS')
figure(15)
bar([centersLowWave,centersHighWave],[nelLowWave,nelHighWave]);
figure(16)
hist(randommat,numbars);
end