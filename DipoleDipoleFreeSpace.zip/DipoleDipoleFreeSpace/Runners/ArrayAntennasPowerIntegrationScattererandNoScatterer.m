%clear all This is to generate the power differencew between an array with
%a scatterer and one withoiur Scatterer
clear all

p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');
p4 = path;
path(p4,'..\MicroscopeVision');
close all
muv=1;
epsilonv=1;
c=1;
epszero=8.854e-12;%F/m....A^2�s^4�kg^?1�m^?3
co=2.99e8;%m/s
hpl=6.626e-34;
eps0=1;
eps1=1;
eps3=1;
mu3=1;
mu1=1;
mu0=1;



Radius=1000;
numberofpoints=200;

%rdip=InitializeDipolePositions(38,1,'Array');

%%%%%%%%%%%%% Definition of the structure with Scatterer
linenumant=9;%(please put odd numbers )This is the number n of antennas in a linear direction i.e.e.g nxn
numscattererrs=1; % This is the number of scatterers different from the antennas
%Definition of the position of the antennas
[xs,ys]=meshgrid(1:linenumant,1:linenumant);
spacing=0.15;
centershift=round(linenumant/2)*spacing;
X=xs(:)*spacing-centershift;
Y=ys(:)*spacing-centershift;
rdip=[X,Y,Y*0];
%Definition of the position of the scatterers
xpos=0;
ypos=0;
zpos=-0.02;
deltay=0.05;
deltax=-0.025;
if numscattererrs==2
    scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos];
elseif numscattererrs==3
    
    scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos;deltax+xpos+0.05,deltay+ypos,zpos];
    
elseif numscattererrs==1
    scatterers=[-deltax+xpos,-deltay+ypos,zpos];
elseif  numscattererrs==0
    scatterers=[];
end



%JOined positions of the scatterers and the antennas
rdip=[rdip;scatterers];

%%%%%%%%%%%%%

%definition of the values for the polarizabilities of the antennas and the
%scatterers
[w0list,gammalist,alist,blist]=InitializeListValuesAntennaLensArray(linenumant,numscattererrs);
%blist=alist*1000000;
%alist=alist*1000000;
%gammalist=gammalist*0;

%let's imagine that we illuminate the field of view which is 1 mm
P0=0.001;%power in W
radfoc=5e-6;%this is the radius of the focus for the incoming light (This is an aproximation since we work with plane waves)
S0=P0/(pi*(radfoc)^2);%this is in W/m^2
S0mu=S0/10^12;%this is in W/mum^2
E0m=sqrt((2*S0/(epszero*co)));%This is in V/m
E0=E0m*10^-6;%This is the field in V/micron

%E0=1;
%Definition of the field excitation
direction=[0 0 -1];
pol=[0 E0 0];
rsource=[0,0,0];

lam=845;%wavelength in nm
omega=2*pi/(lam/1000);
photenerg=hpl*co/(lam*1e-9);%this is in jules

%Calculation of the matrix with the polarizabilities
TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
%Calculation of the fields at the position of the scatterers
TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveE,rdip,muv,epsilonv);
%Calculation of the dipolar moments induced by the field
Pvector=TheMat\TheV
%valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@PlaneWaveE,TheV,TheMat,rdip);


if 1>-1
    Radius=1800;
    NA=1;%0.95;
    %NA=0.85;
    [x,y,Ebackx,Ebacky]=BackAperture(NA,Radius,TheV,TheMat,omega,muv,epsilonv,direction,pol,rsource,rdip);
    
    
    PowerBackfocPlaneX=epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))*(2*pi/(199))*(asin(NA)/(198))*(Radius^2)*sum(sum(sqrt(x.^2+y.^2).*Ebackx.*conj(Ebackx),2),1);
    display('PowerBackfocPlaneX [W/mum^2]'); display(PowerBackfocPlaneX);
    display('PowerBackfocPlaneX [S0]'); display(PowerBackfocPlaneX/S0mu);
    
    PowerBackfocPlaneY=epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))*(2*pi/(199))*(asin(NA)/(198))*(Radius^2)*sum(sum(sqrt(x.^2+y.^2).*Ebacky.*conj(Ebacky),2),1);
    display('PowerBackfocPlaneY [W/mum^2]'); display(PowerBackfocPlaneY);
    display('PowerBackfocPlaneY [S0]'); display(PowerBackfocPlaneY/S0mu);
    
    nfigs = get(0,'Children');
    plotflag=size(nfigs,1);

    EbackXscatt=Ebackx;
    EbackYscatt=Ebacky;
    
end

%%%%%%%%%%%%% Definition of the structure without scatterer
numscattererrs=0; % This is the number of scatterers different from the antennas
%Definition of the position of the antennas
[xs,ys]=meshgrid(1:linenumant,1:linenumant);
centershift=round(linenumant/2)*spacing;
X=xs(:)*spacing-centershift;
Y=ys(:)*spacing-centershift;
rdip=[X,Y,Y*0];
%Definition of the position of the scatterers
if numscattererrs==2
    scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos];
elseif numscattererrs==3
    
    scatterers=[-deltax+xpos,-deltay+ypos,zpos;deltax+xpos,deltay+ypos,zpos;deltax+xpos+0.05,deltay+ypos,zpos];
    
elseif numscattererrs==1
    scatterers=[-deltax+xpos,-deltay+ypos,zpos];
elseif  numscattererrs==0
    scatterers=[];
end



%JOined positions of the scatterers and the antennas
rdip=[rdip;scatterers];

%%%%%%%%%%%%%

%definition of the values for the polarizabilities of the antennas and the
%scatterers
[w0list,gammalist,alist,blist]=InitializeListValuesAntennaLensArray(linenumant,numscattererrs);
%blist=alist*1000000;
%alist=alist*1000000;
%gammalist=gammalist*0;


%Calculation of the matrix with the polarizabilities
TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
%Calculation of the fields at the position of the scatterers
TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveE,rdip,muv,epsilonv);
%Calculation of the dipolar moments induced by the field
Pvector=TheMat\TheV
%valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@PlaneWaveE,TheV,TheMat,rdip);


if 1>-1
    Radius=1800;
    NA=1;%0.95;
    %NA=0.85;
    [x,y,Ebackx,Ebacky]=BackAperture(NA,Radius,TheV,TheMat,omega,muv,epsilonv,direction,pol,rsource,rdip);
    
    
    PowerBackfocPlaneX=epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))*(2*pi/(199))*(asin(NA)/(198))*(Radius^2)*sum(sum(sqrt(x.^2+y.^2).*Ebackx.*conj(Ebackx),2),1);
    display('PowerBackfocPlaneX [W/mum^2]'); display(PowerBackfocPlaneX);
    display('PowerBackfocPlaneX [S0]'); display(PowerBackfocPlaneX/S0mu);
    
    PowerBackfocPlaneY=epszero*co*(1/2)*sqrt((epsilonv*eps1)/(mu0*mu1))*(2*pi/(199))*(asin(NA)/(198))*(Radius^2)*sum(sum(sqrt(x.^2+y.^2).*Ebacky.*conj(Ebacky),2),1);
    display('PowerBackfocPlaneY [W/mum^2]'); display(PowerBackfocPlaneY);
    display('PowerBackfocPlaneY [S0]'); display(PowerBackfocPlaneY/S0mu);
    
    nfigs = get(0,'Children');
    plotflag=size(nfigs,1);

    EbackXNoscatt=Ebackx;
    EbackYNoscatt=Ebacky;
    
end




figure(12);pcolor(x,y,(abs(EbackXscatt)-abs(EbackXNoscatt)));shading flat;axis image ;colorbar;
title('Signal Difference Field (|E| [V/\mum])')
xlabel('sin(theta)')
ylabel('sin(theta)')

figure(13);pcolor(x,y,(1/2)*epszero*co*(abs(EbackXscatt)-abs(EbackXNoscatt)).^2);shading flat;axis image ;colorbar;
title('Signal Difference Intensity ([W/\mum^2])')
xlabel('sin(theta)')
ylabel('sin(theta)')







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%








