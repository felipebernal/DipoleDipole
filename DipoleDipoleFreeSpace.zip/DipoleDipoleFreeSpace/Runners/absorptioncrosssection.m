function absorptioncrosssection


      name='yagiuda';
p = path;
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   

struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
t=0.1;
% struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;1.000001;1.000001],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% t=0.1;
% %t=0;

Radius=1000;
numberofpoints=10;

Ndip=1;
rdip=InitializeDipolePositions(Ndip,1,'yagiuda');%For the yagiUda Ndip and dist do not matter.
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);


direction=[0 0 -1];
pol=[1 0 0];
rsource=[0 0 0];



minlambda=500;
maxlambda=800;
deltalambda=10;
vecplotx=zeros(size([minlambda:deltalambda:maxlambda].',1),1);
vecploty=zeros(size([minlambda:deltalambda:maxlambda].',1),1);
vecplotz=zeros(size([minlambda:deltalambda:maxlambda].',1),1);
cont=1;
for c=minlambda:deltalambda:maxlambda
    omega=2*pi/(c/1000);
    k=omega/c;
    %We need to reorganize Pvector so that we get a Ndipx 3 matrix which is
    %easier to work with when we use multiprod.
  invalpha=INVPolarizabilityProlate(omega,w0list,gammalist,alist,blist,rdip,struct,t);
  alpha=inv(invalpha);
% vecplotx(cont)=k*imag(alpha(1,1)+alpha(4,4)+alpha(7,7)+alpha(10,10)+alpha(15,15));
  vecplotx(cont)=k*imag(alpha(1,1));
 vecploty(cont)=k*imag(alpha(2,2));
 vecplotz(cont)=k*imag(alpha(3,3));
 
    % clear('matrix','vector');
   
  ([int2str(cont),' out of ', int2str((maxlambda-minlambda)/deltalambda)])
     cont=cont+1;
end
%a=[[minlambda:deltalambda:maxlambda].',vecplot];
%save(['\\nanorfsrv\Users\Bernal\Simulations\',day,'\TotalScattCrossSecYagiUda.txt'], 'a','-ascii');
figure(1)
subplot(2,2,1);
plot([minlambda:deltalambda:maxlambda].',vecplotx,'o');
title('x')
subplot(2,2,2);
plot([minlambda:deltalambda:maxlambda].',vecploty,'o');
title('y')
subplot(2,2,3);
plot([minlambda:deltalambda:maxlambda].',vecplotz,'o');
title('z')
subplot(2,2,4);
plot([minlambda:deltalambda:maxlambda].',vecplotx,'o',[minlambda:deltalambda:maxlambda].',vecploty,'o',[minlambda:deltalambda:maxlambda].',vecplotz,'o');
title('All')
end