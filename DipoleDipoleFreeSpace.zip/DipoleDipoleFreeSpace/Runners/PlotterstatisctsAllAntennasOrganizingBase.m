%all antennas plot for chapter 3

%close all
%clear all
%clc

%a=load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\statistics2000YU2p5nmAllAntennas.mat');
%a=load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\statistics2000YU2p5nmAllAntennas.mat');

%a=load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\statistics2000YU2p5nmWithNormaldistributionv3.mat');
%b= load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\LDOSmatrix2000YU2p5nmWithNormaldistributionv3.mat');

a=load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\statistics5000YU2p5nmWithNormaldistributionv3plusLDOS.mat');
b= load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\LDOSmatrix5000YU2p5nmWithNormaldistributionv3.mat');

LDOSMatrixLambda=b.LDOSMatrixLambda;
Matrixdirectivity=a.Matrixdirectivity;

numbars=100;

 sizenumanten=size(Matrixdirectivity,1);
%%%starting for wavelength=600

wavel=1;


matrtoOrganize=squeeze(LDOSMatrixLambda(:,wavel,:));

maxLDOSperpos=squeeze(max(max(LDOSMatrixLambda)));
minLDOSperpos=squeeze(min(min(LDOSMatrixLambda)));



maxperfreqallele=repmat(max(LDOSMatrixLambda,[],3),[1,1,5]);
maxperfreq=repmat(max(max(LDOSMatrixLambda,[],3),[],1),[5000,1,5]);

tablecomparison=not(abs((LDOSMatrixLambda./maxperfreqallele)-1)>0.341);
%tablecomparison=not(abs((LDOSMatrixLambda./maxperfreqallele)-1)>0.25)&not(LDOSMatrixLambda<(0.05*maxperfreq));


c1st=[ones(16,1);zeros(16,1)];
c2nd=[ones(8,1);zeros(8,1);ones(8,1);zeros(8,1)];
c3rd=[ones(4,1);zeros(4,1);ones(4,1);zeros(4,1);ones(4,1);zeros(4,1);ones(4,1);zeros(4,1)];
c4th=[ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1)];
c5th=[1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0];
matrixallpos1sand0s=[c1st,c2nd,c3rd,c4th,c5th];
numa=size(matrixallpos1sand0s,1);
 
 brightupat600=squeeze(tablecomparison(:,1,:));
 brightupat650=squeeze(tablecomparison(:,2,:));
 brightupat700=squeeze(tablecomparison(:,3,:));
 brightupat750=squeeze(tablecomparison(:,4,:));
 brightupat800=squeeze(tablecomparison(:,5,:));
 brightupat850=squeeze(tablecomparison(:,6,:));
 brightupat900=squeeze(tablecomparison(:,7,:));
 
 matnumberrealizationpercaseat=zeros(numa,4);
%whichtype of antenna is the realization of the antenna is written in
 whichBaseelement=zeros(sizenumanten,4);%for all different wavelength ranges

 plotmat1=zeros(sizenumanten,5);
plotmat2=zeros(sizenumanten,5);
plotmat3=zeros(sizenumanten,5);
plotmat4=zeros(sizenumanten,5);

whichwhere=zeros(sizenumanten,4);

 for realiza=1:numa
  
    expos=matrixallpos1sand0s(realiza,:);%here we take every element of the base
    %here we compare the element to each all the antennas
    comparison650=(sum(brightupat650==repmat(expos,sizenumanten,1),2)==5);
    comparison700=(sum(brightupat700==repmat(expos,sizenumanten,1),2)==5);
    comparison750=(sum(brightupat750==repmat(expos,sizenumanten,1),2)==5);
    comparison800=(sum(brightupat800==repmat(expos,sizenumanten,1),2)==5);
    whichBaseelement(comparison650,1)=realiza;
    whichBaseelement(comparison700,2)=realiza;
    whichBaseelement(comparison750,3)=realiza;
    whichBaseelement(comparison800,4)=realiza;
    
    matnumberrealizationpercaseat(realiza,1)=sum(comparison650,1);
    matnumberrealizationpercaseat(realiza,2)=sum(comparison700,1);
    matnumberrealizationpercaseat(realiza,3)=sum(comparison750,1);
    matnumberrealizationpercaseat(realiza,4)=sum(comparison800,1);
    
    % since we know whate antennas pertain to which element in the base at a
% given band frequency then we can plot for a band freuqncy e.g. 650 nm the
% antennas of type 1-32 where the pixels are the max LDOS. at each position
% of the antenna

% if realiza==1
% plotmat1(1:matnumberrealizationpercaseat(realiza,1),:)=[Matrixdirectivity(comparison700,9,1),Matrixdirectivity(comparison700,9,2),Matrixdirectivity(comparison700,9,3),Matrixdirectivity(comparison700,9,4),Matrixdirectivity(comparison700,9,5)];
% else
    
    ind11=sum(matnumberrealizationpercaseat(1:realiza-1,1),1);
    ind21=sum(matnumberrealizationpercaseat(1:realiza,1),1);
    
    ind12=sum(matnumberrealizationpercaseat(1:realiza-1,2),1);
    ind22=sum(matnumberrealizationpercaseat(1:realiza,2),1);
    
    ind13=sum(matnumberrealizationpercaseat(1:realiza-1,3),1);
    ind23=sum(matnumberrealizationpercaseat(1:realiza,3),1);
    
    ind14=sum(matnumberrealizationpercaseat(1:realiza-1,4),1);
    ind24=sum(matnumberrealizationpercaseat(1:realiza,4),1);
    
    
%     if ind1==0
%         ind1=1;
%     end
    if ind21~=0 && ind21~=ind11
        plotmat1(ind11+1:ind21,:)=[LDOSMatrixLambda(comparison650,2,1),LDOSMatrixLambda(comparison650,2,2),LDOSMatrixLambda(comparison650,2,3),LDOSMatrixLambda(comparison650,2,4),LDOSMatrixLambda(comparison650,2,5)];
    whichwhere(ind11+1:ind21,1)=realiza;
    end
    
    if ind22~=0 && ind22~=ind12
        plotmat2(ind12+1:ind22,:)=[LDOSMatrixLambda(comparison700,3,1),LDOSMatrixLambda(comparison700,3,2),LDOSMatrixLambda(comparison700,3,3),LDOSMatrixLambda(comparison700,3,4),LDOSMatrixLambda(comparison700,3,5)];
     whichwhere(ind12+1:ind22,2)=realiza;
    end
    
    if ind23~=0 && ind23~=ind13
        plotmat3(ind13+1:ind23,:)=[LDOSMatrixLambda(comparison750,4,1),LDOSMatrixLambda(comparison750,4,2),LDOSMatrixLambda(comparison750,4,3),LDOSMatrixLambda(comparison750,4,4),LDOSMatrixLambda(comparison750,4,5)];
      whichwhere(ind13+1:ind23,3)=realiza;
    end
    
    if ind24~=0 && ind24~=ind14
        plotmat4(ind14+1:ind24,:)=[LDOSMatrixLambda(comparison800,5,1),LDOSMatrixLambda(comparison800,5,2),LDOSMatrixLambda(comparison800,5,3),LDOSMatrixLambda(comparison800,5,4),LDOSMatrixLambda(comparison800,5,5)];
      whichwhere(ind14+1:ind24,4)=realiza;
    end
    
   
    
    
end
 
 
 
% 
% %first index is the realizations...second index has many different values
% %and 10 is the wavelength of the max LDOS...last index is where the antenna
% %is beign driven.
% 
% [nelLDOS1,centLDOS1]=hist(Matrixdirectivity(:,10,1),numbars);
% [nelLDOS2,centLDOS2]=hist(Matrixdirectivity(:,10,2),numbars);
% [nelLDOS3,centLDOS3]=hist(Matrixdirectivity(:,10,3),numbars);
% [nelLDOS4,centLDOS4]=hist(Matrixdirectivity(:,10,4),numbars);
% [nelLDOS5,centLDOS5]=hist(Matrixdirectivity(:,10,5),numbars);
% 
% sizenumanten=size(Matrixdirectivity,1);
% 
% figure(1)
% plot(centLDOS1,nelLDOS1,'.',centLDOS2,nelLDOS2,'.',centLDOS3,nelLDOS3,'.',centLDOS4,nelLDOS4,'.',centLDOS5,nelLDOS5,'.');
% 
% %figure(2)
% matrixthingy=[nelLDOS1;nelLDOS2;nelLDOS3;nelLDOS4;nelLDOS5];
% figure(2)
% imagesc(matrixthingy.')
% 
% list=1:sizenumanten;
% figure(3)
% plot(list,Matrixdirectivity(:,10,1),list,Matrixdirectivity(:,10,2),list,Matrixdirectivity(:,10,3),list,Matrixdirectivity(:,10,4),list,Matrixdirectivity(:,10,5))
% figure(4)
% plot(list,Matrixdirectivity(:,9,1),list,Matrixdirectivity(:,9,2),list,Matrixdirectivity(:,9,3),list,Matrixdirectivity(:,9,4),list,Matrixdirectivity(:,9,5))
% %In order to find the different realizations of max wavelengths we do the following
% 
% matrixmaxwaveLDOSdiffele=[Matrixdirectivity(:,10,1),Matrixdirectivity(:,10,2),Matrixdirectivity(:,10,3),Matrixdirectivity(:,10,4),Matrixdirectivity(:,10,5)];
% brightupat650=matrixmaxwaveLDOSdiffele>625 & matrixmaxwaveLDOSdiffele<675;
% brightupat700=matrixmaxwaveLDOSdiffele>675 & matrixmaxwaveLDOSdiffele<725;
% brightupat750=matrixmaxwaveLDOSdiffele>725 & matrixmaxwaveLDOSdiffele<775;
% brightupat800=matrixmaxwaveLDOSdiffele>775 & matrixmaxwaveLDOSdiffele<825;
% 
% 
% c1st=[ones(16,1);zeros(16,1)];
% c2nd=[ones(8,1);zeros(8,1);ones(8,1);zeros(8,1)];
% c3rd=[ones(4,1);zeros(4,1);ones(4,1);zeros(4,1);ones(4,1);zeros(4,1);ones(4,1);zeros(4,1)];
% c4th=[ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1);ones(2,1);zeros(2,1)];
% c5th=[1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0;1;0];
% matrixallpos1sand0s=[c1st,c2nd,c3rd,c4th,c5th];
% %matrixallpos1sand0s=matrixallpos1sand0s(1:end-1,:);
% numa=size(matrixallpos1sand0s,1);
% 
% matnumberrealizationpercaseat=zeros(numa,4);
% %whichtype of antenna is the realization of the antenna is written in
% whichBaseelement=zeros(sizenumanten,4);%for all different wavelength ranges
% 
% 
% 
% 
% plotmat1=zeros(sizenumanten,5);
% plotmat2=zeros(sizenumanten,5);
% plotmat3=zeros(sizenumanten,5);
% plotmat4=zeros(sizenumanten,5);
% 
% 
% 
% for realiza=1:numa
%   
%     expos=matrixallpos1sand0s(realiza,:);%here we take every element of the base
%     %here we compare the element to each all the antennas
%     comparison650=(sum(brightupat650==repmat(expos,sizenumanten,1),2)==5);
%     comparison700=(sum(brightupat700==repmat(expos,sizenumanten,1),2)==5);
%     comparison750=(sum(brightupat750==repmat(expos,sizenumanten,1),2)==5);
%     comparison800=(sum(brightupat800==repmat(expos,sizenumanten,1),2)==5);
%     whichBaseelement(comparison650,1)=realiza;
%     whichBaseelement(comparison700,2)=realiza;
%     whichBaseelement(comparison750,3)=realiza;
%     whichBaseelement(comparison800,4)=realiza;
%     
%     matnumberrealizationpercaseat(realiza,1)=sum(comparison650,1);
%     matnumberrealizationpercaseat(realiza,2)=sum(comparison700,1);
%     matnumberrealizationpercaseat(realiza,3)=sum(comparison750,1);
%     matnumberrealizationpercaseat(realiza,4)=sum(comparison800,1);
%     
%     % since we know whate antennas pertain to which element in the base at a
% % given band frequency then we can plot for a band freuqncy e.g. 650 nm the
% % antennas of type 1-32 where the pixels are the max LDOS. at each position
% % of the antenna
% 
% % if realiza==1
% % plotmat1(1:matnumberrealizationpercaseat(realiza,1),:)=[Matrixdirectivity(comparison700,9,1),Matrixdirectivity(comparison700,9,2),Matrixdirectivity(comparison700,9,3),Matrixdirectivity(comparison700,9,4),Matrixdirectivity(comparison700,9,5)];
% % else
%     
%     ind11=sum(matnumberrealizationpercaseat(1:realiza-1,1),1);
%     ind21=sum(matnumberrealizationpercaseat(1:realiza,1),1);
%     
%     ind12=sum(matnumberrealizationpercaseat(1:realiza-1,2),1);
%     ind22=sum(matnumberrealizationpercaseat(1:realiza,2),1);
%     
%     ind13=sum(matnumberrealizationpercaseat(1:realiza-1,3),1);
%     ind23=sum(matnumberrealizationpercaseat(1:realiza,3),1);
%     
%     ind14=sum(matnumberrealizationpercaseat(1:realiza-1,4),1);
%     ind24=sum(matnumberrealizationpercaseat(1:realiza,4),1);
%     
%     
% %     if ind1==0
% %         ind1=1;
% %     end
%     if ind21~=0 && ind21~=ind11
%         plotmat1(ind11+1:ind21,:)=[LDOSMatrixLambda(comparison650,2,1),LDOSMatrixLambda(comparison650,2,2),LDOSMatrixLambda(comparison650,2,3),LDOSMatrixLambda(comparison650,2,4),LDOSMatrixLambda(comparison650,2,5)];
%     end
%     
%     if ind22~=0 && ind22~=ind12
%         plotmat2(ind12+1:ind22,:)=[LDOSMatrixLambda(comparison700,3,1),LDOSMatrixLambda(comparison700,3,2),LDOSMatrixLambda(comparison700,3,3),LDOSMatrixLambda(comparison700,3,4),LDOSMatrixLambda(comparison700,3,5)];
%     end
%     
%     if ind23~=0 && ind23~=ind13
%         plotmat3(ind13+1:ind23,:)=[LDOSMatrixLambda(comparison750,4,1),LDOSMatrixLambda(comparison750,4,2),LDOSMatrixLambda(comparison750,4,3),LDOSMatrixLambda(comparison750,4,4),LDOSMatrixLambda(comparison750,4,5)];
%     end
%     
%     if ind24~=0 && ind24~=ind14
%         plotmat4(ind14+1:ind24,:)=[LDOSMatrixLambda(comparison800,5,1),LDOSMatrixLambda(comparison800,5,2),LDOSMatrixLambda(comparison800,5,3),LDOSMatrixLambda(comparison800,5,4),LDOSMatrixLambda(comparison800,5,5)];
%     end
%     
%    
%     
%     
% end
%end
% 
% %above one percent realizations
% 
%  whichrelizations=matnumberrealizationpercaseat>sizenumanten/100;
% matrealiztoplot700=matrixallpos1sand0s(whichrelizations(:,1),:);
% matrealiztoplot750=matrixallpos1sand0s(whichrelizations(:,2),:);
% matrealiztoplot800=matrixallpos1sand0s(whichrelizations(:,3),:);
% matrealiztoplot850=matrixallpos1sand0s(whichrelizations(:,4),:);
% 
% figure(5)
% subplot(1,2,1)
% imagesc(matrealiztoplot700)
% antennas700=matnumberrealizationpercaseat(whichrelizations(:,1),1);
% subplot(1,2,2)
% %bar(antennas700/sum(antennas700,1)*100);
% bar(antennas700/sizenumanten*100);
% view(90,90)
% title('650 nm +/-25 nm')
% 
% figure(6)
% 
% subplot(1,2,1)
% imagesc(matrealiztoplot750)
% antennas750=matnumberrealizationpercaseat(whichrelizations(:,2),2);
% subplot(1,2,2)
% %bar(antennas750/sum(antennas750,1)*100);
% bar(antennas750/sizenumanten*100);
% view(90,90)
% title('700 nm +/-25 nm')
% 
% figure(7)
% 
% antennas800=matnumberrealizationpercaseat(whichrelizations(:,3),3);
% subplot(1,2,1)
% imagesc(matrealiztoplot800)
% subplot(1,2,2)
% %bar(antennas800/sum(antennas800,1)*100);
% bar(antennas800/sizenumanten*100);
% view(90,90)
% title('750 nm +/-25 nm')
% 
% figure(8)
% antennas850=matnumberrealizationpercaseat(whichrelizations(:,4),4);
% subplot(1,2,1)
% imagesc(matrealiztoplot850)
% subplot(1,2,2)
% %bar(antennas800/sum(antennas800,1)*100);
% bar(antennas850/sizenumanten*100);
% view(90,90)
% title('800 nm +/-25 nm')
% 
pixtocm=50;
figure(9);
hFig1 = figure(9);
 set(gcf,'PaperPositionMode','auto')
 set(hFig1, 'Position', [300 500 3*pixtocm 4.2*pixtocm])
imagesc(plotmat1); 
caxis([0 40])
colorbar
colormap bone

figure(10);
hFig2 = figure(10);
 set(gcf,'PaperPositionMode','auto')
 set(hFig2, 'Position', [500 500 3*pixtocm 4.2*pixtocm])
imagesc(plotmat2); 
caxis([0 40])
colorbar
colormap bone

figure(11);
hFig3 = figure(11);
 set(gcf,'PaperPositionMode','auto')
 set(hFig3, 'Position', [700 500 3*pixtocm 4.2*pixtocm])
imagesc(plotmat3);
caxis([0 40])
colorbar
colormap bone

figure(12);
hFig4 = figure(12);
 set(gcf,'PaperPositionMode','auto')
 set(hFig4, 'Position', [900 500 3*pixtocm 4.2*pixtocm])
imagesc(plotmat4*2);%look that here we multiply by two so that the max is around 40!!!
caxis([0 40])
colorbar
colormap bone

figure(13);
hFig5 = figure(13);
 set(gcf,'PaperPositionMode','auto')
 set(hFig5, 'Position', [1100 500 3*pixtocm 4.2*pixtocm])
 imagesc(matrixallpos1sand0s); 
 caxis([0 1])
%colorbar
colormap bone
% 
% 
% 
% 

%%first we create a colormap
% map = zeros(32, 3);
% mapspace=linspace(390,630,32);
% map=reshape(Wavelength_to_RGB(mapspace),32,3)./255;
% 
% map(:,2:3)=abs(map(:,2:3)-0.2);
% 
% map(17,:)=[1,1,1];
% map(16,:)=[0,0,0];
% map(18,:)=[44,158,79]./255;
% map(15,:)=[ 0.35,0.6000,0.4000];

% map=zeros(32, 3);
% mapspace=linspace(0,1,32).';
% map=[abs(cos(mapspace*pi)),abs(sin(mapspace*pi)),exp(mapspace)/exp(1)];
% 


% map=zeros(32, 3);
% mapspace=linspace(0,1,32).';
% map=[mapspace,1*sin((mapspace*pi/6))+rand(1,32).'/20,0.25*cos(mapspace*pi/6)];
% 
% 


map=zeros(32, 3);
mapspace1=linspace(0,1,8).';
col1a=[242,104,47]./255;
col1b=[118,114,184]./255;
col2a=([242,0,0]+abs([20,104,47]-20))./255;
col2b=([118,0,0]+abs([20,114,184]-20))./255;

col3a=([242,0,0]+abs([40,104,47]-40))./255;
col3b=([118,0,0]+abs([40,114,184]-40))./255;

col4a=([242,0,0]+abs([60,104,47]-60))./255;
col4b=([118,0,0]+abs([60,114,184]-60))./255;


num=8;
map1=[linspace(col1a(1),col1b(1),num).',linspace(col1a(2),col1b(2),num).',linspace(col1a(3),col1b(3),num).'];
map2=[linspace(col2a(1),col2b(1),num).',linspace(col2a(2),col2b(2),num).',linspace(col2a(3),col2b(3),num).'];
map3=[linspace(col3a(1),col3b(1),num).',linspace(col3a(2),col3b(2),num).',linspace(col3a(3),col3b(3),num).'];
map4=[linspace(col4a(1),col4b(1),num).',linspace(col4a(2),col4b(2),num).',linspace(col4a(3),col4b(3),num).'];

map=[map1.';map2.';map3.';map4.'];
map=reshape(map(:),3,[]).';

 map(24,:)=[0,0,0];
 map(16,:)=[1,1,1];






x=1;
figure(x+13);
hFig5 = figure(x+13);
 set(gcf,'PaperPositionMode','auto')
 set(hFig5, 'Position', [1300 500 1.5*pixtocm 4.2*pixtocm])
 imagesc(whichwhere(:,x)); 
 caxis([1 32])
 set(gca,'XTickLabel',[])
 set(gca,'YTickLabel',[])
%colorbar
colormap(map)


x=2;
figure(x+13);
hFig5 = figure(x+13);
 set(gcf,'PaperPositionMode','auto')
 set(hFig5, 'Position', [1300 500 1.5*pixtocm 4.2*pixtocm])
 imagesc(whichwhere(:,x)); 
 caxis([1 32])
  set(gca,'XTickLabel',[])
 set(gca,'YTickLabel',[])
%colorbar
colormap(map)


x=3;
figure(x+13);
hFig5 = figure(x+13);
 set(gcf,'PaperPositionMode','auto')
 set(hFig5, 'Position', [1300 500 1.5*pixtocm 4.2*pixtocm])
 imagesc(whichwhere(:,x)); 
 caxis([1 32])
  set(gca,'XTickLabel',[])
 set(gca,'YTickLabel',[])
%colorbar
colormap(map)

x=4;
figure(x+13);
hFig5 = figure(x+13);
 set(gcf,'PaperPositionMode','auto')
 set(hFig5, 'Position', [1300 500 1.5*pixtocm 4.2*pixtocm])
 imagesc(whichwhere(:,x)); 
 caxis([1 32])
  set(gca,'XTickLabel',[])
 set(gca,'YTickLabel',[])
%colorbar
colormap(map)


x=5;
figure(x+13);
hFig5 = figure(x+13);
 set(gcf,'PaperPositionMode','auto')
 set(hFig5, 'Position', [1300 500 1.5*pixtocm 4.2*pixtocm])
 imagesc([1:32].'); 
 caxis([1 32])
  set(gca,'XTickLabel',[])
 set(gca,'YTickLabel',[])
%colorbar
colormap(map)



%now we plot the histogrms with the frequency of apparition of every
%element for every frequency.



   
vectorcomp=reshape([1:32],1,1,[]); %first the 32 elements in the 3rd dimension
matcomp=repmat(vectorcomp,[5000,4,1]); %then we reapeat it 5000 times in y and 4 in x
%now we compare it to a matrix which tells you which antenna was in which
%vector of the otrganizing base
%first we repeat thewhich baseelement matrix
matrixwhichBaselement=repmat(whichBaseelement,[1,1,32]);
%now we compare

histoOfVectcomp=reshape(sum(matrixwhichBaselement==matcomp,1),4,32).';

hFig5 =figure(19)
bar(histoOfVectcomp(:,1)/5000*100)
set(gcf,'PaperPositionMode','auto')
 set(hFig5, 'Position', [300 200 1.5*pixtocm 4.2*pixtocm])
xlim([0.5,32.5])
 % title('650 nm')
 view(90,90)

hFig5 = figure(20)
bar(histoOfVectcomp(:,2)/5000*100)
set(gcf,'PaperPositionMode','auto')
 set(hFig5, 'Position', [500 200 1.5*pixtocm 4.2*pixtocm])
xlim([0.5,32.5])
  %title('700 nm')
 view(90,90)

hFig5 = figure(21)
bar(histoOfVectcomp(:,3)/5000*100)
set(gcf,'PaperPositionMode','auto')
 set(hFig5, 'Position', [700 200 1.5*pixtocm 4.2*pixtocm])
xlim([0.5,32.5])
  %title('750 nm')
 view(90,90)

hFig5 = figure(22)
bar(histoOfVectcomp(:,4)/5000*100)
set(gcf,'PaperPositionMode','auto')
 set(hFig5, 'Position', [900 200 1.5*pixtocm 4.2*pixtocm])
xlim([0.5,32.5])
  %title('800 nm')
 view(90,90)

 %disp('the number of thimes that at 650nm the feed is on is:')
 %sum(histoOfVectcomp(17:24,1),1)/5000*100
 
 
 %at 750 nm the directors are on this frequency
 % sum([histoOfVectcomp(1:7,3);histoOfVectcomp(9:15,3);histoOfVectcomp(17:23,3);histoOfVectcomp(25:31,3)],1)/5000*100
%at 750 nm the feed is on this frequency
 %sum([histoOfVectcomp(1:8,3);histoOfVectcomp(17:24,3)],1)/5000*100