
function [polarizabilityALL,dall,LS]=DimerDistancePolarizabilities
p = path;
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   


struct=[[1;4.01;2.127],[1;1;1]];
t=0.1;

Li=0.4;
Lf=1.4;
numL=20;
LS=linspace(Li,Lf,numL);

dmax=5;
dmin=0.09;
numh=20;
dall=logspace(log10(dmax),log10(dmin),numh);
%dall=linspace((dmax),(dmin),numh);
polarizabilityALL=zeros(6,6,numL,numh);
Ndip=2;
for conth=1:numh
for conti=1:numL

lambda=LS(conti);
omega=2*pi/lambda;
heig=1;

dist=dall(conth);
rdip=[0,0,heig;dist,0,heig];
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);
TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
polarizabilityALL(:,:,conti,conth)=inv(TheMat);
conti
   
end
conth
end

