%load the statistic file
%all these files only have the excitation based on the feed element... in
%contrast with the file statisticsplotterexcAllelements wich has them all.

%a= load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\statistics10000YU2p5nm.mat');
 %a=load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\statistics5000YU2p5nmWithNormaldistribution.mat');
 a=load('\\nanorfsrv\Users\Bernal\ExperimentsInProgress\CL Bridges\DipoleDipoleYagiUdas\statistics5000YU2p5nmWithNormaldistributionv2.mat');

 
 close all;
 Matrixdirectivity=a.Matrixdirectivity;

randommat=0.0025*randn(1,5000);
%plot



numbars=100;

if 1<-1
    figure(1)
plot(Matrixdirectivity(:,1),Matrixdirectivity(:,2),'.')    
figure(2)
plot(Matrixdirectivity(:,3),Matrixdirectivity(:,4),'.')    
figure(3)
plot(Matrixdirectivity(:,9),Matrixdirectivity(:,1),'.')    
figure(4)
plot(Matrixdirectivity(:,9),Matrixdirectivity(:,10),'.')    
figure(5)
plot(Matrixdirectivity(:,2),Matrixdirectivity(:,10),'.')    
figure(6)
plot(Matrixdirectivity(:,3),Matrixdirectivity(:,10),'.') 

figure(7)
plot(Matrixdirectivity(:,3),Matrixdirectivity(:,9),'.')




else
    
figure(1)
plot(Matrixdirectivity(:,1),'.')
figure(2)
plot(Matrixdirectivity(:,2),'.')
figure(3)
plot(Matrixdirectivity(:,3),'.')
figure(4)
plot(Matrixdirectivity(:,4),'.')
figure(5)
hist(Matrixdirectivity(:,1),numbars)
title('Directivity low wavelength peak')
[nelLowWave,centersLowWave]=hist(Matrixdirectivity(:,2),numbars);
figure(6)
hist(Matrixdirectivity(:,2),numbars);
title('Wavelength low wavelength peak')
figure(7)
hist(Matrixdirectivity(:,3),numbars);
title('Directivity high wavelength peak')
[nelHighWave,centersHighWave]=hist(Matrixdirectivity(:,4),numbars);
figure(8)
hist(Matrixdirectivity(:,4),numbars);
title('Wavelength high wavelength peak')
figure(9)
hist(Matrixdirectivity(:,5),numbars);
title('anglephimaxdirect1')
figure(10)
hist(Matrixdirectivity(:,6),numbars);
title('anglephimaxdirect2')
figure(11)
hist(Matrixdirectivity(:,7),numbars);
title('anglethetamaxdirect1')
figure(12)
hist(Matrixdirectivity(:,8),numbars);
title('anglethetamaxdirect2')
figure(13)
hist(Matrixdirectivity(:,9),numbars);
title('maxLDOS')
figure(14)
hist(Matrixdirectivity(:,10),numbars);
title('waveLDOS')
figure(15)
bar([centersLowWave,centersHighWave],[nelLowWave,nelHighWave]);
figure(16)
hist(randommat,numbars);
end