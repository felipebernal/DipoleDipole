function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
  ...  [sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
          [sigmascatparallel, sigmascatperpend,TheMat,TheV,omega,rdip,struct,t,Pvector,efficiencycoupling]=runnerBistaticDipoleExcitation(lambda)
      name='yagiuda';
p = path;
%path(p,'..\WaveguideGreensFunctionQuadVGK');
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   
p4 = path;
path(p4,'..\MicroscopeVision');   
      

Radius=1800;


c=1;
eps0=1;
mu0=1;
struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
t=0.1;
% %struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% t=0.1;
% %t=0;

%struct=[[1;1.000001;1],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%t=0.01;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);





omega=2*pi/(lambda/1000);
%omega=pi;


Ndip=5;
%Ndip=1;
rdip=InitializeDipolePositions(Ndip,1,name);%For the yagiUda Ndip and dist do not matter.
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);

direction=[1 0 0];%this gives the direction of the orientation of the dipole
pol=[0 0 1];%this one doesn't do anything
dipoleheightplus=0.01;
rsource=rdip(2,:)+[0,0,dipoleheightplus];

numberofpoints=100;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date; 

TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
TheV=TheVectorFiller(omega, direction,pol,rsource,@DipoleEFieldLayered,rdip,struct,t);



Pvector=TheMat\TheV;
if -1>1

[vecplotparallel,vecplotperpedicular]= FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);

   
    
     Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
     sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrparallel];
     
     Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
     sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* Escatsqrperpendm];
     
          
    %save([directory, dia,'\',name,'DrawingparallelperpendMatrix.mat'],'sigmascatparallel','sigmascatperpend'); 
    figure(1)
    polar(sigmascatparallel(:,1),sigmascatparallel(:,2));
    figure(2)
    polar(sigmascatperpend(:,1),sigmascatperpend(:,2));
    figure(3)
    polar([sigmascatparallel(:,1);NaN;sigmascatperpend(:,1)],[sigmascatparallel(:,2);NaN;sigmascatperpend(:,2)]); 
end    
%this is the fourier and microscope parts
if -1>1
Radius=1800;
   NA=0.95;
   %NA=0.85;
   BackAperture(NA,Radius,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
   
   fmicroscope=1800;%microns
   ftubelens=100000;%microns
   nlenses=1.5; %refractive index of the lenses used
   [Efocal,numpixelsx,xgrid,ygrid]=microscopevision(omega,TheMat,TheV,rdip,fmicroscope,NA,ftubelens,nlenses,struct,t);
   matrixintensity=reshape(sqrt(sum(Efocal.*conj(Efocal),2)),numpixelsx,numpixelsx);
   figure(5)
   imagesc(xgrid,ygrid,matrixintensity);
   colormap(hot)
   title('Microscope image')
   xlabel('X')
   ylabel('Y')
   
  % drawpolarizabilityAntenna(Pvector,rdip);
   
end
  
   
%    
%    %Now we have here the part for the incoupled ligth into the waveguide.
%    numberofpointsincouping=50;
%    RadiusIncoupling=10;
%    vecplotcircle=FieldGuidedCircleBistaticCrossSec(RadiusIncoupling,numberofpointsincouping,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
%    
%     %EscatsqrIncoupling=sum( vecplotcircle.*conj( vecplotcircle),2);%sum(abs(vecplotparallel).^2,2);
%     EscatsqrIncoupling=abs(vecplotcircle(:,1));%sum(abs(vecplotparallel).^2,2);
%     %sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',2*pi*RadiusIncoupling*EscatsqrIncoupling];
%     sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',EscatsqrIncoupling];
%     figure(6)
%    polar(sigmaincoupling(:,1),sigmaincoupling(:,2),'.');
%    integratedint=1;
%    
% 



 
 if 1>-1  
%This part for the incoupled ligth into the waveguide in the greens function way...very slow.
   numberofpointsincouping=50;
   RadiusIncoupling=20;
   vecplotcircle=FieldGuidedCircleBistaticCrossSec(RadiusIncoupling,numberofpointsincouping,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
   
    EscatsqrIncoupling=sum( vecplotcircle.*conj( vecplotcircle),2);%sum(abs(vecplotparallel).^2,2);
    %EscatsqrIncoupling=abs(vecplotcircle(:,1));%sum(abs(vecplotparallel).^2,2);
    
    %sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',2*pi*RadiusIncoupling*EscatsqrIncoupling];
    sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',EscatsqrIncoupling];
    figure(6)
   polar(sigmaincoupling(:,1),sigmaincoupling(:,2),'.');
   integratedint=1;
 end    


 if -1>1
    
   %Now we have here the part for the incoupled ligth into the waveguide.
   %and we try to get what is the efficiency at which it incouples the
   %light
   numberofpointsincouping=50;
   numberpointsheight=5;
   RadiusIncoupling=10;
   [vecplotcylinder,integratedint]=FieldGuidedCylinder(RadiusIncoupling,numberofpointsincouping, numberpointsheight,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
   
  
   integratedint
   
    %EscatsqrIncoupling=sum( vecplotcircle.*conj( vecplotcircle),2);%sum(abs(vecplotparallel).^2,2);
    %EscatsqrIncoupling=reshape(sum(reshape(abs(vecplotcylinder(:,1)),numberpointsheight,[]),1),[],1);%sum(abs(vecplotparallel).^2,2);
    EscatsqrIncouplingant=reshape(abs(vecplotcylinder(:,1)),numberpointsheight,[]);%sum(abs(vecplotparallel).^2,2);
    EscatsqrIncoupling=EscatsqrIncouplingant(2,:).';
    %sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',2*pi*RadiusIncoupling*EscatsqrIncoupling];
    sigmaincoupling=[[0:2*pi/(numberofpointsincouping-1):2*pi]',EscatsqrIncoupling];
    figure(6)
   polar(sigmaincoupling(:,1),sigmaincoupling(:,2),'.');
     
 end


%this is the part of what is the incouplign efficiency
if 1>-1
    k=omega/c;
Pvector=reshape(Pvector,3,Ndip).';
TheVarr=reshape(TheV,3,Ndip).';
fieldatdipole=FieldEfinder('scatt','near',rsource,omega,struct,t,direction,pol,rsource,@DipoleEFieldLayered,TheV,TheMat,rdip)+...
    FieldEfinder('scatt','far',rsource,omega,[[1;1;1],[1;1;1]],0,direction,pol,rsource,@DipoleEFieldLayered,TheV,TheMat,rdip)+...%this part is to get the free space part of the scattered field which we don't get with near field only.
 (omega^2)*mu0*mu1*multiprod(GreenWaveguide(k,rsource,rsource,struct,t),direction.',[1,2],[1]).';
PextintionDipole=(omega/2)*imag(sum(sum([1,0,0].*conj(fieldatdipole),2),1))+(omega*(omega/c)^3/(12*pi*eps0*eps1));%the second term is the power that the dipole does to itself in free space.
Pextintion=(omega/2)*imag(sum(sum(Pvector.*conj(TheVarr),2),1));

%Now we find the power scattered out of plane
%first on top

thetarange=pi/2;
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end)),(numberofpoints))];
allphi=[0;repmat(phipoints,(numberofpoints-1),1)];

positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
vecplotTOP=(1/2)*sqrt((eps0*eps1)/(mu0*mu1))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);

%Now for the bottom
thetarange=pi/2-(pi/2)/(numberofpoints);
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
alltheta=[0;VECrpt1D(thetapoints(2:(end)),(numberofpoints))];
allphi=[0;repmat(phipoints,(numberofpoints-1),1)];

positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),-Radius*cos(alltheta)];%notice the minus in front of the angle for z
valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
vecplotBOTTOM=(1/2)*sqrt((eps0*eps3)/(mu0*mu3))*(2*pi/(numberofpoints-1))*((thetarange)/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);

Pscattered=vecplotTOP+vecplotBOTTOM;




%%%
%EIncomingfield=PlaneWaveELayeredGauss(omega,direction,pol,rdip,rdip,struct,t);
%EIncomingfield=PlaneWaveE(omega,direction,pol,rdip,[0,0,0],struct,t);
%POWincoming=eps0*c*sum(EIncomingfield.*conj(EIncomingfield),2)/2;
%

%So the power got into the waveguide is

Pwaveguide=Pextintion-Pscattered;
%efficiencycoupling=Pwaveguide/Pextintion; %This would be the portion of the
%work absorved or incoupled
%efficiencycoupling=Pwaveguide/POWincoming;%This would be the portion of the
%incoming power from the plane wave absorved or incoupled
efficiencycoupling=Pwaveguide/Pextintion;%This would be the portion of the
    
    Pwaveguide+PextintionDipole;
    
end




   