function vecplot=FieldTotalCrossSecYagiUdaToppart(guided)

p = path;
path(p,'..\WaveguideGreensFunctionv2');
%path(p,'..\WaveguideGreensFunctionQuadVGKProblems');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');




%guided=0; %0 means free space and 1 means guided

struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive
% %index database for siN is 2.00347)
% t=0.1;


%struct=[[1;1.0000001;1],[1;1;1]];%for glass the n is 1.45846(refractive
%index database for siN is 2.00347)
t=0.1;

Radius=1000000;
numberofpoints=20;

Ndip=1;
rdip=InitializeDipolePositions(Ndip,1,'yagiuda');%For the yagiUda Ndip and dist do not matter.
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);

if guided==0
    direction=[0 0 -1];
    pol=[1 0 0];
    rsource=[0 0 0];
    
elseif guided==1
    direction=[0 1 0];
    pol=[1 0 0];
    rsource=[0 0 0];
end


day=date;
%day='19-Nov-2011';

thetarange=pi/2;
thetapoints=[0:thetarange/(numberofpoints-1):thetarange]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];

minlambda=400;
maxlambda=1000;
deltalambda=20;
vecplot=zeros(size([minlambda:deltalambda:maxlambda].',1),1);
cont=1;
for c=minlambda:deltalambda:maxlambda
    omega=2*pi/(c/1000);
    
    TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
    %save([directory, dia,'\',name,'.mat'],'TheMat');
    if guided==0
        TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayered,rdip,struct,t);
        valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@PlaneWaveELayered,TheV,TheMat,rdip);
         vecplot(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
    
    elseif guided==1
        TheV=TheVectorFiller(omega, direction,pol,rsource,@GuidedWaveELayered,rdip,struct,t);
        valE=FieldEfinder('scatt','far',positionsphere,omega,struct,t,direction,pol,rsource,@GuidedWaveELayered,TheV,TheMat,rdip);
        fieldatantennasheight=GuidedWaveELayered(omega,direction,pol,[0,0,rdip(1,3)],1,struct,t);
        intensityatAntH=sum(fieldatantennasheight.*conj(fieldatantennasheight),2);
         vecplot(cont)=(2*pi/(numberofpoints-1))*(thetarange/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2))/(intensityatAntH),1);
    
    end
    
    % clear('matrix','vector');
    
   
    ([int2str(cont),' out of', int2str((maxlambda-minlambda)/deltalambda)])
    cont=cont+1;
end
%a=[[minlambda:deltalambda:maxlambda].',vecplot];
%save(['\\nanorfsrv\Users\Bernal\Simulations\',day,'\TotalScattCrossSecYagiUda.txt'], 'a','-ascii');
figure(1)
plot([minlambda:deltalambda:maxlambda].',vecplot);
vecplot=[[minlambda:deltalambda:maxlambda].',vecplot];
end