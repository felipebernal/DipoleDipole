function vecplot=CLexcitationDirectionalityYagiUda

%p = path;
%path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');

%guided=0; %0 means free space and 1 means guided

%struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive
% %index database for siN is 2.00347)
% t=0.1;

muv=1;
epsilonv=1;
c=1;
%struct=[[1;1;1],[1;1;1]];%for glass the n is 1.45846(refractive
%index database for siN is 2.00347)
%t=0.1;

Radius=10000000;
numberofpoints=50;

Ndip=5;
%rdip=InitializeDipolePositions(Ndip,1,'yagiuda');%For the yagiUda Ndip and dist do not matter.
%rdip=InitializeDipolePositions(Ndip,1,'singlerod');%For the singlerod Ndip and dist do not matter.
rdip=InitializeDipolePositions(Ndip,1,'YU1CL');%For the singlerod Ndip and dist do not matter.


%[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);
YU=7;
[w0list,gammalist,alist,blist]=InitializeListVAluesCLYagiUda(YU);

%[w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('reflector',1);
%[w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('feed',1)
%  [w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('dir1',1)
% [w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('dir2',1)
%[w0list,gammalist,alist,blist]=InitializeListVAluesSingleRods('dir3',1)


%this is the CL or better dipole orientation and 
%pol is the orientation
%direction is not used at all
%rsource is the position of the dipole
    direction=[0 0 -1];
    pol=[0 0 1];
    %posit='edgeReflector';
    %  posit='edgefeed';
    % posit='edgedir1';
    %  posit='edgedir2';
     posit='edgefeed';
     if strcmp(posit,'edgeReflector')
         rsource=rdip(1,:)+[alist(1,:),0,0.03];
    elseif strcmp(posit,'edgefeed')
         rsource=rdip(2,:)+[alist(2,:),0,0.03];
    elseif strcmp(posit,'edgedir1')
         rsource=rdip(3,:)+[alist(3,:),0,0.03];
    elseif strcmp(posit,'edgedir2')
         rsource=rdip(4,:)+[alist(4,:),0,0.03];
    elseif strcmp(posit,'edgedir3')
         rsource=rdip(5,:)+[alist(5,:),0,0.03];
    end
%day=date;
%day='19-Nov-2011';

thetapoints=[0:pi/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];

minlambda=500;
maxlambda=1000;
deltalambda=5;
vecplot=zeros(size([minlambda:deltalambda:maxlambda].',1),1);
Dir=zeros(size([minlambda:deltalambda:maxlambda].',1),size(allphi,1));
c=1;
cont=1;
for lam=minlambda:deltalambda:maxlambda
    omega=2*pi/(lam/1000);
    
    TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,muv,epsilonv);
    %save([directory, dia,'\',name,'.mat'],'TheMat');
    TheV=TheVectorFiller(omega, direction,pol,rsource,@DipoleEField,rdip,muv,epsilonv);
    valE=FieldEfinder('total','far',positionsphere,omega,muv,epsilonv,direction,pol,rsource,@DipoleEField,TheV,TheMat,rdip);
    P0=(omega^4)/(12*pi*epsilonv*c^3); 
    powerperangle=(1/2)*c*(Radius^2)*sum(valE.*conj(valE),2);
    Ptot=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*sum(sin(alltheta).*powerperangle,1); 
    Dir(cont,:)=(4*pi*powerperangle/Ptot).';
    %vecplot(cont)=(1/P0)*(1/2)*(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);   
    %([int2str(cont),' out of', int2str((maxlambda-minlambda)/deltalambda)])
    cont=cont+1;
end

%a=[[minlambda:deltalambda:maxlambda].',vecplot];
%save(['\\nanorfsrv\Users\Bernal\Simulations\',day,'\TotalScattCrossSecYagiUda.txt'], 'a','-ascii');
[directivity,angleindic]=max(Dir,[],2);
wavelengths=[minlambda:deltalambda:maxlambda].';
figure(1)
plot(wavelengths,directivity);
title('Directivity vs. Wavelength')

figure(2)
plot(wavelengths,allphi(angleindic)/pi*180,[minlambda:deltalambda:maxlambda].',alltheta(angleindic)/pi*180);
title('Directivity vs. Anglephi and Theta')
legend('phi','theta');

vecplot=[wavelengths,max(Dir,[],2)];

%we also need to find what is the wavelength at which this directivity is
%maximum.

[maxdirect,direcindic]=max(directivity)
wavemaxdirect=wavelengths(direcindic)
end