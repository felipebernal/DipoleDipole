function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
  ...  [sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
          [TheMat,TheV,omega,rdip,struct,t,Pvector]=runnerBistaticGuided(lambda)
     name='yagiuda';
p = path;
%path(p,'..\WaveguideGreensFunctionQuadVGK');
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   
p4=path;
path(p3,'..\MicroscopeVision');   

      
clear('Greenscube');
clear('CurlGreenscube');


struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;12;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)

% %struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
% t=0.1;
% %t=0;

%struct=[[1;1.000001;1],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%t=0.01;
t=0.1;

omega=2*pi/(lambda/1000);
%omega=pi;



Ndip=5;
rdip=InitializeDipolePositions(Ndip,1,name);%For the yagiUda Ndip and dist do not matter.
[w0list,gammalist,alist,blist]=InitializeListVAluesYagiUda(Ndip);

direction=[0 -1 0];
pol=[1 0 0];
rsource=[0 0 0];

numberofpoints=500;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date; 


         TheMat=TheMatrixFiller(omega,w0list,gammalist,alist,blist,rdip,struct,t);
        %save([directory, dia,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
         %TheV=TheVectorFiller(omega, direction,pol,rsource,@PlaneWaveELayered,rdip,struct,t);
          TheV=TheVectorFiller(omega, direction,pol,rsource,@GuidedWaveELayered,rdip,struct,t);
 Pvector=TheMat\TheV     

 
 if 1<-1 %make radiation pattern images
     Radius=100;
     [vecplotparallel,vecplotperpedicular]= FieldGuidedSphereBistaticCrossSecGuided(Radius,numberofpoints,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
     
     
     Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
     sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrparallel];
     
     Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
     sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* Escatsqrperpendm];
     
     
     %    save([directory, dia,'\',name,'DrawingparallelperpendMatrix.mat'],'sigmascatparallel','sigmascatperpend');
     
     
     figure(1)
     polar(sigmascatparallel(:,1),sigmascatparallel(:,2));
     figure(2)
     polar(sigmascatperpend(:,1),sigmascatperpend(:,2));
     figure(3)
     polar([sigmascatparallel(:,1);NaN;sigmascatperpend(:,1)],[sigmascatparallel(:,2);NaN;sigmascatperpend(:,2)]);
 end
 
 % figure(4)
 %subplot(2,1,1), polar([0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* sum(Efieldsparallel.*conj(Efieldsparallel),2)),title('\it{Circle parallel to the polarization-k plane }','FontSize',16);
 %subplot(2,1,2), polar([0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* sum(Efieldsperpendicular.*conj(Efieldsperpendicular),2)),title('\it{Circle perpendicular to the polarization-k plane }','FontSize',16);
 
 
 
 
 %
 %    vecplotcircle=FieldGuidedCircleBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
 %     Escatsqrcircle=sum(vecplotcircle.*conj(vecplotcircle),2);%sum(abs(vecplotparallel).^2,2);
 %      sigmascatcircle=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrcircle];
 %    figure(5)
 %     polar(sigmascatcircle(:,1),sigmascatcircle(:,2));
 
 
 NA=0.95;
 if 1<-1 %make fourier image
     
     %NA=0.85;
     RadiusObj=1800;%distance from the sample to the objective;
     BackApertureGuided(NA,RadiusObj,TheV,TheMat,omega,struct,t,direction,pol,rsource,rdip);
 end
 
 if 1>-1 %make real image
     fmicroscope=1800;%microns
     ftubelens=100000;%microns
     nlenses=1.5; %refractive index of the lenses used
     [Efocal,numpixelsx,xgrid,ygrid]=microscopevision(omega,TheMat,TheV,rdip,fmicroscope,NA,ftubelens,nlenses,struct,t);
     matrixintensity=reshape(sqrt(sum(Efocal.*conj(Efocal),2)),numpixelsx,numpixelsx);
     figure(7)
     imagesc(xgrid,ygrid,matrixintensity);
     colormap(hot)
     title(['Microscope image Lambda=',int2str(lambda),'nm'])
     xlabel('X(microns)')
     ylabel('Y(microns)')
     
     drawpolarizabilityAntenna(Pvector,rdip);
 end
 
 
