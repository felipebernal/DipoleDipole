function [w0list,gammalist,alist,blist]=InitializeListValuesAntennaLensArray(linenumant,numscattererrs)
c=1;


  
 %lambdas1=[0.70481-0.152];%this is in microns
  lambdas1=[0.4];%this is in microns
        %alist1=[0.0512252];%alist is the list with the length of the element in microns
        alist1=[0.04];%alist is the list with the length of the element in microns
        blist1=[0.01];
        gammalist1=[0.325];
        
        numanten=linenumant*linenumant;
        
        lambdas=repmat(lambdas1,numanten,1);
        
        alist=repmat(alist1,numanten,1);
        blist=repmat(blist1,numanten,1);
        gammalist=repmat(gammalist1,numanten,1);
       
        
        %the value of the scatteres must be small and different;
        lambScatt=0.3;
        %ascatt=0.009;%this is for r=10nm
        %bscatt=0.009;%this is for r=10nm
        %ascatt=0.015;%this is for r=10nm
        %bscatt=0.015;%this is for r=10nm
        ascatt=0.029;%this is for r=40nm
        bscatt=0.029;%this is for r=40nm
        
        gammascatt=0.3;
        
        lambdas=[lambdas;repmat(lambScatt,numscattererrs,1)];
        w0list=2*pi*(c./lambdas);
        alist=[alist;repmat(ascatt,numscattererrs,1)];
        blist=[blist;repmat(bscatt,numscattererrs,1)];
        gammalist=[gammalist;repmat(gammascatt,numscattererrs,1)];
        