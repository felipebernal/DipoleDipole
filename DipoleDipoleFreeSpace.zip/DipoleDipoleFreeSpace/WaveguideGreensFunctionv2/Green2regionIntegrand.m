function Vectorfunctionsregion2=Green2regionIntegrand(kR,k,h,z,R,phi,struct,t,J0,J1)
numpoints=size(R,1);
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

Vectorfunctionsregion2=[Gv2R(kR,k,h,z,R,phi,struct,t),Gv2z(kR,k,h,z,R,phi,struct,t),Gh2R(kR,k,h,z,R,phi,struct,t),Gh2phi(kR,k,h,z,R,phi,struct,t),Gh2Z(kR,k,h,z,R,phi,struct,t)];


%Here we write the functions for vertical and horizontal dipoles but
%without the angle dependence so that we can use on single integral for
%both Gxi and Gyi components.

function gv2r=Gv2R(kR,k,h,z,~,~,~,t)
gv2r=(1i*exp(1i*(h*k1z(kR,k)-z*k2z(kR,k))).*J1.*kR.*(A2(kR,k,t)-exp(2*1i*z*k2z(kR,k)).*A3(kR,k,t)).*k2z(kR,k))./(4*eps1*k^2*mu1*pi);
end
function gv2z=Gv2z(kR,k,h,z,~,~,~,t)
gv2z=(exp(1i*(h.*k1z(kR,k)-z.*k2z(kR,k))).*J0.*kR^2.*(A2(kR,k,t)+exp(2*1i.*z.*k2z(kR,k)).*A3(kR,k,t)))./(4*eps1*k^2*mu1*pi);
end

function gh2r=Gh2R(kR,k,h,z,R,~,~,t)
    
gh2r=zeros(numpoints,1);
cond=logical(k*R<=(10^-10));   
    
   
gh2r(cond)=(exp(1i*(h(cond)*k1z(kR,k)-z(cond)*k2z(kR,k))).*J0(cond).*k2z(kR,k).*((-1i)*kR*C2(kR,k,t)...
    +B2(kR,k,t)*k2z(kR,k)+...
    exp(2*1i*z(cond)*k2z(kR,k)).*(1i*kR*C3(kR,k,t)+B3(kR,k,t)*k2z(kR,k))))./...
    (4*eps1*k^2*mu1*pi)...
    +(exp(1i*(h(cond).*k1z(kR,k)-z(cond).*k2z(kR,k))).*(kR/2).*(kR*B2(kR,k,t)+1i*C2(kR,k,t)*k2z(kR,k)...%here you have the J1->kr/2 limit
    + exp(2*1i.*z(cond).*k2z(kR,k)).*(kR*B3(kR,k,t)-1i*C3(kR,k,t).*k2z(kR,k))))./...
    (4*eps1*k^2*mu1*pi);


gh2r(not(cond))=(exp(1i*(h(not(cond))*k1z(kR,k)-z(not(cond))*k2z(kR,k))).*J0(not(cond)).*k2z(kR,k).*((-1i)*kR*C2(kR,k,t)...
    +B2(kR,k,t)*k2z(kR,k)+...
    exp(2*1i*z(not(cond))*k2z(kR,k)).*(1i*kR*C3(kR,k,t)+B3(kR,k,t)*k2z(kR,k))))./...
    (4*eps1*k^2*mu1*pi)...
    +(exp(1i*(h(not(cond)).*k1z(kR,k)-z(not(cond)).*k2z(kR,k))).*J1(not(cond)).*(kR*B2(kR,k,t)+1i*C2(kR,k,t)*k2z(kR,k)...
    + exp(2*1i.*z(not(cond)).*k2z(kR,k)).*(kR*B3(kR,k,t)-1i*C3(kR,k,t).*k2z(kR,k))))./...
    (4*eps1*k^2*mu1*pi.*R(not(cond)));


% gh2r=(exp(1i*(h*k1z(kR,k)-z*k2z(kR,k))).*J0.*k2z(kR,k).*((-1i)*kR*C2(kR,k,t)...
%     +B2(kR,k,t)*k2z(kR,k)+...
%     exp(2*1i*z*k2z(kR,k)).*(1i*kR*C3(kR,k,t)+B3(kR,k,t)*k2z(kR,k))))./...
%     (4*eps1*k^2*mu1*pi)...
%     +(exp(1i*(h.*k1z(kR,k)-z.*k2z(kR,k))).*J1.*(kR*B2(kR,k,t)+1i*C2(kR,k,t)*k2z(kR,k)...
%     + exp(2*1i.*z.*k2z(kR,k)).*(kR*B3(kR,k,t)-1i*C3(kR,k,t).*k2z(kR,k))))./...
%     (4*eps1*k^2*mu1*pi.*R);

%Note that this function already doesn't have the cos(phi) dependence which
%we plug after the integration!!!!
end


function gh2phi=Gh2phi(kR,k,h,z,R,~,~,t)
    
gh2phi=zeros(numpoints,1);
cond=logical(k*R<=(10^-10));

gh2phi(cond)=-((exp(h(cond).*1i*k1z(kR,k)-1i.*z(cond).*k2z(kR,k)).*...
(eps2.*J0(cond).*k^2*mu2.*(B2(kR,k,t)+exp(2*1i*z(cond)*k2z(kR,k)).*B3(kR,k,t))./(4*eps1*k^2*mu1*pi)...
-(kR/2).*(kR*B2(kR,k,t)+1i*C2(kR,k,t).*k2z(kR,k)...
+exp(2*1i*z(cond)*k2z(kR,k)).*(kR*B3(kR,k,t)-1i*C3(kR,k,t)*k2z(kR,k)))./(4*eps1*k^2*mu1*pi))));


gh2phi(not(cond))=-((exp(h(not(cond)).*1i*k1z(kR,k)-1i.*z(not(cond)).*k2z(kR,k)).*(eps2.*J0(not(cond)).*k^2*mu2.*R(not(cond)).*(B2(kR,k,t)...
    + exp(2*1i*z(not(cond))*k2z(kR,k)).*B3(kR,k,t))-J1(not(cond)).*(kR*B2(kR,k,t)+1i*C2(kR,k,t).*...
    k2z(kR,k)+ exp(2*1i*z(not(cond))*k2z(kR,k)).*(kR*B3(kR,k,t)-1i*C3(kR,k,t)*k2z(kR,k)))))...
    ./(4*eps1*k^2*mu1*pi.*R(not(cond))));

% gh2phi=-((exp(h.*1i*k1z(kR,k)-1i.*z.*k2z(kR,k)).*(eps2.*J0.*k^2*mu2.*R.*(B2(kR,k,t)...
%     + exp(2*1i*z*k2z(kR,k)).*B3(kR,k,t))-J1.*(kR*B2(kR,k,t)+1i*C2(kR,k,t).*...
%     k2z(kR,k)+ exp(2*1i*z*k2z(kR,k)).*(kR*B3(kR,k,t)-1i*C3(kR,k,t)*k2z(kR,k)))))...
%     ./(4*eps1*k^2*mu1*pi.*R));

%Note that this function already doesn't have the sin(phi) dependence which
%we plug after the integration!!!!
end

function gh2pz=Gh2Z(kR,k,h,z,~,~,~,t)
gh2pz=(exp(1i*(h.*k1z(kR,k)-z.*k2z(kR,k))).*J1.*kR.*(kR*C2(kR,k,t)...
    +1i*B2(kR,k,t)*k2z(kR,k)+exp(2*1i.*z.*k2z(kR,k)).*(kR*C3(kR,k,t)...
    -1i*B3(kR,k,t)*k2z(kR,k))))./(4*eps1*k^2*mu1*pi);
%Note that this function already doesn't have the cos(phi) dependence which
%we plug after the integration!!!!
end

function k1zval=k1z(kR,k)
    tempk1z=sqrt(eps1*mu1*k^2-kR^2);
    if abs(imag(tempk1z))<10^-6
        k1zval=tempk1z;
    else
        k1zval=tempk1z*sign(imag(tempk1z));
    end
end

function k2zval=k2z(kR,k)
 tempk2z=sqrt(eps2*mu2*k^2-kR^2);
    if abs(imag(tempk2z))<10^-6
        k2zval=tempk2z;
    else
        k2zval=tempk2z*sign(imag(tempk2z));
    end
end

function k3zval=k3z(kR,k)
 tempk3z=sqrt(eps3*mu3*k^2-kR^2);
    if abs(imag(tempk3z))<10^-6
        k3zval=tempk3z;
    else
        k3zval=tempk3z*sign(imag(tempk3z));
    end
end



function A2val=A2(kR,k,t)
    A2val=1i*((2*eps1*kR*f4(kR,k)))...
        /(((f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t))));
end

function A3val=A3(kR,k,t)
    A3val=1i*((2*eps1*kR*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        /(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t));
end


function B2val=B2(kR,k,t)
 B2val=1i*(eps1/eps2)*(2*mu1*kR*g4(kR,k))...
        /(g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t));   
end

function B3val=B3(kR,k,t)
 B3val=1i*(eps1/eps2)*(2*mu1*kR*g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
        /(g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t));   
end

% 
%     function C2val=C2(kR,k,t)
%         C2val=2*(kR^2)*(eps1/eps2)*...
%             (f4(kR,k)*(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
%             *(eps1*mu1-eps2*mu2)-...
%             2*mu1*k2z(kR,k)*f1(kR,k)*...
%             (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
%             (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
%             *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
%     end

function C2val=C2(kR,k,t)
    C2val=-2*(kR^2)*(eps1/eps2)*...
        (f4(kR,k)*(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
       *(eps1*mu1-eps2*mu2)-...
    2*mu1*k2z(kR,k)*f1(kR,k)*...
     (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
         (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
%NOOOOTEEE this has a minus sign at the beggining cause there is
        %soemthing wrong and it may be that.!!!!!!!!
end


% 
%     function C3val=C3(kR,k,t)
%         C3val=2*(kR^2)*(eps1/eps2)*...
%             (f3(kR,k)*(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
%             *(eps1*mu1-eps2*mu2)*exp(2*1i*k2z(kR,k)*t)+...
%             2*mu1*k2z(kR,k)*f2(kR,k)*...
%             (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
%             (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
%             *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
%     end

function C3val=C3(kR,k,t)
    C3val=-2*(kR^2)*(eps1/eps2)*...
        (f3(kR,k)*(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
       *(eps1*mu1-eps2*mu2)*exp(2*1i*k2z(kR,k)*t)+...
    2*mu1*k2z(kR,k)*f2(kR,k)*...
     (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
         (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
     %NOOOOTEEE this has a minus sign at the beggining cause there is
        %soemthing wrong and it may be that.!!!!!!!!
end



function f1val=f1(kR,k)
f1val=eps2*k1z(kR,k)-eps1*k2z(kR,k);
%checked
end

function f2val=f2(kR,k)
f2val=eps2*k1z(kR,k)+eps1*k2z(kR,k);
%checked
end

function f3val=f3(kR,k)
f3val=eps3*k2z(kR,k)-eps2*k3z(kR,k);
%checked
end

function f4val=f4(kR,k)
f4val=eps3*k2z(kR,k)+eps2*k3z(kR,k);
%checked
end

function g1val=g1(kR,k)
g1val=mu2*k1z(kR,k)-mu1*k2z(kR,k);
%checked
end
function g2val=g2(kR,k)
g2val=mu2*k1z(kR,k)+mu1*k2z(kR,k);
%checked
end
function g3val=g3(kR,k)
g3val=mu3*k2z(kR,k)-mu2*k3z(kR,k);
%checked
end
function g4val=g4(kR,k)
g4val=mu3*k2z(kR,k)+mu2*k3z(kR,k);
%checked
end


end