function Vectorfunctionsregion3=Green3regionIntegrand(kR,k,h,z,R,phi,struct,t,J0,J1)
numpoints=size(R,1);
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

Vectorfunctionsregion3=[Gv3R(kR,k,h,z,R,phi,struct,t),Gv3z(kR,k,h,z,R,phi,struct,t),Gh3R(kR,k,h,z,R,phi,struct,t),Gh3phi(kR,k,h,z,R,phi,struct,t),Gh3Z(kR,k,h,z,R,phi,struct,t)];


%Here we write the functions for vertical and horizontal dipoles but
%without the angle dependence so that we can use on single integral for
%both Gxi and Gyi components.

function gv3r=Gv3R(kR,k,h,z,~,~,~,t)
gv3r=(1i*exp(1i*(h.*k1z(kR,k)-z.*k3z(kR,k))).*J1.*kR*A4(kR,k,t).*k3z(kR,k))./(4*eps1*k^2*mu1*pi);
end
function gv3z=Gv3z(kR,k,h,z,~,~,~,t)
gv3z=(exp(1i*(h.*k1z(kR,k)-z.*k3z(kR,k))).*J0.*kR^2*A4(kR,k,t))./(4*eps1*k^2*mu1*pi);
end

function gh3r=Gh3R(kR,k,h,z,R,~,~,t)
gh3r=zeros(numpoints,1);
cond=logical(k*R<=(10^-10));  


gh3r(cond)=(exp(1i*(h(cond).*k1z(kR,k)-z(cond).*k3z(kR,k))).*(...
    J0(cond).*k3z(kR,k).*((-1i)*kR*C4(kR,k,t)+B4(kR,k,t)*k3z(kR,k))./(4*eps1*k^2*mu1*pi)...
    +(kR/2).*(kR*B4(kR,k,t)+1i*C4(kR,k,t)*k3z(kR,k))./(4*eps1*k^2*mu1*pi)...
    ));

gh3r(not(cond))=(exp(1i*(h(not(cond)).*k1z(kR,k)-z(not(cond)).*k3z(kR,k))).*(J0(not(cond)).*R(not(cond)).*k3z(kR,k).*...
    ((-1i)*kR*C4(kR,k,t)+B4(kR,k,t)*k3z(kR,k))+J1(not(cond)).*(kR*B4(kR,k,t)+...
    1i*C4(kR,k,t)*k3z(kR,k))))./(4*eps1*k^2*mu1*pi*R(not(cond)));
% gh3r=(exp(1i*(h.*k1z(kR,k)-z.*k3z(kR,k))).*(J0.*R.*k3z(kR,k).*...
%     ((-1i)*kR*C4(kR,k,t)+B4(kR,k,t)*k3z(kR,k))+J1.*(kR*B4(kR,k,t)+...
%     1i*C4(kR,k,t)*k3z(kR,k))))./(4*eps1*k^2*mu1*pi*R);

%Note that this function already doesn't have the cos(phi) dependence which
%we plug after the integration!!!!
end

function gh3phi=Gh3phi(kR,k,h,z,R,~,~,t)
gh3phi=zeros(numpoints,1);
cond=logical(k*R<=(10^-10));  
    
gh3phi(cond)=-((exp(1i*(h(cond).*k1z(kR,k)-z(cond).*k3z(kR,k))).*...
    (J0(cond).*eps3*mu3*k^2.*B4(kR,k,t)./(4*eps1*k^2*mu1*pi)...
    -(kR/2).*(kR*B4(kR,k,t)+1i*C4(kR,k,t)*k3z(kR,k))./(4*eps1*k^2*mu1*pi)...
    )));

gh3phi(not(cond))=-((exp(1i*(h(not(cond)).*k1z(kR,k)-z(not(cond)).*k3z(kR,k))).*...
    (J0(not(cond)).*eps3*mu3*k^2.*R(not(cond)).*B4(kR,k,t)-J1(not(cond)).*(kR*B4(kR,k,t)+1i*C4(kR,k,t)*k3z(kR,k))))./...
    (4*eps1*k^2*mu1*pi.*R(not(cond))));


% gh3phi=-((exp(1i*(h.*k1z(kR,k)-z.*k3z(kR,k))).*...
%     (J0.*eps3*mu3*k^2.*R.*B4(kR,k,t)-J1.*(kR*B4(kR,k,t)+1i*C4(kR,k,t)*k3z(kR,k))))./...
%     (4*eps1*k^2*mu1*pi.*R));
%Note that this function already doesn't have the sin(phi) dependence which
%we plug after the integration!!!!
end


function gh3z=Gh3Z(kR,k,h,z,~,~,~,t)
    
 gh3z=(exp(1i*(h.*k1z(kR,k)-z.*k3z(kR,k))).*J1.*kR*(kR*C4(kR,k,t)+...
     1i*B4(kR,k,t)*k3z(kR,k)))./(4*eps1*k^2*mu1*pi);   
%Note that this function already doesn't have the cos(phi) dependence which
%we plug after the integration!!!!
end

function k1zval=k1z(kR,k)
    tempk1z=sqrt(eps1*mu1*k^2-kR^2);
    if abs(imag(tempk1z))<10^-6
        k1zval=tempk1z;
    else
        k1zval=tempk1z*sign(imag(tempk1z));
    end
end

function k2zval=k2z(kR,k)
 tempk2z=sqrt(eps2*mu2*k^2-kR^2);
    if abs(imag(tempk2z))<10^-6
        k2zval=tempk2z;
    else
        k2zval=tempk2z*sign(imag(tempk2z));
    end
end

function k3zval=k3z(kR,k)
 tempk3z=sqrt(eps3*mu3*k^2-kR^2);
    if abs(imag(tempk3z))<10^-6
        k3zval=tempk3z;
    else
        k3zval=tempk3z*sign(imag(tempk3z));
    end
end


function A4val=A4(kR,k,t)
A4val=1i*((4*eps1*eps2*kR*k2z(kR,k)*exp(1i*(k2z(kR,k)-k3z(kR,k))*t)))...
        /(((f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t))));
end


function B4val=B4(kR,k,t)
 B4val=1i*(eps1/eps3)*(4*mu1*mu2*kR*k2z(kR,k)*exp(1i*(k2z(kR,k)-k3z(kR,k))*t))...
        /(g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t));   
end

 
% function C4val=C4(kR,k,t)
%     C4val=4*(kR^2)*k2z(kR,k)*(eps1/eps3)*exp(1i*(k2z(kR,k)-k3z(kR,k))*t)*...
%         (eps3*(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
%        *(eps1*mu1-eps2*mu2)+...
%     mu1*(f2(kR,k)-f1(kR,k)*exp(2*1i*k2z(kR,k)*t))*...
%      (eps2*mu2-eps3*mu3))./...
%          (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
%         *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
% end    

 
function C4val=C4(kR,k,t)
    C4val=-4*(kR^2)*k2z(kR,k)*(eps1/eps3)*exp(1i*(k2z(kR,k)-k3z(kR,k))*t)*...
        (eps3*(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
       *(eps1*mu1-eps2*mu2)+...
    mu1*(f2(kR,k)-f1(kR,k)*exp(2*1i*k2z(kR,k)*t))*...
     (eps2*mu2-eps3*mu3))./...
         (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
    %Note the minus sign here...it really gets into my nerves!
end    




function f1val=f1(kR,k)
f1val=eps2*k1z(kR,k)-eps1*k2z(kR,k);
%checked
end

function f2val=f2(kR,k)
f2val=eps2*k1z(kR,k)+eps1*k2z(kR,k);
%checked
end

function f3val=f3(kR,k)
f3val=eps3*k2z(kR,k)-eps2*k3z(kR,k);
%checked
end

function f4val=f4(kR,k)
f4val=eps3*k2z(kR,k)+eps2*k3z(kR,k);
%checked
end

function g1val=g1(kR,k)
g1val=mu2*k1z(kR,k)-mu1*k2z(kR,k);
%checked
end
function g2val=g2(kR,k)
g2val=mu2*k1z(kR,k)+mu1*k2z(kR,k);
%checked
end
function g3val=g3(kR,k)
g3val=mu3*k2z(kR,k)-mu2*k3z(kR,k);
%checked
end
function g4val=g4(kR,k)
g4val=mu3*k2z(kR,k)+mu2*k3z(kR,k);
%checked
end


end