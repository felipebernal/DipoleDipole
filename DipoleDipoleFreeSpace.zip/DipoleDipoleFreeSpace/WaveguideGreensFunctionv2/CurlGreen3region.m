function CurlGreenregion3Dyad=CurlGreen3region(k,h,z,R,phi,struct,t)
if size(R,1)==0
CurlGreenregion3Dyad=zeros(3,3,0);
else
CurlGreenregion3Dyad=CurlGreenIntegrator(k,h,z,R,phi,struct,t,@CurlGreen3regionIntegrand,3);
end
