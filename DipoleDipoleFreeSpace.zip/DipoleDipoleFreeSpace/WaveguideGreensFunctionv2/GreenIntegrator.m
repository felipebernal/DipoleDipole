function Greenregion1Dyad=GreenIntegrator(k,h,z,R,phi,struct,t,GreenXregionIntegrand,Region)

%First we find the integrals of the cilyndrical functions and from those we
%find the values of the cartesian ones.

%The function GreenXregionIntegrand gives
%[GvXR,GvXz,GhXR/cos(phi),GhXphi/sin(phi),GhXZ/cos(phi)] where X is the
%region where we are integrating.

numpoints=size(R,1);
tol=1e-7;%This is the absolute error tolerance for the integration. 

ratio=1E-3;
nellipse=max(real(sqrt(struct(:,1).*struct(:,2))))*k;
%Here I choose the maximum possible Real K as suggested in Paulus and Martin pg. 19
kmax=(nellipse+k)/2;
kmin=ratio*kmax;
ellipspath        = @(x) kmax*(1-cos(x)) - 1i*kmin*sin(x);
ellipspathvelocity=@(x) kmax*sin(x)  - 1i*kmin*cos(x);

funEllipCon = @(x) ellipspathvelocity(x)*GreenXregionIntegrand(ellipspath(x),k,h,z,R,phi,...
    struct,t,besselj(0, ellipspath(x)*R),besselj(1, ellipspath(x)*R));

cylindricFunction1StPart=quadv(funEllipCon,0,pi,tol);



cylindricFunction2NDPart=zeros(numpoints,5);
Rmin=k*min(R);
Zmin=k*(10^-3);
%INFINITY=30/sqrt(Rmin^2+Zmin^2);


n1=real(sqrt(struct(1,1)*struct(1,2)));
n2=real(sqrt(struct(2,1)*struct(2,2)));
n3=real(sqrt(struct(3,1)*struct(3,2)));

if Region==1
    INFINITY=100000*n1*sqrt(k);%%%%%NOTEEE THIS 40!!! I don't know which general condition for infinity to take!!
elseif Region==2
    INFINITY=10*n2*sqrt(k);
elseif Region==3
    INFINITY=100*n3*sqrt(k);
end
    kstart=real(ellipspath(pi));
    
    %These two are the conditions for when to use the bessel functions and when
    %to use the Hankel functions.
    
    %Original
    condz=logical(abs(k*(z-h))>=10^(0)|k*R<=10^-2);
    condzmin=logical(abs(k*(z-h))<10^(0)& k*R>10^-2);
    
    %CHECKERS
    %condz=logical(abs(k*(z-h))>10^(-10));
    %condzmin=logical(abs(k*(z-h))<10^(-10));
    
    %This if is only a way to avoid porblems in case conz or condzmin are zro
    %vectors.
    
  
    if Region==1
        if size(R(condz),1)>0
            funRealAxes = @(x) GreenXregionIntegrand(x,k,h(condz),z(condz),R(condz)...
                ,phi(condz), struct,t,besselj(0,x*R(condz)),besselj(1,x*R(condz)));
            
            funrealchangevariable= @(u) funRealAxes((1-(1/u))).*(1/(u.^2));
            
            %    cylindricFunction2NDPart(condz,:)=quadv(funRealAxes,kstart,INFINITY,tol);
            cylindricFunction2NDPart(condz,:)=quadv(funrealchangevariable,1/(1-kstart),0,tol);
        end
    elseif Region==2
        if size(R(condz),1)>0
            funRealAxes = @(x) GreenXregionIntegrand(x,k,h(condz),z(condz),R(condz)...
                ,phi(condz), struct,t,besselj(0,x*R(condz)),besselj(1,x*R(condz)));
            
            %funrealchangevariable= @(u) funRealAxes((1-(1/u))).*(1/(u.^2));
            
            cylindricFunction2NDPart(condz,:)=quadv(funRealAxes,kstart,INFINITY,tol);
            %cylindricFunction2NDPart(condz,:)=quadv(funrealchangevariable,1/(1-kstart),0,tol);
        end
        
    elseif Region==3
        if size(R(condz),1)>0
            funRealAxes = @(x) GreenXregionIntegrand(x,k,h(condz),z(condz),R(condz)...
                ,phi(condz), struct,t,besselj(0,x*R(condz)),besselj(1,x*R(condz)));
            funrealchangevariable= @(u) funRealAxes((1-(1/u))).*(1/(u.^2));
            %cylindricFunction2NDPart(condz,:)=quadv(funRealAxes,kstart,INFINITY,tol);
            cylindricFunction2NDPart(condz,:)=quadv(funrealchangevariable,1/(1-kstart),0,tol);
        end
    end
    
    
    % funNegComplAxes = @(x) -1i* GreenXregionIntegrand(kstart-1i*x,k,h(condzmin),z(condzmin),R(condzmin)...
    %     ,phi(condzmin), struct,t,0.5*besselh(0,2,(kstart-1i*x)*R(condzmin)),0.5*besselh(1,2,(kstart-1i*x)*R(condzmin)));
    % funPosComplAxes = @(x)  1i* GreenXregionIntegrand((kstart+1i*x),k,h(condzmin),z(condzmin),R(condzmin)...
    %     ,phi(condzmin), struct,t,0.5*besselh(0,1,(kstart+1i*x)*R(condzmin)),0.5*besselh(1,1,(kstart+1i*x)*R(condzmin)));
    
    if size(R(condzmin),1)>0
        funNegANDPosComplAxes=@(x) -1i* GreenXregionIntegrand(kstart-1i*x,k,h(condzmin),z(condzmin),R(condzmin)...
            ,phi(condzmin), struct,t,0.5*besselh(0,2,(kstart-1i*x)*R(condzmin)),0.5*besselh(1,2,(kstart-1i*x)*R(condzmin)))+...
            1i* GreenXregionIntegrand((kstart+1i*x),k,h(condzmin),z(condzmin),R(condzmin)...
            ,phi(condzmin), struct,t,0.5*besselh(0,1,(kstart+1i*x)*R(condzmin)),0.5*besselh(1,1,(kstart+1i*x)*R(condzmin)));
        %funNPCOMPLEXchangevariable= @(u) funNegANDPosComplAxes((1-(1/u))).*(1/(u.^2));
        %cylindricFunction2NDPart(condzmin,:)=quadv(funNegComplAxes + funPosComplAxes,0,INFINITY,tol);
        cylindricFunction2NDPart(condzmin,:)=quadv(funNegANDPosComplAxes,0,INFINITY,tol);
        
        %cylindricFunction2NDPart(condzmin,:)=quadv(funNPCOMPLEXchangevariable,1,0,tol);
  
        
    end
    



TotalInt=cylindricFunction1StPart+cylindricFunction2NDPart;
%The function TotalInt gives the integrated [Gv1R,Gv1z,Gh1R/cos(phi),Gh1phi/sin(phi),Gh1Z/cos(phi)]
Greenregion1Dyad=zeros(3,3,numpoints);


Greenregion1Dyad(1,1,:)=(cos(phi).^2).*TotalInt(:,3)-(sin(phi).^2).*TotalInt(:,4);%Gxx
Greenregion1Dyad(2,1,:)=(cos(phi).*sin(phi)).*(TotalInt(:,3)+TotalInt(:,4));%Gxy
Greenregion1Dyad(3,1,:)=cos(phi).*TotalInt(:,5);%Gxz
Greenregion1Dyad(1,2,:)=Greenregion1Dyad(2,1,:);%Gyx
Greenregion1Dyad(2,2,:)=(sin(phi).^2).*TotalInt(:,3)-(cos(phi).^2).*TotalInt(:,4)  ;%Gyy
Greenregion1Dyad(3,2,:)=sin(phi).*TotalInt(:,5);%Gyz
Greenregion1Dyad(1,3,:)=cos(phi).*TotalInt(:,1);%Gzx
Greenregion1Dyad(2,3,:)=sin(phi).*TotalInt(:,1);%Gzy
Greenregion1Dyad(3,3,:)=TotalInt(:,2);%Gzz


end