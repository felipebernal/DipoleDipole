function Greenregion3Dyad=Green3region(k,h,z,R,phi,struct,t)
if size(R,1)==0
Greenregion3Dyad=zeros(3,3,0);
else
Greenregion3Dyad=GreenIntegrator(k,h,z,R,phi,struct,t,@Green3regionIntegrand,3);
end
