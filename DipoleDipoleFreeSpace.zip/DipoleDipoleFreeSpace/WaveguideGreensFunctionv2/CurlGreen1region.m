function CurlGreenregion1Dyad=CurlGreen1region(k,h,z,R,phi,struct,t)
if size(R,1)==0
CurlGreenregion1Dyad=zeros(3,3,0);
else
CurlGreenregion1Dyad=CurlGreenIntegrator(k,h,z,R,phi,struct,t,@CurlGreen1regionIntegrand,1);
end
