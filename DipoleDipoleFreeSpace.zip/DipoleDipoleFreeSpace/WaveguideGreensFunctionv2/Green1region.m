function Greenregion1Dyad=Green1region(k,h,z,R,phi,struct,t)
if size(R,1)==0
Greenregion1Dyad=zeros(3,3,0);
else
Greenregion1Dyad=GreenIntegrator(k,h,z,R,phi,struct,t,@Green1regionIntegrand,1);
end
