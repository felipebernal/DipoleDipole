function Vectorfunctionsregion2=CurlGreen2regionIntegrand(kR,k,h,z,R,phi,struct,t,J0,J1)
numpoints=size(R,1);
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

Vectorfunctionsregion2=[CGv2phi(kR,k,h,z,R,phi,struct,t),CGh2R(kR,k,h,z,R,phi,struct,t),CGh2phi(kR,k,h,z,R,phi,struct,t),CGh2Z(kR,k,h,z,R,phi,struct,t)];

%Here we write the functions for vertical and horizontal dipoles but
%without the angle dependence so that we can use on single integral for
%both Gxi and Gyi components.

function Cgv2phi=CGv2phi(kR,k,h,z,~,~,~,t)
Cgv2phi=(exp(1i*(h*k1z(kR,k)-z.*k2z(kR,k))).*eps2.*J1.*kR*mu2.*(A2(kR,k,t)+exp(2*1i*z.*k2z(kR,k))*A3(kR,k,t)))./(4*eps1*mu1*pi);
%Note that this function already doesn't have the sin(phi) dependence which
%we plug after the integration!!!!
end


function Cgh2r=CGh2R(kR,k,h,z,R,~,~,t)
Cgh2r=zeros(numpoints,1);
cond=logical(k*R<=(10^-10));    
   
Cgh2r(cond)=(1i*exp(1i*(h(cond).*k1z(kR,k)-z(cond).*k2z(kR,k))).*eps2*mu2.*(...
1i*(kR/2).*(C2(kR,k,t)+exp(2*1i*z(cond).*k2z(kR,k)).*C3(kR,k,t))./(4*eps1*mu1*pi)...
    -J0(cond).*(B2(kR,k,t)-exp(2*1i.*z(cond).*k2z(kR,k)).*B3(kR,k,t)).*k2z(kR,k)./(4*eps1*mu1*pi)...
    ));

Cgh2r(not(cond))=(1i*exp(1i*(h(not(cond)).*k1z(kR,k)-z(not(cond)).*k2z(kR,k))).*eps2*mu2.*(1i*J1(not(cond)).*(C2(kR,k,t)...
    +exp(2*1i*z(not(cond)).*k2z(kR,k)).*C3(kR,k,t))-J0(not(cond)).*R(not(cond)).*(B2(kR,k,t)-...
    exp(2*1i.*z(not(cond)).*k2z(kR,k)).*B3(kR,k,t)).*k2z(kR,k)))./(4*eps1*mu1*pi*R(not(cond)));

% Cgh2r=(1i*exp(1i*(h.*k1z(kR,k)-z.*k2z(kR,k))).*eps2*mu2.*(1i*J1.*(C2(kR,k,t)...
%     +exp(2*1i*z.*k2z(kR,k)).*C3(kR,k,t))-J0.*R.*(B2(kR,k,t)-...
%     exp(2*1i.*z.*k2z(kR,k)).*B3(kR,k,t)).*k2z(kR,k)))./(4*eps1*mu1*pi*R);
%Note that this function already doesn't have the sin(phi) dependence which
%we plug after the integration!!!!
end

function Cgh2phi=CGh2phi(kR,k,h,z,R,~,~,t)
Cgh2phi=zeros(numpoints,1);
cond=logical(k*R<=(10^-10));      

Cgh2phi(cond)=(exp(1i*(h(cond).*k1z(kR,k)-z(cond).*k2z(kR,k))).*eps2*mu2.*(...
    (kR/2).*(C2(kR,k,t)+exp(2*1i*z(cond).*k2z(kR,k)).*C3(kR,k,t))./(4*eps1*mu1*pi)-...
    1i*J0(cond).*((-1i)*kR*C2(kR,k,t)+B2(kR,k,t)*k2z(kR,k)-exp(2*1i*z(cond).*k2z(kR,k)).*(1i*kR*C3(kR,k,t)+B3(kR,k,t).*k2z(kR,k)))./(4*eps1*mu1*pi)...
    ));

Cgh2phi(not(cond))=(exp(1i*(h(not(cond)).*k1z(kR,k)-z(not(cond)).*k2z(kR,k))).*eps2*mu2.*(J1(not(cond)).*(C2(kR,k,t)+exp(2*1i*z(not(cond)).*k2z(kR,k)).*C3(kR,k,t))-...
    1i*J0(not(cond)).*R(not(cond)).*((-1i)*kR*C2(kR,k,t)+B2(kR,k,t)*k2z(kR,k)-exp(2*1i*z(not(cond)).*k2z(kR,k)).*(1i*kR*C3(kR,k,t)+B3(kR,k,t).*k2z(kR,k)))))./(4*eps1*mu1*pi.*R(not(cond)));

% 
% Cgh2phi=(exp(1i*(h.*k1z(kR,k)-z.*k2z(kR,k))).*eps2*mu2.*(J1.*(C2(kR,k,t)+exp(2*1i*z.*k2z(kR,k)).*C3(kR,k,t))-...
%     1i*J0.*R.*((-1i)*kR*C2(kR,k,t)+B2(kR,k,t)*k2z(kR,k)-exp(2*1i*z.*k2z(kR,k)).*(1i*kR*C3(kR,k,t)+B3(kR,k,t).*k2z(kR,k)))))./(4*eps1*mu1*pi.*R);

%Note that this function already doesn't have the Cos(phi) dependence which
%we plug after the integration!!!!
end

function Cgh2pz=CGh2Z(kR,k,h,z,~,~,~,t)
Cgh2pz=(exp(1i*(h.*k1z(kR,k)-z.*k2z(kR,k))).*eps2.*J1.*kR*mu2.*(B2(kR,k,t)+exp(2*1i*z.*k2z(kR,k)).*B3(kR,k,t)))./(4*eps1*mu1*pi);
%Note that this function already doesn't have the Sin(phi) dependence which
%we plug after the integration!!!!
end

function k1zval=k1z(kR,k)
    tempk1z=sqrt(eps1*mu1*k^2-kR^2);
    if abs(imag(tempk1z))<10^-6
        k1zval=tempk1z;
    else
        k1zval=tempk1z*sign(imag(tempk1z));
    end
end

function k2zval=k2z(kR,k)
 tempk2z=sqrt(eps2*mu2*k^2-kR^2);
    if abs(imag(tempk2z))<10^-6
        k2zval=tempk2z;
    else
        k2zval=tempk2z*sign(imag(tempk2z));
    end
end

function k3zval=k3z(kR,k)
 tempk3z=sqrt(eps3*mu3*k^2-kR^2);
    if abs(imag(tempk3z))<10^-6
        k3zval=tempk3z;
    else
        k3zval=tempk3z*sign(imag(tempk3z));
    end
end



function A2val=A2(kR,k,t)
    A2val=1i*((2*eps1*kR*f4(kR,k)))...
        /(((f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t))));
end

function A3val=A3(kR,k,t)
    A3val=1i*((2*eps1*kR*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        /(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t));
end


function B2val=B2(kR,k,t)
 B2val=1i*(eps1/eps2)*(2*mu1*kR*g4(kR,k))...
        /(g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t));   
end

function B3val=B3(kR,k,t)
 B3val=1i*(eps1/eps2)*(2*mu1*kR*g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
        /(g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t));   
end

% 
%     function C2val=C2(kR,k,t)
%         C2val=2*(kR^2)*(eps1/eps2)*...
%             (f4(kR,k)*(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
%             *(eps1*mu1-eps2*mu2)-...
%             2*mu1*k2z(kR,k)*f1(kR,k)*...
%             (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
%             (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
%             *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
%     end

function C2val=C2(kR,k,t)
    C2val=-2*(kR^2)*(eps1/eps2)*...
        (f4(kR,k)*(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
       *(eps1*mu1-eps2*mu2)-...
    2*mu1*k2z(kR,k)*f1(kR,k)*...
     (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
         (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
%NOOOOTEEE this has a minus sign at the beggining cause there is
        %soemthing wrong and it may be that.!!!!!!!!
end


% 
%     function C3val=C3(kR,k,t)
%         C3val=2*(kR^2)*(eps1/eps2)*...
%             (f3(kR,k)*(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
%             *(eps1*mu1-eps2*mu2)*exp(2*1i*k2z(kR,k)*t)+...
%             2*mu1*k2z(kR,k)*f2(kR,k)*...
%             (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
%             (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
%             *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
%     end

function C3val=C3(kR,k,t)
    C3val=-2*(kR^2)*(eps1/eps2)*...
        (f3(kR,k)*(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
       *(eps1*mu1-eps2*mu2)*exp(2*1i*k2z(kR,k)*t)+...
    2*mu1*k2z(kR,k)*f2(kR,k)*...
     (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
         (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
     %NOOOOTEEE this has a minus sign at the beggining cause there is
        %soemthing wrong and it may be that.!!!!!!!!
end



function f1val=f1(kR,k)
f1val=eps2*k1z(kR,k)-eps1*k2z(kR,k);
%checked
end

function f2val=f2(kR,k)
f2val=eps2*k1z(kR,k)+eps1*k2z(kR,k);
%checked
end

function f3val=f3(kR,k)
f3val=eps3*k2z(kR,k)-eps2*k3z(kR,k);
%checked
end

function f4val=f4(kR,k)
f4val=eps3*k2z(kR,k)+eps2*k3z(kR,k);
%checked
end

function g1val=g1(kR,k)
g1val=mu2*k1z(kR,k)-mu1*k2z(kR,k);
%checked
end
function g2val=g2(kR,k)
g2val=mu2*k1z(kR,k)+mu1*k2z(kR,k);
%checked
end
function g3val=g3(kR,k)
g3val=mu3*k2z(kR,k)-mu2*k3z(kR,k);
%checked
end
function g4val=g4(kR,k)
g4val=mu3*k2z(kR,k)+mu2*k3z(kR,k);
%checked
end


end