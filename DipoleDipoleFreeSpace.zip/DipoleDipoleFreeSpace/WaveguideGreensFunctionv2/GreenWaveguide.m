function GreenDyad=GreenWaveguide(k,rdetect,rsource,struct,t)

%This function only gives the reflected and transmited part of the green's
%function ommiting the free part.
%struct contains the permitivities and permeavilities of the layered
%e.g. structure [[eps1;eps2;eps3],[mu1;mu2;mu3]]
%

rvec=rdetect-rsource;
R=sqrt(rvec(:,1).^2+rvec(:,2).^2);
z=rdetect(:,3);
h=rsource(:,3);
phi=atan2(rvec(:,2),rvec(:,1));


numpoints=size(rdetect,1);

GreenDyad=zeros(3,3,numpoints);

cond1=logical(rdetect(:,3)>=0);
cond2=logical(rdetect(:,3)<0 & (rdetect(:,3)+t) >=0 );
cond3=logical((rdetect(:,3)+t) <0 );

GreenDyad(:,:,cond1)=Green1region(k,h(cond1),z(cond1),R(cond1),phi(cond1),struct,t);
GreenDyad(:,:,cond2)=Green2region(k,h(cond2),z(cond2),R(cond2),phi(cond2),struct,t);
GreenDyad(:,:,cond3)=Green3region(k,h(cond3),z(cond3),R(cond3),phi(cond3),struct,t);




