function TotalInt=GreenIntegratorCilyndrical(k,h,z,R,phi,struct,t,GreenXregionIntegrand)

%First we find the integrals of the cilyndrical functions and from those we
%find the values of the cartesian ones.

%The function GreenXregionIntegrand gives
%[GvXR,GvXz,GhXR/cos(phi),GhXphi/sin(phi),GhXZ/cos(phi)] where X is the
%region where we are integrating.

numpoints=size(R,1);
tol=1e-7;%This is the absolute error tolerance for the integration. 

ratio=1E-3;
nellipse=max(real(sqrt(struct(:,1).*struct(:,2))))*k;
%Here I choose the maximum possible Real K as suggested in Paulus and Martin pg. 19
kmax=(nellipse+k)/2;
kmin=ratio*kmax;
ellipspath        = @(x) kmax*(1-cos(x)) - 1i*kmin*sin(x);
ellipspathvelocity=@(x) kmax*sin(x)  - 1i*kmin*cos(x);

funEllipCon = @(x) ellipspathvelocity(x)*GreenXregionIntegrand(ellipspath(x),k,h,z,R,phi,...
    struct,t,besselj(0, ellipspath(x)*R),besselj(1, ellipspath(x)*R));

cylindricFunction1StPart=quadv(funEllipCon,0,pi,tol);



cylindricFunction2NDPart=zeros(numpoints,5);
Rmin=k*min(R);
Zmin=k*(10^-3);
%INFINITY=30/sqrt(Rmin^2+Zmin^2);
INFINITY=40*k;
kstart=real(ellipspath(pi));


condz=logical(abs(k*(z-h))>=10^(-1));
condzmin=logical(abs(k*(z-h))<10^(-1));
if size(R(condz),1)>0
funRealAxes = @(x) GreenXregionIntegrand(x,k,h(condz),z(condz),R(condz)...
    ,phi(condz), struct,t,besselj(0,x*R(condz)),besselj(1,x*R(condz)));

cylindricFunction2NDPart(condz,:)=quadv(funRealAxes,kstart,INFINITY,tol);
end

% funNegComplAxes = @(x) -1i* GreenXregionIntegrand(kstart-1i*x,k,h(condzmin),z(condzmin),R(condzmin)...
%     ,phi(condzmin), struct,t,0.5*besselh(0,2,(kstart-1i*x)*R(condzmin)),0.5*besselh(1,2,(kstart-1i*x)*R(condzmin)));
% funPosComplAxes = @(x)  1i* GreenXregionIntegrand((kstart+1i*x),k,h(condzmin),z(condzmin),R(condzmin)...
%     ,phi(condzmin), struct,t,0.5*besselh(0,1,(kstart+1i*x)*R(condzmin)),0.5*besselh(1,1,(kstart+1i*x)*R(condzmin)));

if size(R(condzmin),1)>0
funNegANDPosComplAxes=@(x) -1i* GreenXregionIntegrand(kstart-1i*x,k,h(condzmin),z(condzmin),R(condzmin)...
    ,phi(condzmin), struct,t,0.5*besselh(0,2,(kstart-1i*x)*R(condzmin)),0.5*besselh(1,2,(kstart-1i*x)*R(condzmin)))+... 
    1i* GreenXregionIntegrand((kstart+1i*x),k,h(condzmin),z(condzmin),R(condzmin)...
    ,phi(condzmin), struct,t,0.5*besselh(0,1,(kstart+1i*x)*R(condzmin)),0.5*besselh(1,1,(kstart+1i*x)*R(condzmin)));

%cylindricFunction2NDPart(condzmin,:)=quadv(funNegComplAxes + funPosComplAxes,0,INFINITY,tol);
cylindricFunction2NDPart(condzmin,:)=quadv(funNegANDPosComplAxes ,0,INFINITY,tol);
end    


TotalInt=cylindricFunction1StPart+cylindricFunction2NDPart;
%The function TotalInt gives the integrated [Gv1R,Gv1z,Gh1R/cos(phi),Gh1phi/sin(phi),Gh1Z/cos(phi)]





end