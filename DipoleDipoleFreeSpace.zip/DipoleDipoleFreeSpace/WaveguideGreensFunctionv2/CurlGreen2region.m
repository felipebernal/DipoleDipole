function CurlGreenregion2Dyad=CurlGreen2region(k,h,z,R,phi,struct,t)
if size(R,1)==0
CurlGreenregion2Dyad=zeros(3,3,0);
else
CurlGreenregion2Dyad=CurlGreenIntegrator(k,h,z,R,phi,struct,t,@CurlGreen2regionIntegrand,2);
end
