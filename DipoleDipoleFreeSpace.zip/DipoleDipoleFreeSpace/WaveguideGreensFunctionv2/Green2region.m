function Greenregion2Dyad=Green2region(k,h,z,R,phi,struct,t)
if size(R,1)==0
Greenregion2Dyad=zeros(3,3,0);
else
Greenregion2Dyad=GreenIntegrator(k,h,z,R,phi,struct,t,@Green2regionIntegrand,2);
end
