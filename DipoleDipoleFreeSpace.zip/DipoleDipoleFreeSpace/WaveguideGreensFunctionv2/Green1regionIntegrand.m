function Vectorfunctionsregion1=Green1regionIntegrand(kR,k,h,z,R,phi,struct,t,J0,J1)

numpoints=size(R,1);
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

Vectorfunctionsregion1=[Gv1R(kR,k,h,z,R,phi,struct,t),Gv1z(kR,k,h,z,R,phi,struct,t),Gh1R(kR,k,h,z,R,phi,struct,t),Gh1phi(kR,k,h,z,R,phi,struct,t),Gh1Z(kR,k,h,z,R,phi,struct,t)];


%Here we write the functions for vertical and horizontal dipoles but
%without the angle dependence so that we can use on single integral for
%both Gxi and Gyi components.

function gv1r=Gv1R(kR,k,h,z,~,~,~,t)
gv1r=-((1i*exp(1i*(h + z)*k1z(kR,k))*kR*A1(kR,k,t).*J1*k1z(kR,k))...
./(4*eps1*k^2*mu1*pi));
%CHECKED
end
function gv1z=Gv1z(kR,k,h,z,~,~,~,t)
gv1z=(exp(1i*(h+z)*k1z(kR,k)).*kR^2*A1(kR,k,t).*J0)./(4*eps1*k^2*mu1*pi);
%CHECKED
end

function gh1r=Gh1R(kR,k,h,z,R,~,~,t)
    
%This funciton looks ugly just because we needed a vectorized if for when R
%was too small and then put the limit of the function in it....and so here
%you are!!
gh1r=zeros(numpoints,1);
cond=logical(k*R<=(10^-10));    
    
gh1r(cond)=...
    exp(1i*(h(cond)+z(cond))*k1z(kR,k)).*(...
    J0(cond)*k1z(kR,k)*(1i*kR*C1(kR,k,t)+B1(kR,k,t)*k1z(kR,k))./(4*eps1*k^2*mu1*pi)...
    +(kR/2).*(kR*B1(kR,k,t)-1i*C1(kR,k,t)*k1z(kR,k))./(4*eps1*k^2*mu1*pi));%Here we use the limit R->0 of J1(kR R)/R=kR/2
gh1r(not(cond))=(exp(1i*(h(not(cond))+z(not(cond)))*k1z(kR,k)).*(R(not(cond)).*J0(not(cond))*k1z(kR,k)...
   *(1i*kR*C1(kR,k,t)+B1(kR,k,t)*k1z(kR,k))+J1(not(cond)).*(kR*B1(kR,k,t)-1i*C1(kR,k,t)...
   *k1z(kR,k))))./(4*eps1*k^2*mu1*pi*R(not(cond)));
% 
% 
% gh1r=(exp(1i*(h+z)*k1z(kR,k)).*(R.*J0*k1z(kR,k)...
%    *(1i*kR*C1(kR,k,t)+B1(kR,k,t)*k1z(kR,k))+J1.*(kR*B1(kR,k,t)-1i*C1(kR,k,t)...
%    *k1z(kR,k))))./(4*eps1*k^2*mu1*pi*R);

% Note that this one does not have the Cos[phi] which we add after
%the integration.
%Checked!!
end


function gh1phi=Gh1phi(kR,k,h,z,R,~,~,t)
gh1phi=zeros(numpoints,1);
cond=logical(k*R<=(10^-10));
    
gh1phi(cond)=...
    -exp(1i*(h(cond)+z(cond))*k1z(kR,k)).*...
    (...
    eps1*k^2*mu1.*B1(kR,k,t).*J0(cond)./(4*eps1*k^2*mu1*pi)+...
    (kR/2).*((-kR)*B1(kR,k,t)+1i*C1(kR,k,t).*k1z(kR,k))./(4*eps1*k^2*mu1*pi)...
    )...
    ;
gh1phi(not(cond))=-((exp(1i*(h(not(cond))+z(not(cond)))*...
     k1z(kR,k)).*(eps1*k^2*mu1.*R(not(cond)).*B1(kR,k,t).*J0(not(cond))...
     +J1(not(cond)).*((-kR)*B1(kR,k,t)+1i*C1(kR,k,t).*k1z(kR,k))))...
     ./(4*eps1*k^2*mu1*pi.*R(not(cond))));   
    
    
% gh1phi=-((exp(1i*(h+z)*k1z(kR,k)).*(eps1*k^2*mu1.*R.*B1(kR,k,t).*J0+J1.*...
%     ((-kR)*B1(kR,k,t)+1i*C1(kR,k,t).*k1z(kR,k))))./(4*eps1*k^2*mu1*pi.*R));
% Note that this one does not have the Sin[phi] which we add after
%the integration.
%Checked!!
end

% function gh1pz=Gh1Z(kR,k,h,z,R,phi,struct,t)
% gh1pz=(exp(1i*(h+z)*k1z(kR,k)).*kR*cos(phi).*J1.*(kR*C1(kR,k,t)-1i*B1(kR,k,t).*...
%     k1z(kR,k)))./(4*eps1*k^2*mu1*pi);
% end

function gh1pz=Gh1Z(kR,k,h,z,~,~,~,t)
gh1pz=(exp(1i*(h+z)*k1z(kR,k)).*kR.*J1.*(kR*C1(kR,k,t)-1i*B1(kR,k,t).*...
    k1z(kR,k)))./(4*eps1*k^2*mu1*pi);
end

function k1zval=k1z(kR,k)
    tempk1z=sqrt(eps1*mu1*k^2-kR^2);
    if abs(imag(tempk1z))<10^-6
        k1zval=tempk1z;
    else
        k1zval=tempk1z*sign(imag(tempk1z));
    end
end

function k2zval=k2z(kR,k)
 tempk2z=sqrt(eps2*mu2*k^2-kR^2);
    if abs(imag(tempk2z))<10^-6
        k2zval=tempk2z;
    else
        k2zval=tempk2z*sign(imag(tempk2z));
    end
end

function k3zval=k3z(kR,k)
 tempk3z=sqrt(eps3*mu3*k^2-kR^2);
    if abs(imag(tempk3z))<10^-6
        k3zval=tempk3z;
    else
        k3zval=tempk3z*sign(imag(tempk3z));
    end
end
function A1val=A1(kR,k,t)
    A1val=1i*(kR*(f1(kR,k)*f4(kR,k)+f2(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        /(k1z(kR,k)*((f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t))));
    %checked
end

function B1val=B1(kR,k,t)
 B1val=1i*(kR*(g1(kR,k)*g4(kR,k)+g2(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        /(k1z(kR,k)*((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t))));
    %checked
end

% function C1val=C1(kR,k,t)
%     C1val=2*(kR^2)*...
%         ((f4(kR,k)+f3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
%    *(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
%     *(eps1*mu1-eps2*mu2)+...
%     4*eps1*mu1*(k2z(kR,k)^2)*...
%      (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
%          (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
%         *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
%         %checked But there are differences with the paper when used for a
%         %single layer...there they have one minus too much after the reduction
% end

function C1val=C1(kR,k,t)
    C1val=-2*(kR^2)*...
        ((f4(kR,k)+f3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
   *(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
    *(eps1*mu1-eps2*mu2)+...
    4*eps1*mu1*(k2z(kR,k)^2)*...
     (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
         (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
        %NOOOOTEEE this has a minus sign at the beggining cause there is
        %soemthing wrong and with this it gets just as Femius Green's!!!!!!!!
        %Does Novotny do it on porpouse...??? I am starting to believe
        %so!!!!!!!!!!
end

function f1val=f1(kR,k)
f1val=eps2*k1z(kR,k)-eps1*k2z(kR,k);
%checked
end

function f2val=f2(kR,k)
f2val=eps2*k1z(kR,k)+eps1*k2z(kR,k);
%checked
end

function f3val=f3(kR,k)
f3val=eps3*k2z(kR,k)-eps2*k3z(kR,k);
%checked
end

function f4val=f4(kR,k)
f4val=eps3*k2z(kR,k)+eps2*k3z(kR,k);
%checked
end

function g1val=g1(kR,k)
g1val=mu2*k1z(kR,k)-mu1*k2z(kR,k);
%checked
end
function g2val=g2(kR,k)
g2val=mu2*k1z(kR,k)+mu1*k2z(kR,k);
%checked
end
function g3val=g3(kR,k)
g3val=mu3*k2z(kR,k)-mu2*k3z(kR,k);
%checked
end
function g4val=g4(kR,k)
g4val=mu3*k2z(kR,k)+mu2*k3z(kR,k);
%checked
end


end