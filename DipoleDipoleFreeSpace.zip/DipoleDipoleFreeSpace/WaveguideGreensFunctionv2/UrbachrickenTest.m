function Ffluct=UrbachrickenTest(k,numpoints,n)

hbar=1;
c=1;
eps0=1;
t=0.1*2*pi/k;
w=k*c;
struct=[[1;n^2;1],[1;1;1]];

vecxy=zeros(numpoints+1,1);
vecz=[0:(3.3/numpoints):3.3]';
rdetect=[vecxy,vecxy,vecz];
rsource=rdetect;
Ffluct=1+(c*hbar*k^2/(eps0*pi))*(imag(GreenWaveguide(k,rdetect,rsource,struct,t)))/(hbar*w^3/(6*pi^2*eps0*c^2));


figure(1)
plot(vecz*2/t,squeeze(Ffluct(1,1,:)))
figure(2)
plot(vecz*2/t,squeeze(Ffluct(2,2,:)))
figure(3)
plot(vecz*2/t,squeeze(Ffluct(3,3,:)))

