
function [polarizabilityALL,invSubstrateALL,invFreeSpaceALL,invalphstaticALL,LS,hall]=polarizabilitySubstratecomparison
p = path;
path(p,'..\WaveguideGreensFunctionv2');
p2 = path;
path(p2,'..\DipoleDipoleInteractions');
p3 = path;
path(p3,'..\GreenWaveguideFarField');   


% invalphacomplete=INVPolarizabilityProlate(2*pi/0.7,2*pi/0.8,3.9,0.071,0.071,[0,0,0.1],[[1;4.01;2.127],[1;1;1]],0.1)
% 
% invalphasubstrate=INVPolarizabilitySubstrate(2*pi/0.7,2*pi/0.8,3.9,0.071,0.071,[0,0,0.1],[[1;4.01;2.127],[1;1;1]],0.1)
% 
% invalphastatic=INVPolarizabilityStatic(2*pi/0.7,2*pi/0.8,3.9,0.071,0.071,[0,0,0.1],[[1;4.01;2.127],[1;1;1]],0.1)
% 
% invalphaFreespace=INVPolarizabilityFreeSpace(2*pi/0.7,2*pi/0.8,3.9,0.071,0.071,[0,0,0.1],[[1;4.01;2.127],[1;1;1]],0.1)


%First lets do a comparison of the polarizability depending on the
%wavelength.

%alist=0.071;
%blist=0.071;

alist=0.10;
blist=0.06;
w0list=2*pi/0.52;
gammalist=3.9;
struct=[[1;4.01;2.127],[1;1;1]];
t=0.1;
h=0.1;


Li=0.1;
Lf=1.5;
numL=20;
LS=linspace(Li,Lf,numL);

hmax=0.5;
hmin=0.01;
numh=10;
hall=logspace(log10(hmax),log10(hmin),numh);

invalphstaticALL=zeros(3,3,numL,numh);
invSubstrateALL=zeros(3,3,numL,numh);
invFreeSpaceALL=zeros(3,3,numL,numh);
polarizabilityALL=zeros(3,3,numL,numh);

for conth=1:numh
for conti=1:numL
  h=hall(conth);
    
rdip=[0,0,h];
    
lambda=LS(conti);
omega=2*pi/lambda;
    
invSubstrateALL(:,:,conti,conth)=INVPolarizabilitySubstrate(omega,w0list,gammalist,alist,blist,rdip,struct,t);
invalphstaticALL(:,:,conti,conth)=INVPolarizabilityStatic(omega,w0list,gammalist,alist,blist,rdip,struct,t);
invFreeSpaceALL(:,:,conti,conth)=INVPolarizabilityFreeSpace(omega,w0list,gammalist,alist,blist,rdip,struct,t);
polarizabilityALL(:,:,conti,conth)=inv( invSubstrateALL(:,:,conti,conth)+ invalphstaticALL(:,:,conti,conth)+ invFreeSpaceALL(:,:,conti,conth)  );
conti
   
end
conth
end


%First we will study the X dipole component
% figure(1)
% plot(LS.',squeeze(real(invSubstrateALL(1,1,:))),'.',LS.',squeeze(imag(invSubstrateALL(1,1,:))),'.')
% legend('Re','Im','Location','northeast')
% title('X dipole, substrate contribution')
% figure(2)
% plot(LS.',squeeze(real(invalphstaticALL(1,1,:))),'.',LS.',squeeze(imag(invalphstaticALL(1,1,:))),'.')
% legend('Re','Im','Location','northeast')
% title('X dipole, Inv static polarizability')
% figure(3)
% plot(LS.',squeeze(real(invFreeSpaceALL(1,1,:))),'.',LS.',squeeze(imag(invFreeSpaceALL(1,1,:))),'.')
% legend('Re','Im','Location','northeast')
% title('X dipole, free space correction')
% figure(4)
% plot(LS.',squeeze(abs(invFreeSpaceALL(1,1,:))),LS.',squeeze(abs(invalphstaticALL(1,1,:))),LS.',squeeze(real(invSubstrateALL(1,1,:))))
% legend('Free space correction','Static Polarizability','Substrate correction','Location','northeast')
% title(['inv polarizability terms for the X dipole(absolute value) at ',num2str(h),' microns high'])
% 
% figure(5)
% plot(LS.',squeeze(abs(polarizabilityALL(1,1,:))))
% legend('Polarizability','Location','northeast')
% title(['polarizability for the X dipole(absolute value) at ',num2str(h),' microns high'])
% 




function invalpha=INVPolarizabilityProlate(omega,w0list,gammalist,alist,blist,rdip,struct,t)
numdipoles=size(rdip,1);
eps0=1;
mu0=1;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);
c=1;
invalpha=zeros(3*numdipoles,3*numdipoles);
for cont=1:numdipoles
    a=alist(cont);
    b=blist(cont);
    
    gamma=gammalist(cont);
    w0=w0list(cont);
    k=omega/c;
    rdipole=rdip(cont,:);
    % let's figure out an epsilon according to Drude
    % if Drude: w0 = wp/Sqrt(3)
    epsilon=1-3*(w0.^2)./omega./(omega+1i*gamma);
    ex=sqrt(1-(b./a).^2);   %% excentricity
    if ex==0
        prolateL1=1/3;
    else
        prolateL1=((1-ex.^2)./(ex.^2)).*(-1+(1./(2.*ex)).*log((1+ex)./(1-ex)));
    end
    
    prolateL2=(1-prolateL1)/2;
    em=eps1;
    prolateL3=prolateL2;
    alphax=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL1*(epsilon-em)));
    alphay=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL2*(epsilon-em)));
    alphaz=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL3*(epsilon-em)));
    alphastatic=diag([alphax,alphay,alphaz]);
%    invalpha(3*(cont-1)+1:3*cont,3*(cont-1)+1:3*cont)=inv(alphastatic)-((omega.^2)*mu0*mu1)*GreenWaveguide(k,rdipole,rdipole,struct,t)-1i*((k)^2*(mu1)/(eps0))*(omega/(6*pi*c))*eye(3);  
    invalpha(3*(cont-1)+1:3*cont,3*(cont-1)+1:3*cont)=inv(alphastatic)-((omega.^2)*mu0*mu1)*imag(GreenWaveguide(k,rdipole,rdipole,struct,t))-1i*((k)^2*(mu1)/(eps0))*(omega/(6*pi*c))*eye(3);  

end
end

function invalpha=INVPolarizabilityStatic(omega,w0list,gammalist,alist,blist,rdip,struct,t)
numdipoles=size(rdip,1);
eps0=1;
mu0=1;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);
c=1;
invalpha=zeros(3*numdipoles,3*numdipoles);
for cont=1:numdipoles
    a=alist(cont);
    b=blist(cont);
    
    gamma=gammalist(cont);
    w0=w0list(cont);
    k=omega/c;
    rdipole=rdip(cont,:);
    % let's figure out an epsilon according to Drude
    % if Drude: w0 = wp/Sqrt(3)
    epsilon=1-3*(w0.^2)./omega./(omega+1i*gamma);
    ex=sqrt(1-(b./a).^2);   %% excentricity
    if ex==0
        prolateL1=1/3;
    else
        prolateL1=((1-ex.^2)./(ex.^2)).*(-1+(1./(2.*ex)).*log((1+ex)./(1-ex)));
    end
    
    prolateL2=(1-prolateL1)/2;
    em=eps1;
    prolateL3=prolateL2;
    alphax=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL1*(epsilon-em)));
    alphay=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL2*(epsilon-em)));
    alphaz=(4)*pi*a*b*b*((epsilon-em)./(3*em+3*prolateL3*(epsilon-em)));
    alphastatic=diag([alphax,alphay,alphaz]);
    invalpha(3*(cont-1)+1:3*cont,3*(cont-1)+1:3*cont)=inv(alphastatic);
end
end

function invalpha=INVPolarizabilityFreeSpace(omega,w0list,gammalist,alist,blist,rdip,struct,t)
numdipoles=size(rdip,1);
eps0=1;
mu0=1;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);
c=1;
invalpha=zeros(3*numdipoles,3*numdipoles);
for cont=1:numdipoles
 k=omega/c;
    invalpha(3*(cont-1)+1:3*cont,3*(cont-1)+1:3*cont)=-1i*((k)^2*(mu1)/(eps0))*(omega/(6*pi*c))*eye(3);  
end
end

function invalpha=INVPolarizabilitySubstrate(omega,w0list,gammalist,alist,blist,rdip,struct,t)
numdipoles=size(rdip,1);
eps0=1;
mu0=1;
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);
c=1;
invalpha=zeros(3*numdipoles,3*numdipoles);
for cont=1:numdipoles
  k=omega/c;
  rdipole=rdip(cont,:);
  invalpha(3*(cont-1)+1:3*cont,3*(cont-1)+1:3*cont)=-((omega.^2)*mu0*mu1)*imag(GreenWaveguide(k,rdipole,rdipole,struct,t));
end
end





end