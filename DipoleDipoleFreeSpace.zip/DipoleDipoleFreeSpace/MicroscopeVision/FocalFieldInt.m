function [Efocal,numpixelsx,xgridfig,ygridfig]=FocalFieldInt(Efar,thetagrid,phigrid,deltatheta,deltaphi,xsize,ysize,numres,z,f,k)

% this function will calculate the focal field Efocal with wavevector k of a lens with focal 
% length f in the plane located
% at z on an area of size xsize x ysize divided into res points.
% z=0 is the focal plane
% input is the far field Efar on a grid of theta and phi specified by
% thetagrid and phigrid


% make the xy grid
numpixelsx=numres;
xgridfig=linspace(-xsize/2,xsize/2,numres);
ygridfig=linspace(-ysize/2,ysize/2,numres);
[xgrid,ygrid] = meshgrid(linspace(-xsize/2,xsize/2,numres),linspace(-ysize/2,ysize/2,numres));
%now send this grid which is now a vector into the third dimension
xgridlin=reshape(xgrid(:),1,1,[]);
ygridlin=reshape(ygrid(:),1,1,[]);

%find how many points does the xy grid and the theta phi grid have.
nx=size(xgridlin,3);
ny=size(ygridlin,3);
ntheta=size(thetagrid,1);
nphi=size(phigrid,1);

%now you just need to make the integral defined in novotny 3.47...since
%this integral is defined in cilindrical coordinates we just change our
%grid of wanted points x and y into an angle phisplane and a radius
%radiusplane.
radiusplane=repmat(sqrt(xgridlin.^2+ygridlin.^2),[ntheta,3,1]);
phisplane=repmat(atan2(ygridlin,xgridlin),[ntheta,3,1]);
phisplane=repmat(angle(xgridlin+1i*ygridlin),[ntheta,3,1]);

%in order to vectorize the integration we need to repeat the grid of thetas and phis in the
%third dimension so that we can multiply it element by element with our
%desired radiusplane,phisplane grid .

thetagridnew=repmat(thetagrid,[1,3,nx]);
phigridnew=repmat(phigrid,[1,3,nx]);

DeltaThetaByDeltaphi=repmat(deltatheta.*deltaphi,[1,3,nx]);


%And then you make the integration and multiply it by the deltas.
%Efocal=(1i*k*f*exp(-1i*k*f)/(2*pi))*sum(repmat(Efar,[1,1,nx]).*exp(1i*k*z.*cos(thetagridnew)).*exp(1i*k.*radiusplane.*cos(phigridnew-phisplane)).*sin(thetagridnew).*DeltaThetaByDeltaphi,1);
%Efocal=(1i*k*f*exp(-1i*k*f)/(2*pi))*sum(repmat(Efar,[1,1,nx]).*exp(1i*k*z.*cos(thetagridnew)).*exp(1i*k.*sin(thetagridnew).*radiusplane.*cos(phigridnew-phisplane)).*sin(thetagridnew).*deltatheta.*deltaphi,1);

    
%This one is the latest version%
%Efocal=(1i*k*f*exp(-1i*k*f)/(2*pi))*sum(repmat(Efar,[1,1,nx]).*exp(1i*k*z.*cos(thetagridnew)).*exp(1i*k.*sin(thetagridnew).*radiusplane.*cos(phigridnew-phisplane)).*sin(thetagridnew).*DeltaThetaByDeltaphi,1);

numtiles=50;

tilepieces=gcd(ntheta,numtiles);
numthingintile=ntheta/tilepieces;
%Efocaltemp=zeros(1,3,nx);
Efocal=zeros(1,3,nx);

for cont=1:tilepieces

    bege=(cont-1)*(numthingintile)+1;
    ende=(cont)*(numthingintile);
Efocal=Efocal+(1i*k*f*exp(-1i*k*f)/(2*pi))*sum(repmat(Efar(bege:ende,:),[1,1,nx]).*exp(1i*k*z.*cos(thetagridnew(bege:ende,:,:))).*exp(1i*k.*sin(thetagridnew(bege:ende,:,:)).*radiusplane(bege:ende,:,:).*cos(phigridnew(bege:ende,:,:)-phisplane(bege:ende,:,:))).*sin(thetagridnew(bege:ende,:,:)).*DeltaThetaByDeltaphi(bege:ende,:,:),1);
end




