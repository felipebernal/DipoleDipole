function [Fieldplane]=TransformSpherePlane(omega,Fieldsphere,thetagridlin,phigridlin,nbeforeMIC,nafterMIC,nlenses)
 c=1;
 k=omega/c;
% 
%  mu1=1;
%  mu2=1;
%  eps1=nbeforeMIC^2;
%  eps2=nlenses^2;
%  kz1=k*nbeforeMIC*cos(thetagridlin);
%  kz2=k*nlenses*cos(thetagridlin);
%  ts=(2*mu2*kz1)./(mu2*kz1+mu1*kz2);
%  tp=(2*eps2*kz1)./(eps2*kz1+eps1*kz2);
ts=1;
tp=1;

%Here we define the director vectors 
nrho=[cos(phigridlin),sin(phigridlin),0*phigridlin];
nphi=[-sin(phigridlin),cos(phigridlin),0*phigridlin];
ntheta=[cos(thetagridlin).*cos(phigridlin),cos(thetagridlin).*sin(phigridlin),-sin(thetagridlin)];

%and here we trnasfor the field in the direction of ntheta to nrho
firstterm=repmat(sum(Fieldsphere.*nphi,2).*ts,1,3).*nphi;
secondterm=repmat(sum(Fieldsphere.*ntheta,2).*tp,1,3).*nrho;
Fieldplane=sqrt(nafterMIC/nbeforeMIC)*(firstterm+secondterm).*repmat(1./sqrt(cos(thetagridlin)),1,3);



end