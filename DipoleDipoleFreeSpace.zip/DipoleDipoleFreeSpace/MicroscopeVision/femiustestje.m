clear all
nlenses=1;
k=2*pi/0.600;  %% lambda in microns
epslenses=nlenses^2;
%refractive indeces of the different mediums before and after both lenses
%1st called MIC 2nd called lens.
%lenses
NAmicroscope=0.95
nbeforelMIC=1; 
nafterMIC=1;
nbeforelens=1;
nafterlens=1;
thetamaxMIC=asin(NAmicroscope/nbeforelens); %This is the maximum theta that the first lens can see...



Mag=100; 
fmicroscope =550E-6
fov=2;%this is the field of view in microns
numpx=50;


%We need to find the field on a sphere at different positions, so first we find what those positions are:
%here we define the grid
gridnr=50;
%[phigrid,thetagrid] = meshgrid(linspace(0,2*pi,gridnr),linspace(0,thetamaxMIC,gridnr));
%x=cos(phigrid).*sin(thetagrid);y=sin(phigrid).*sin(thetagrid);

x=NAmicroscope*([-gridnr:gridnr]/gridnr);y=x;
[x y]=meshgrid(x,y);
phigrid=angle(x+1i*y);
thetagrid=asin(sqrt(x.^2+y.^2));


mask=(sqrt(x.^2+y.^2)<NAmicroscope)*1.0;
phigridlin=phigrid(:);
thetagridlin=thetagrid(:);
masklin=mask(:);
 


%
%Fieldsphere= FieldEfinder('scatt','far',posMICsphere,omega,struct,t,direction,pol,rsource,@GuidedWaveELayered,VECQ,matM,positiondipoles);
%Fieldsphere= FieldEfinderMicroscope('scatt','far',posMICsphere,omega,struct,t,direction,pol,rsource,@GuidedWaveELayered,VECQ,matM,positiondipoles);
%%%%%%%%


pmn=[0 0 1 0 0 0 ].';
rdipole=[ 0.5 0 0 ];
for p=1:length(phigridlin), 
        rdipole=[ 0.5 0 0 ];
        director=rdipole(1)*(cos(phigridlin(p))*sin(thetagridlin(p)))+rdipole(2)*(sin(phigridlin(p))*sin(thetagridlin(p)))+rdipole(3)*(cos(thetagridlin(p)));
        field=exp(1i*k*director)*exp(1i*k*fmicroscope)/fmicroscope*FarAngularG(thetagridlin(p),phigridlin(p ))*pmn;
        
        rdipole=[ -0.5 0 0 ];
        director=rdipole(1)*(cos(phigridlin(p))*sin(thetagridlin(p)))+rdipole(2)*(sin(phigridlin(p))*sin(thetagridlin(p)))+rdipole(3)*(cos(thetagridlin(p)));
        field=field+exp(1i*k*director)*exp(1i*k*fmicroscope)/fmicroscope*FarAngularG(thetagridlin(p),phigridlin(p ))*pmn;
        
        
        Fieldsphere(p,1:3)=field(1:3)*masklin(p);
end
  


[Fieldplane]=TransformSpherePlane(0,Fieldsphere,thetagridlin,phigridlin,nbeforelMIC,nafterMIC,nlenses);

figure(1)

pcolor(x,y,reshape(real(Fieldplane(:,1)),size(phigrid))); axis equal
title('backaperture field')



%% now find the image again.  Low NA optics just Fourier transforms. This
%% is the same as Novotny;s high NA formula in the low NA limit.


%% Ex and Ey as a function of kx and ky

%%    


Exback=reshape(Fieldplane(:,1),size(phigrid));
Eyback=reshape(Fieldplane(:,2),size(phigrid));

ximage= Mag*fov*[-gridnr:gridnr]/gridnr;
yimage= Mag*fov*[-gridnr:gridnr]/gridnr;
[ximage yimage]=meshgrid(ximage,yimage);
Eximage=0*ximage;Eyimage=0*ximage;
for p=1:size(ximage,1),
    for q=1:size(ximage,2),
        Eximage(p,q)=sum(sum(exp(-(1i*ximage(p,q)*x-1i*yimage(p,q)*y)/(2*pi)).*Exback));
        Eyimage(p,q)=sum(sum(exp(-(1i*ximage(p,q)*x-1i*yimage(p,q)*y)/(2*pi)).*Eyback));
    end
end

figure(2)

 pcolor(ximage,yimage,abs(Eximage).^2+abs(Eyimage).^2);axis image; shading flat, colormap hot
title('image')



%% Felipe says


 

thetagridnew=asin(sin(thetagridlin)/Mag);

[Fieldspherelens]=TransformPlanesphere(k,Fieldplane,thetagridnew,phigridlin,nbeforelens,nafterlens,nlenses);

z=0;%this is the z at the focal plane by definition.


deltathetaold=thetamaxMIC/(2*gridnr+1);
  deltatheta=deltathetaold*(cos(thetagridlin)./(sqrt(1-(sin(thetagridlin)/Mag).^2)))/Mag;

%  deltatheta=asin(sin(thetamaxMIC)/Mag)/(2*gridnr+1)*ones(size(phigridlin,1),1);
  deltaphi=2*pi/(2*gridnr+1)*ones(size(phigridlin,1),1);



% deltathetamat=gradient(reshape(thetagridnew,gridnr,gridnr));
% deltapghimat=gradient(reshape(phigridlin,gridnr,gridnr));

% [deltathetamatx,deltathetamaty]=gradient(reshape(thetagridnew,gridnr*2+1,gridnr*2+1));
% deltathetamat=sqrt(deltathetamatx.^2+deltathetamaty.^2);
% 
% [deltaphimatx,deltaphimaty]=gradient(reshape(phigridlin,gridnr*2+1,gridnr*2+1));
% deltaphimat=sqrt(deltaphimatx.^2+deltaphimaty.^2);
% 
% 
% 
% deltaphi=deltaphimat(:);
% deltatheta=deltathetamat(:);






[Efocal,numpixelsx,xgrid,ygrid]=FocalFieldInt(Fieldspherelens,thetagridnew,phigridlin,deltatheta,deltaphi,2*Mag*fov,2*Mag*fov,numpx,z,fmicroscope*Mag,k);


A=Efocal(1,1,:);B=Efocal(1,2,:);figure(3); 
pcolor(xgrid,ygrid,reshape(real(A).^2,[length(xgrid) length(xgrid)])+reshape(real(B).^2,[length(xgrid) length(xgrid)]))
colormap hot