function [farangularg]=FarAngularG(theta,phi)

 
rhat=[cos(phi)*sin(theta) sin(phi)*sin(theta) cos(theta)];

gdiag=eye(3)-rhat.'*rhat;
goffdiag=[ 0 -rhat(3) rhat(2); rhat(3) 0 -rhat(1); -rhat(2) rhat(1) 0];

farangularg=[gdiag -goffdiag; goffdiag  gdiag];  %% comparison with FreeDyadG suggests there should be a minus somewhere...


end
