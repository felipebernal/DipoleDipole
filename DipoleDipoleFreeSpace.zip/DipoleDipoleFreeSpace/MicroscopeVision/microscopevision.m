function [Efocal,numpixelsx,xgrid,ygrid]=microscopevision(omega,matM,VECQ,positiondipoles,fmicroscope,NAmicroscope,ftubelens,nlenses,muv,epsilonv)

%In this program we will find the image that you would get from a normal
%microscope. This microscope has a focal distance fmicroscope and NA=
%Namicroscope. The tube lens ahs a focal distance ftubelens and the
%refractive index of these two lenses is nlenses. Omega is hte frequency at
%which the dipole is emiting. MatM is the matrix that comes from the dipole
%dipole calculator or the new polarizability and VECQ the vector with the
%fields at the dipole positions. struct is the indices of the substrate
%where the dipoles sit namely [[eps1;eps2;eps3],[mu1;mu2;mu3]] and finally
%t is the tichness of the sadwiched layer.

p2 = path;
path(p2,'..\DipoleDipoleInteractions');

c=1;
k=omega/c;
epslenses=nlenses^2;
%refractive indeces of the different mediums before and after both lenses
%1st called MIC 2nd called lens.
%lenses
nbeforelMIC=1; 
nafterMIC=1;
nbeforelens=1;
nafterlens=1;
thetamaxMIC=asin(NAmicroscope/nbeforelens); %This is the maximum theta that the first lens can see...

Mag=ftubelens/fmicroscope;
fovsample=1;         % field of view in microns at sample plane

fov=3*Mag;%this is the field of view in microns
numpx=50;


%We need to find the field on a sphere at different positions, so first we find what those positions are:
%here we define the grid
gridnr=50;
[phigrid,thetagrid] = meshgrid(linspace(0,2*pi,gridnr),linspace(0,thetamaxMIC,gridnr));
phigridlin=phigrid(:);
thetagridlin=thetagrid(:);

posMICsphere=zeros(gridnr*gridnr,3);
posMICsphere=[fmicroscope*cos(phigridlin).*sin(thetagridlin),fmicroscope*sin(phigridlin).*sin(thetagridlin),fmicroscope*cos(thetagridlin)];

%the vectors thetagridlin phigridlin are long vectors with 1 column where we have all the
%combinations of phi and thetas. This structure is better for when we need
%to do the integration in a vectorized way and therefore we can use a third
% dimensions for the positions that we want to evaluate while having the different field components in the second dimension.


%%%Now we find the field over this grid


%This part simply gets the positions and the dipoles and gives the field at
%those positions.

%%%%%%%%You can change this part for your favorite field finder depending on
%positions and dipoles...or whatever you can imagine.


%direction, pol and rsource are not needed since we only need the field from the dipoles and not from the exitation field so we put three random numbers 
direction=[0,-1,0];
pol=[1,0,0];
rsource=[0,0,0];
%
Fieldsphere= FieldEfinder('scatt','far',posMICsphere,omega,muv,epsilonv,direction,pol,rsource,@PlaneWaveE,VECQ,matM,positiondipoles);
%Fieldsphere= FieldEfinderMicroscope('scatt','far',posMICsphere,omega,struct,t,direction,pol,rsource,@GuidedWaveELayered,VECQ,matM,positiondipoles);
%%%%%%%%



%Having the field at the surface of the sphere now we need to make the transformation from the sphere to a plane.

[Fieldplane]=TransformSpherePlane(omega,Fieldsphere,thetagridlin,phigridlin,nbeforelMIC,nafterMIC,nlenses);


%Now with the field on the plane we need to transform the grid in theta for
%the second lens  according to sin(thetaone)*fone=sin(thetatwo)*ftwo


thetagridnew=asin(sin(thetagridlin)*fmicroscope/ftubelens);

[Fieldspherelens]=TransformPlanesphere(omega,Fieldplane,thetagridnew,phigridlin,nbeforelens,nafterlens,nlenses);

z=0;%this is the z at the focal plane by definition.




deltathetaold=thetamaxMIC/(gridnr);
deltatheta=deltathetaold*(cos(thetagridlin)./(sqrt(1-(sin(thetagridlin)/Mag).^2)))/Mag;
deltaphi=2*pi/(gridnr)*ones(size(phigridlin,1),1);


%deltatheta=(asin(sin(thetamaxMIC)*fmicroscope/ftubelens))/gridnr;
%deltaphi=2*pi/gridnr;

[Efocal,numpixelsx,xgrid,ygrid]=FocalFieldInt(Fieldspherelens,thetagridnew,phigridlin,deltatheta,deltaphi,fov,fov,numpx,z,ftubelens,k);
% matrixintensity=reshape(sqrt(sum(Efocal.*conj(Efocal),2)),numpixelsx,numpixelsx);
% figure(2)
% imagesc(matrixintensity);
%colormap(hot)


%In order to have the image in distances that relate to the real distances
%in the sample plane we now divide them by the magnification.

xgrid=xgrid./Mag;
ygrid=ygrid./Mag;
