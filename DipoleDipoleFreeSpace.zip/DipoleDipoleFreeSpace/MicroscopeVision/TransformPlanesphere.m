function [Fieldsphere]=TransformPlanesphere(omega,Fieldplane,thetagridlin,phigridlin,nbeforelens,nafterlens,nlenses)
c=1;
k=omega/c;

mu1=1;
mu2=1;
eps1=nbeforelens^2;
eps2=nlenses^2;
kz1=k*nbeforelens*cos(thetagridlin);
kz2=k*nlenses*cos(thetagridlin);
ts=(2*mu2*kz1)./(mu2*kz1+mu1*kz2);
tp=(2*eps2*kz1)./(eps2*kz1+eps1*kz2);
%ts=1;
%tp=1;


%Here we define the director vectors 
nrho=[cos(phigridlin),sin(phigridlin),0*phigridlin];
nphi=[-sin(phigridlin),cos(phigridlin),0*phigridlin];
ntheta=[cos(thetagridlin).*cos(phigridlin),cos(thetagridlin).*sin(phigridlin),-sin(thetagridlin)];

%and here we trnasfor the field in the direction of nrho to ntheta
firstterm=repmat(sum(Fieldplane.*nphi,2).*ts,1,3).*nphi;
secondterm=repmat(sum(Fieldplane.*nrho,2).*tp,1,3).*ntheta;
Fieldsphere=sqrt(nafterlens/nbeforelens)*(firstterm+secondterm).*repmat(sqrt(cos(thetagridlin)),1,3);




end